const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const defaults = {
  settings: {
    global_margin: '0', okeconnect_member_id: '', okeconnect_password: '', okeconnect_pin: '',
    ppob_secret: '', token_bo: '', telegram_bot_token_ppob: '', telegram_chat_id: '', token_fonnte: '',
    digiflazz_webhook_secret: ''
  },
  admins: [], products: [], transactions: [], members: [], memberships: [], membership_prices: [],
  refunds: [], token_signature: [], login_attempts: [], login_confirmations: []
};

function fileFor(name){ return path.join(DATA_DIR, `${name}.json`); }
function clone(v){ return JSON.parse(JSON.stringify(v)); }
function ensure(name){
  const f=fileFor(name);
  if(!fs.existsSync(f)) fs.writeFileSync(f, JSON.stringify(defaults[name] ?? [], null, 2));
  try { return JSON.parse(fs.readFileSync(f,'utf8') || (Array.isArray(defaults[name])?'[]':'{}')); }
  catch { return clone(defaults[name] ?? []); }
}
function write(name, data){
  const f=fileFor(name), tmp=f+'.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data,null,2));
  fs.renameSync(tmp,f);
}
function all(name){ return ensure(name); }
function set(name,data){ write(name,data); return data; }
function first(name, pred=()=>true){ return all(name).find(pred); }
function upsert(name, pred, value){ const a=all(name); const i=a.findIndex(pred); if(i<0)a.push(value); else a[i]={...a[i],...value}; write(name,a); return a[i<0?a.length-1:i]; }
function remove(name,pred){ const a=all(name); const b=a.filter(x=>!pred(x)); write(name,b); return a.length-b.length; }

function init(){
  for(const k of Object.keys(defaults)) ensure(k);
  const admins=all('admins');
  if(!admins.length){
    const bcrypt=require('bcryptjs');
    admins.push({id:1,username:'admin',password:bcrypt.hashSync('admin123',10),allowed_device_token:'',allowed_user_agent:'',allowed_location:''});
    write('admins',admins);
  }
}
init();
module.exports={DATA_DIR,all,set,first,upsert,remove,write,init};
