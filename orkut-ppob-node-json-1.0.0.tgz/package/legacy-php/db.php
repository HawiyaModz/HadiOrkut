<?php
// ==========================================
// KONFIGURASI DATABASE
// Silakan ubah sesuai dengan database hosting Anda
// ==========================================
$db_host = 'localhost';
$db_user = '';       // Ganti dengan username database Anda
$db_pass = '';           // Ganti dengan password database Anda
$db_name = ''; // Ganti dengan nama database Anda

$pdo = null;
$db_setup_error = null;

try {
    // Membuat koneksi PDO
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false); // Mencegah SQL Injection tingkat lanjut
    
    // Buat tabel settings jika belum ada
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        key_name VARCHAR(50) PRIMARY KEY,
        key_value TEXT
    )");

    // Buat tabel admins jika belum ada
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE,
        password VARCHAR(255)
    )");

    // Insert default admin jika kosong
    $stmt = $pdo->query("SELECT COUNT(*) FROM admins");
    if ($stmt->fetchColumn() == 0) {
        $default_pass = password_hash('admin123', PASSWORD_DEFAULT);
        $pdo->exec("INSERT INTO admins (username, password) VALUES ('admin', '$default_pass')");
    }

    // Buat tabel products jika belum ada
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        buyer_sku_code VARCHAR(50) PRIMARY KEY,
        product_name VARCHAR(255),
        category VARCHAR(100),
        brand VARCHAR(100),
        type VARCHAR(100),
        seller_name VARCHAR(100),
        price INT,
        sell_price INT,
        margin INT DEFAULT 0,
        admin INT DEFAULT 0,
        commission INT DEFAULT 0,
        buyer_product_status TINYINT(1),
        seller_product_status TINYINT(1),
        unlimited_stock TINYINT(1),
        stock INT,
        multi TINYINT(1),
        start_cut_off VARCHAR(10),
        end_cut_off VARCHAR(10),
        description TEXT,
        product_type VARCHAR(20),
        display TINYINT(1) DEFAULT 1
    )");

    // Tambahkan kolom margin jika belum ada (untuk update dari versi sebelumnya)
    try {
        $pdo->exec("ALTER TABLE products ADD COLUMN margin INT DEFAULT 0");
    } catch (PDOException $e) {
        // Abaikan jika kolom sudah ada
    }
    
    try {
        $pdo->exec("ALTER TABLE products ADD COLUMN admin INT DEFAULT 0");
    } catch (PDOException $e) {
    }
    
    try {
        $pdo->exec("ALTER TABLE products ADD COLUMN commission INT DEFAULT 0");
    } catch (PDOException $e) {
    }
    try {
        $pdo->exec("ALTER TABLE settings ADD COLUMN token_bo varchar(255)");
    } catch (PDOException $e) {
    }

    // Buat tabel transactions jika belum ada
    $pdo->exec("CREATE TABLE IF NOT EXISTS transactions (
        ref_id VARCHAR(100) PRIMARY KEY,
        id_user VARCHAR(50),
        nama_user VARCHAR(100),
        price_user INT,
        buyer_user VARCHAR(50),
        buyer_sku_code VARCHAR(50),
        customer_no VARCHAR(100),
        command VARCHAR(50),
        status VARCHAR(50),
        message TEXT,
        rc VARCHAR(10),
        sn VARCHAR(255),
        price INT,
        selling_price INT,
        customer_name VARCHAR(255),
        admin_fee INT,
        desc_detail TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");

    // tambahkan kolom jika belum ada (untuk update dari versi sebelumnya)
    $columns_to_add = [
        "id_user VARCHAR(50)",
        "nama_user VARCHAR(100)",
        "customer_name VARCHAR(255)",
        "admin_fee INT",
        "desc_detail TEXT"
    ];

    // buat tabel token_signature jika belum ada
    $pdo->exec("CREATE TABLE IF NOT EXISTS token_signature (
        id INT AUTO_INCREMENT PRIMARY KEY,
        token VARCHAR(255),
        action VARCHAR(50),
        signature VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    foreach ($columns_to_add as $col) {
        try {
            $pdo->exec("ALTER TABLE transactions ADD COLUMN $col");
        } catch (PDOException $e) {
            // Abaikan jika kolom sudah ada
        }
    }

    // buat tabel refund jika belum ada
    $pdo->exec("CREATE TABLE IF NOT EXISTS refunds (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ref_id VARCHAR(100),
        id_user VARCHAR(50),
        amount INT,
        reason TEXT,
        status VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    //  tambahkan ALTER TABLE refunds ADD UNIQUE (ref_id);
    $pdo->exec("ALTER TABLE refunds ADD UNIQUE (ref_id);");

    // Tambahkan index untuk optimasi query jika belum ada
    $indexes_to_add = [
        "CREATE INDEX idx_trx_created_at ON transactions(created_at)",
        "CREATE INDEX idx_trx_stats ON transactions(status, command, created_at)",
        "CREATE INDEX idx_trx_ref_id ON transactions(ref_id)",
        "CREATE INDEX idx_trx_customer_no ON transactions(customer_no)",
        "CREATE INDEX idx_trx_buyer_sku ON transactions(buyer_sku_code)",

        "CREATE INDEX idx_prod_type_brand_name ON products(product_type, brand, product_name)",
        "CREATE INDEX idx_prod_category_type ON products(category, product_type)",
        "CREATE INDEX idx_prod_sku ON products(buyer_sku_code)",
        // index untuk tabel token_signature
        "CREATE INDEX idx_token_action ON token_signature(action)",
        "CREATE INDEX idx_token_token ON token_signature(token)",
        "CREATE INDEX idx_token_signature ON token_signature(signature)",

        // index untuk tabel refunds
        "CREATE INDEX idx_refund_ref_id ON refunds(ref_id)",
        "CREATE INDEX idx_refund_id_user ON refunds(id_user)",
        "CREATE INDEX idx_refund_status ON refunds(status)",
        "CREATE INDEX idx_refund_created_at ON refunds(created_at)"
    ];

    foreach ($indexes_to_add as $index_sql) {
        try {
            $pdo->exec($index_sql);
        } catch (PDOException $e) {
            // Abaikan jika index sudah ada
        }
    }

} catch(PDOException $e) {
    // Menangkap error jika database belum dibuat atau kredensial salah
    $db_setup_error = $e->getMessage();
}
?>
