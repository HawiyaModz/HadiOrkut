SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `allowed_device_token` varchar(255) DEFAULT NULL,
  `allowed_user_agent` varchar(255) DEFAULT NULL,
  `allowed_location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) NOT NULL,
  `attempt_time` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `login_confirmations` (
  `id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `username` varchar(100) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `new_device_token_hash` varchar(255) NOT NULL,
  `otp_code` varchar(10) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `Member` (
  `id` int(11) NOT NULL,
  `id_user` varchar(11) DEFAULT NULL,
  `nama_user` varchar(255) DEFAULT NULL,
  `nomor_telepon` varchar(20) DEFAULT NULL,
  `paylater` varchar(10) NOT NULL DEFAULT 'tidak',
  `limit` int(11) NOT NULL DEFAULT 0,
  `sisa_pinjaman` int(11) NOT NULL DEFAULT 0,
  `total_pinjaman` int(11) NOT NULL DEFAULT 0,
  `total_bayar` int(11) NOT NULL DEFAULT 0,
  `email_user` varchar(255) DEFAULT NULL,
  `saldo_user` int(11) DEFAULT 0,
  `jumlah_transaksi` int(11) NOT NULL DEFAULT 0,
  `nama_membership` varchar(255) NOT NULL DEFAULT 'Umum',
  `poin_member` int(11) NOT NULL DEFAULT 0,
  `last_login` datetime NOT NULL DEFAULT current_timestamp(),
  `ua` varchar(255) NOT NULL DEFAULT '-',
  `restricted_products` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `memberships` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `membership_prices` (
  `id` int(11) NOT NULL,
  `membership_name` varchar(100) NOT NULL,
  `buyer_sku_code` varchar(100) NOT NULL,
  `price_adjustment` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `products` (
  `buyer_sku_code` varchar(50) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `seller_name` varchar(100) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `sell_price` int(11) DEFAULT NULL,
  `margin` int(11) DEFAULT 0,
  `admin` int(11) DEFAULT 0,
  `commission` int(11) DEFAULT 0,
  `buyer_product_status` tinyint(1) DEFAULT NULL,
  `seller_product_status` tinyint(1) DEFAULT NULL,
  `unlimited_stock` tinyint(1) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `multi` tinyint(1) DEFAULT NULL,
  `start_cut_off` varchar(10) DEFAULT NULL,
  `end_cut_off` varchar(10) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `product_type` varchar(20) DEFAULT NULL,
  `display` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `refunds` (
  `id` int(11) NOT NULL,
  `ref_id` varchar(100) DEFAULT NULL,
  `id_user` varchar(50) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `settings` (
  `key_name` varchar(50) NOT NULL,
  `key_value` text DEFAULT NULL,
  `token_bo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `settings` (`key_name`, `key_value`, `token_bo`) VALUES
('global_margin', '0', NULL),
('okeconnect_member_id', '', NULL),
('okeconnect_password', '', NULL),
('okeconnect_pin', '', NULL),
('ppob_secret', '', NULL),
('telegram_bot_token_ppob', '', NULL),
('telegram_chat_id', '', NULL),
('token_bo', '', NULL),
('token_fonnte', '', NULL);

CREATE TABLE `token_signature` (
  `id` int(11) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE TABLE `transactions` (
  `ref_id` varchar(100) NOT NULL,
  `id_user` varchar(50) DEFAULT NULL,
  `nama_user` varchar(100) DEFAULT NULL,
  `price_user` int(11) DEFAULT NULL,
  `buyer_user` varchar(50) DEFAULT NULL,
  `buyer_sku_code` varchar(50) DEFAULT NULL,
  `customer_no` varchar(100) DEFAULT NULL,
  `command` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `ip` varchar(255) NOT NULL DEFAULT '-',
  `message` text DEFAULT NULL,
  `rc` varchar(10) DEFAULT NULL,
  `sn` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `selling_price` int(11) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `admin_fee` int(11) DEFAULT NULL,
  `desc_detail` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `metadata` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ip_address` (`ip_address`,`attempt_time`),
  ADD KEY `username` (`username`,`attempt_time`);

ALTER TABLE `login_confirmations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `token_2` (`token`),
  ADD KEY `otp_code` (`otp_code`);

ALTER TABLE `Member`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_id_user` (`id_user`);

ALTER TABLE `memberships`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

ALTER TABLE `membership_prices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_membership_sku` (`membership_name`,`buyer_sku_code`);

ALTER TABLE `products`
  ADD PRIMARY KEY (`buyer_sku_code`),
  ADD KEY `idx_prod_type_brand_name` (`product_type`,`brand`,`product_name`),
  ADD KEY `idx_prod_category_type` (`category`,`product_type`),
  ADD KEY `idx_prod_sku` (`buyer_sku_code`);

ALTER TABLE `refunds`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ref_id` (`ref_id`),
  ADD UNIQUE KEY `ref_id_2` (`ref_id`),
  ADD UNIQUE KEY `ref_id_3` (`ref_id`),
  ADD UNIQUE KEY `ref_id_4` (`ref_id`),
  ADD UNIQUE KEY `ref_id_5` (`ref_id`),
  ADD UNIQUE KEY `ref_id_6` (`ref_id`),
  ADD UNIQUE KEY `ref_id_7` (`ref_id`),
  ADD UNIQUE KEY `ref_id_8` (`ref_id`),
  ADD UNIQUE KEY `ref_id_9` (`ref_id`),
  ADD UNIQUE KEY `ref_id_10` (`ref_id`),
  ADD UNIQUE KEY `ref_id_11` (`ref_id`),
  ADD UNIQUE KEY `ref_id_12` (`ref_id`),
  ADD UNIQUE KEY `ref_id_13` (`ref_id`),
  ADD UNIQUE KEY `ref_id_14` (`ref_id`),
  ADD UNIQUE KEY `ref_id_15` (`ref_id`),
  ADD UNIQUE KEY `ref_id_16` (`ref_id`),
  ADD UNIQUE KEY `ref_id_17` (`ref_id`),
  ADD UNIQUE KEY `ref_id_18` (`ref_id`),
  ADD UNIQUE KEY `ref_id_19` (`ref_id`),
  ADD UNIQUE KEY `ref_id_20` (`ref_id`),
  ADD UNIQUE KEY `ref_id_21` (`ref_id`),
  ADD UNIQUE KEY `ref_id_22` (`ref_id`),
  ADD UNIQUE KEY `ref_id_23` (`ref_id`),
  ADD UNIQUE KEY `ref_id_24` (`ref_id`),
  ADD UNIQUE KEY `ref_id_25` (`ref_id`),
  ADD UNIQUE KEY `ref_id_26` (`ref_id`),
  ADD UNIQUE KEY `ref_id_27` (`ref_id`),
  ADD UNIQUE KEY `ref_id_28` (`ref_id`),
  ADD UNIQUE KEY `ref_id_29` (`ref_id`),
  ADD UNIQUE KEY `ref_id_30` (`ref_id`),
  ADD UNIQUE KEY `ref_id_31` (`ref_id`),
  ADD UNIQUE KEY `ref_id_32` (`ref_id`),
  ADD UNIQUE KEY `ref_id_33` (`ref_id`),
  ADD UNIQUE KEY `ref_id_34` (`ref_id`),
  ADD UNIQUE KEY `ref_id_35` (`ref_id`),
  ADD UNIQUE KEY `ref_id_36` (`ref_id`),
  ADD UNIQUE KEY `ref_id_37` (`ref_id`),
  ADD UNIQUE KEY `ref_id_38` (`ref_id`),
  ADD UNIQUE KEY `ref_id_39` (`ref_id`),
  ADD UNIQUE KEY `ref_id_40` (`ref_id`),
  ADD UNIQUE KEY `ref_id_41` (`ref_id`),
  ADD UNIQUE KEY `ref_id_42` (`ref_id`),
  ADD UNIQUE KEY `ref_id_43` (`ref_id`),
  ADD UNIQUE KEY `ref_id_44` (`ref_id`),
  ADD UNIQUE KEY `ref_id_45` (`ref_id`),
  ADD UNIQUE KEY `ref_id_46` (`ref_id`),
  ADD UNIQUE KEY `ref_id_47` (`ref_id`),
  ADD UNIQUE KEY `ref_id_48` (`ref_id`),
  ADD UNIQUE KEY `ref_id_49` (`ref_id`),
  ADD UNIQUE KEY `ref_id_50` (`ref_id`),
  ADD UNIQUE KEY `ref_id_51` (`ref_id`),
  ADD UNIQUE KEY `ref_id_52` (`ref_id`),
  ADD UNIQUE KEY `ref_id_53` (`ref_id`),
  ADD UNIQUE KEY `ref_id_54` (`ref_id`),
  ADD UNIQUE KEY `ref_id_55` (`ref_id`),
  ADD UNIQUE KEY `ref_id_56` (`ref_id`),
  ADD UNIQUE KEY `ref_id_57` (`ref_id`),
  ADD UNIQUE KEY `ref_id_58` (`ref_id`),
  ADD UNIQUE KEY `ref_id_59` (`ref_id`),
  ADD KEY `idx_refund_ref_id` (`ref_id`),
  ADD KEY `idx_refund_id_user` (`id_user`),
  ADD KEY `idx_refund_status` (`status`),
  ADD KEY `idx_refund_created_at` (`created_at`);

ALTER TABLE `settings`
  ADD PRIMARY KEY (`key_name`) USING BTREE;

ALTER TABLE `token_signature`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_token_action` (`action`),
  ADD KEY `idx_token_token` (`token`),
  ADD KEY `idx_token_signature` (`signature`);

ALTER TABLE `transactions`
  ADD PRIMARY KEY (`ref_id`),
  ADD KEY `idx_trx_created_at` (`created_at`),
  ADD KEY `idx_trx_stats` (`status`,`command`,`created_at`),
  ADD KEY `idx_trx_ref_id` (`ref_id`),
  ADD KEY `idx_trx_customer_no` (`customer_no`),
  ADD KEY `idx_trx_buyer_sku` (`buyer_sku_code`);


ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `login_confirmations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `memberships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `membership_prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `refunds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `token_signature`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
