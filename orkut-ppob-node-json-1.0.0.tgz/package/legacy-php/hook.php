<?php
require_once __DIR__ . '/db.php';
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: *');
header('Access-Control-Allow-Headers: *');

// Set header response ke JSON
header('Content-Type: application/json');

// Fungsi untuk mengambil konfigurasi dari database
function getConfig($pdo, $key, $default = '')
{
    try {
        $stmt = $pdo->prepare("SELECT key_value FROM settings WHERE key_name = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetchColumn();
        return $result !== false ? $result : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

function reconnectDB($db_host, $db_name, $db_user, $db_pass)
{
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    return $pdo;
}

$token_bo = getConfig($pdo, 'token_bo', '');
$token_fonnte = getConfig($pdo, 'token_fonnte', '');

function updateSaldoMember($id_user, $tipe, $jumlah, $catatan, $token_bo, $oid = null)
{
    $header = array("Authorization: Bearer " . $token_bo);

    $post_body = array(
        "id_user" => $id_user,
        "tipe" => $tipe, // tambah / kurang
        "jumlah" => $jumlah,
        "catatan_saldo" => $catatan,
        "token" => $token_bo,
    );

    // DIRECT KE API BUKAOLSHOP
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://bukaolshop.net/api/v1/member/saldo");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_body);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $hasil = curl_exec($ch);
        curl_close($ch);

        return json_decode($hasil, true);
}

function sendTelegramNotif($pdo, $trx, $newStatus, $source)
{
    $botToken = getConfig($pdo, 'telegram_bot_token_ppob', '');
    $chatId   = getConfig($pdo, 'telegram_chat_id', '');

    if (empty($botToken) || empty($chatId)) {
        file_put_contents(
            'telegram_error.txt',
            date('Y-m-d H:i:s') . " - Token/ChatID kosong\n",
            FILE_APPEND
        );
        return;
    }

    $message = "Transaksi Ref ID: $trx\n"
             . "Status: $newStatus\n"
             . "Source: $source";

    $payload = [
        'chat_id' => $chatId,
        'text'    => $message
    ];

    $ch = curl_init("https://api.telegram.org/bot{$botToken}/sendMessage");

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);

    $response = curl_exec($ch);
    $error    = curl_error($ch);
    curl_close($ch);

    file_put_contents(
        'telegram_log.txt',
        date('Y-m-d H:i:s') . " - RESPONSE: " . $response . PHP_EOL,
        FILE_APPEND
    );

    if ($error) {
        file_put_contents(
            'telegram_error.txt',
            date('Y-m-d H:i:s') . " - ERROR: " . $error . PHP_EOL,
            FILE_APPEND
        );
    }
}

$webhook_secret = getConfig($pdo, 'digiflazz_webhook_secret', '');

// Ambil data
$ref_id = $_GET['refid'] ?? $_POST['refid'] ?? '';
$message = $_GET['message'] ?? $_POST['message'] ?? '';
$manual_status = $_GET['status'] ?? $_POST['status'] ?? '';

$post_data = $_POST;

if (empty($post_data)) {
    $post_data = $_GET;
}

if (empty($ref_id)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'refid is missing']);
    exit;
}

file_put_contents('okeconnect_log.txt', date('Y-m-d H:i:s'). ' - REF: ' . $ref_id . ' - MSG: ' . $message . ' - STATUS: ' . $manual_status . PHP_EOL, FILE_APPEND);

// Determine status from message or manual override
$status = 'Pending';
$sn = '';

if (!empty($manual_status)) {
    if (stripos($manual_status, 'SUKSES') !== false || stripos($manual_status, 'Sukses') !== false) {
        $status = 'Sukses';
    } else if (stripos($manual_status, 'GAGAL') !== false || stripos($manual_status, 'Gagal') !== false || stripos($manual_status, 'BATAL') !== false) {
        $status = 'Gagal';
    } else {
        $status = 'Pending';
    }

    if (empty($message)) {
        if ($status === 'Sukses') {
            $message = 'Transaksi sukses diproses secara manual oleh Admin.';
        } else if ($status === 'Gagal') {
            $message = 'Transaksi dibatalkan secara manual oleh Admin.';
        } else {
            $message = 'Transaksi diubah ke pending secara manual oleh Admin.';
        }
    }
} else {
    if (stripos($message, 'SUKSES') !== false || stripos($message, 'Sukses') !== false) {
        $status = 'Sukses';
        // extract SN
        if (preg_match('/SN:\s*(.*?)\s*Saldo/i', $message, $m)) {
            $sn = rtrim(trim($m[1]), '.');
        }
    } else if (stripos($message, 'GAGAL') !== false || stripos($message, 'Gagal') !== false) {
        $status = 'Gagal';
        // extract KET
        if (preg_match('/KET:\s*(.*?)\s*Saldo/i', $message, $m)) {
            $sn = rtrim(trim($m[1]), '.');
        } else if (preg_match('/GAGAL.\s*(.*?)\s*Saldo/i', $message, $m)) {
            $sn = rtrim(trim($m[1]), '.');
        }
    } else if (stripos($message, 'diproses') !== false) {
        $status = 'Pending';
    }
}

$price = 0; // we don't get price directly, usually it says "Harga x" but we might need to parse.
$rc = '';

// update message. hapus bagian Saldo sampai akhir
$message = preg_replace('/Saldo\s*[\d\.,]+/i', '', $message);

// From this point, we can copy the transaction processing logic
// 3. Handle Transaction Event (create / update)
if ($status !== 'Pending' || $status === 'Pending') {

    try {
        // Ambil transaksi + product
        /** @var PDO $pdo */
        $stmt = $pdo->prepare("
        SELECT 
            t.ref_id,
            t.status,
            t.rc,
            t.customer_no,
            t.command,
            t.id_user,
            t.selling_price,
            t.buyer_sku_code,
            t.price,
            t.sn,
            p.product_name,
            p.margin
        FROM transactions t
        LEFT JOIN products p 
            ON t.buyer_sku_code = p.buyer_sku_code
        WHERE t.ref_id = ?
    ");
        $stmt->execute([$ref_id]);
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($transaction) {
            // file_put_contents('digilog.txt', $ref_id . ' - ' . $event . ' - \n\n' . $post_data . PHP_EOL, FILE_APPEND);
            $id_user_order = $transaction['id_user'];
            $harga = $transaction['selling_price'];
            $product_name = $transaction['product_name'] ?? 'Produk tidak ditemukan';
            $customer_no = $transaction['customer_no'] ?? '';

            $old_status = $transaction['status'];
            $new_status = $status;

            $is_was_process = ($old_status !== 'Gagal');
            $is_now_failed  = ($new_status === 'Gagal');
            $is_valid_cmd   = in_array($transaction['command'], ['topup', 'pay-pasca']);

            $exist_price = isset($transaction['price']) ? $transaction['price'] : 0;
            $price = ($price > 0) ? $price : $exist_price;

            $exist_sn = isset($transaction['sn']) ? $transaction['sn'] : '';
            if (empty($sn)) {
                $sn = $exist_sn;
            }

            // =========================
            // INSERT REFUND (ANTI DOUBLE)
            // =========================
            if ($is_was_process && $is_now_failed && $is_valid_cmd) {
                try {
                    /** @var PDO $pdo */
                    $stmt = $pdo->prepare("
                    INSERT INTO refunds (ref_id, id_user, amount, reason, status, created_at)
                    VALUES (?, ?, ?, ?, 'Pending', NOW())
                ");
                    $stmt->execute([$ref_id, $id_user_order, $harga, $message]);
                } catch (PDOException $e) {
                    // duplicate → abaikan
                }
            }

            file_put_contents('digilog.txt', "DIBAWAH INSERT REFUND : " . $is_was_process . ' - ' . $is_now_failed . ' - ' . $is_valid_cmd . PHP_EOL, FILE_APPEND);
            // =========================
            // NOTIFIKASI
            // =========================
            if ($old_status !== $new_status && $new_status !== 'Pending') {

                $judul_notifikasi = "Transaksi " . $new_status;
                $pesan_notifikasi = $product_name . " " . $new_status . ". Cek detail transaksi pada aplikasi.";

                //file_put_contents('digilog.txt', "notifikasi : " . $id_user_order . ' Token : ' . $token_bo . PHP_EOL, FILE_APPEND);

                $headerBo =  array("Authorization: Bearer " . $token_bo);
                $post_body = array(
                    "id_user" => $id_user_order,
                    "judul_notifikasi" => $judul_notifikasi,
                    "pesan_notifikasi" => $pesan_notifikasi,
                );
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, "https://bukaolshop.net/api/v1/member/notifikasi");
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headerBo);
                curl_setopt($ch, CURLOPT_POST, TRUE);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post_body);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $response = curl_exec($ch);
                curl_close($ch);

                // LANGSUNG PAKAI $res
                $code = isset($response['code']) ? $response['code'] : 0;

                file_put_contents('refund_log.txt', "CODE REFUND: " . $code . " - Response: " . json_encode($response) . PHP_EOL, FILE_APPEND);

                if ($code && $code != 200) {
                    file_put_contents('notif_error.txt', curl_error($ch) . PHP_EOL, FILE_APPEND);
                } else {
                    file_put_contents('notif_log.txt', $response . PHP_EOL, FILE_APPEND);
                }

                curl_close($ch);


                // kirim notifikasi ke whatsapp via fonnte. ambil nomor hp user dari database. misal $user_phone
                /** @var PDO $pdo */
                $stmt = $pdo->prepare("SELECT nomor_telepon FROM Member WHERE id_user = ?");
                $stmt->execute([$id_user_order]);
                $user_phone = $stmt->fetchColumn();

                if ($user_phone) {
                    $message = "Transaksi PPOB\n\n" . "ID: " . $ref_id . "\nLayanan: " . $product_name . "\n\nTarget: " . $customer_no . "\nStatus: " . $new_status . "\nUpdate: " . date('Y-m-d H:i:s') . "\n\nSN:\n" . $sn;
                    $payload = [
                        'target' => $user_phone,
                        'message' => $message
                    ];
                    $ch = curl_init('https://api.fonnte.com/send');

                    curl_setopt_array($ch, [
                        CURLOPT_POST => true,
                        CURLOPT_POSTFIELDS => json_encode($payload),
                        CURLOPT_HTTPHEADER => [
                            'Authorization: ' . $token_fonnte,
                            'Content-Type: application/json'
                        ],
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_TIMEOUT => 30
                    ]);

                    $response = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

                    if (curl_errno($ch)) {
                        die('cURL Error: ' . curl_error($ch));
                    }
                }
            }

            // =========================
            // UPDATE TRANSAKSI
            // =========================
            $update_sql = "UPDATE transactions SET 
            status = ?, 
            message = ?, 
            rc = ?, 
            sn = ?";
            $update_params = [$status, $message, $rc, $sn];

            if (stripos($sn, 'TAG:') !== false) {
                $parsed_customer_name = '';
                $parsed_tag = 0;
                $parsed_admin = 0;
                $parsed_ttag = 0;

                if (preg_match('/^(.*?)\/TAG:/i', $sn, $m)) {
                    $parsed_customer_name = trim($m[1]);
                }
                if (preg_match('/TAG:(\d+)/i', $sn, $m)) {
                    $parsed_tag = (int)$m[1];
                }
                if (preg_match('/ADMIN:(\d+)/i', $sn, $m)) {
                    $parsed_admin = (int)$m[1];
                }
                if (preg_match('/TTAG:(\d+)/i', $sn, $m)) {
                    $parsed_ttag = (int)$m[1];
                } else {
                    $parsed_ttag = $parsed_tag + $parsed_admin;
                }

                $cur_command = $transaction['command'] ?? 'topup';
                $product_margin = isset($transaction['margin']) ? (int)$transaction['margin'] : 0;

                if ($cur_command === 'pay-pasca') {
                    $update_sql .= ", selling_price = ?, customer_name = ?, admin_fee = ?, price = ?";
                    $update_params[] = $parsed_ttag + $product_margin;
                    $update_params[] = $parsed_customer_name;
                    $update_params[] = $parsed_admin;
                    $update_params[] = $parsed_ttag;
                } else {
                    $update_sql .= ", selling_price = ?, customer_name = ?, admin_fee = ?, price = ?";
                    $update_params[] = $parsed_ttag;
                    $update_params[] = $parsed_customer_name;
                    $update_params[] = $parsed_admin;
                    $update_params[] = $parsed_ttag;
                }
            } else {
                $update_sql .= ", price = ?";
                $update_params[] = $price;
            }

            $update_sql .= " WHERE ref_id = ?";
            $update_params[] = $ref_id;

            $stmt = $pdo->prepare($update_sql);
            $stmt->execute($update_params);

            // =========================
            // RESPOND CEPAT KE OKECONNECT
            // =========================
            http_response_code(200);
            echo json_encode(['status' => 'success']);

            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            }

            sendTelegramNotif($pdo, $ref_id, $new_status, $sn);

            // =========================
            // DELAY WAJIB 
            // =========================
            sleep(6);

            // =========================
            // LOCK REFUND (ANTI DOUBLE PROCESS)
            // =========================
            $stmt = $pdo->prepare("
                UPDATE refunds 
                SET status = 'Processing' 
                WHERE ref_id = ? AND status = 'Pending'
            ");
            $stmt->execute([$ref_id]);

            if ($stmt->rowCount() > 0) {

                // ambil data refund
                $stmt = $pdo->prepare("SELECT * FROM refunds WHERE ref_id = ?");
                $stmt->execute([$ref_id]);
                $refund = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($refund && $id_user_order) {

                    $res = updateSaldoMember(
                        $refund['id_user'],
                        "tambah",
                        $refund['amount'],
                        "REFUND " . $product_name,
                        $token_bo
                    );

                    // LANGSUNG PAKAI $res
                    $code = isset($res['code']) ? $res['code'] : 0;

                    file_put_contents('refund_log.txt', "CODE REFUND: " . $code . " - Response: " . json_encode($res) . PHP_EOL, FILE_APPEND);

                    file_put_contents('refund_log.txt', "CODE REFUND: " . $code . " - Response: " . $res . PHP_EOL, FILE_APPEND);

                    if ($code && $code == 200) {
                        $pdo->prepare("UPDATE refunds SET status = 'Success' WHERE ref_id = ?")
                            ->execute([$ref_id]);

                        // debug apakah berhasil update atau gagal
                        $stmt = $pdo->prepare("SELECT * FROM refunds WHERE ref_id = ?");
                        $stmt->execute([$ref_id]);
                        $updated_refund = $stmt->fetch(PDO::FETCH_ASSOC);

                        if ($updated_refund) {
                            file_put_contents('refund_log.txt', "UPDATE REFUND: " . json_encode($updated_refund) . PHP_EOL, FILE_APPEND);
                        }
                    } else {

                        $pdo->prepare("UPDATE refunds SET status = 'Failed' WHERE ref_id = ?")
                            ->execute([$ref_id]);
                    }

                    file_put_contents('refund_log.txt', "FINAL REFUND: " . json_encode($refund) . PHP_EOL, FILE_APPEND);
                }
            }
        } else {
            
            $forward_url = 'https://bukaolshop.net/callback/okeconnect/event';

                $ch = curl_init($forward_url);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                curl_exec($ch);
                curl_close($ch);

                http_response_code(200);
                echo json_encode(['status' => 'forwarded']);
                exit;
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
}

