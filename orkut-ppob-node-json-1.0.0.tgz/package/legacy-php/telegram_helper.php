<?php
// ==========================================
// CENTRAL TELEGRAM HELPER FOR DASHBOARD LOGIN
// ==========================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- CONFIGURATION ---
// Silakan tulis token bot Telegram dan chat ID Anda secara hardcode di sini:
define('TELEGRAM_BOT_TOKEN', '');
define('TELEGRAM_CHAT_ID', '');

// --- DEBUG LOGGER HELPER ---
function telegram_write_debug($message) {
    try {
        $file_path = __DIR__ . '/debug_verif_tele.txt';
        $timestamp = date('[Y-m-d H:i:s]');
        $log_entry = "{$timestamp} {$message}\n";
        file_put_contents($file_path, $log_entry, FILE_APPEND);
    } catch (Exception $e) {}
}

// --- DATABASE HELPER ---
// --- DATABASE HELPER ---
function telegram_get_pdo() {
    global $pdo, $conn;

    if (isset($pdo) && $pdo instanceof PDO) {
        return $pdo;
    }

    if (isset($conn) && $conn instanceof PDO) {
        return $conn;
    }

    return null;
}

function telegram_init_db($db) {
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS login_confirmations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            token VARCHAR(64) NOT NULL UNIQUE,
            username VARCHAR(100) NOT NULL,
            ip_address VARCHAR(45) NOT NULL,
            user_agent VARCHAR(255) NOT NULL,
            location VARCHAR(255) NOT NULL,
            new_device_token_hash VARCHAR(255) NOT NULL,
            otp_code VARCHAR(10) NOT NULL,
            status VARCHAR(20) DEFAULT 'pending', -- pending, approved, rejected
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX(token),
            INDEX(otp_code)
        )");
    } catch (Exception $e) {
        // telegram_write_debug("DB_ERROR: Gagal inisialisasi tabel login_confirmations - " . $e->getMessage());
    }
}

// --- COOKIE UTILITY ---
function telegram_set_device_cookie($token) {
    // telegram_write_debug("COOKIE: Set cookie baru 'admin_device_token' untuk otentikasi otomatis.");
    $is_secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    
    if (PHP_VERSION_ID >= 70300) {
        setcookie('admin_device_token', $token, [
            'expires' => time() + (365 * 24 * 60 * 60),
            'path' => '/',
            'domain' => '',
            'secure' => $is_secure,
            'httponly' => true,
            'samesite' => $is_secure ? 'None' : 'Lax'
        ]);
    } else {
        // Fallback untuk versi PHP lama dengan manipulasi header
        $header = "Set-Cookie: admin_device_token=" . urlencode($token) . "; Max-Age=" . (365 * 24 * 60 * 60) . "; Path=/; HttpOnly";
        if ($is_secure) {
            $header .= "; Secure; SameSite=None";
        } else {
            $header .= "; SameSite=Lax";
        }
        header($header, false);
    }
}

// --- TELEGRAM API HELPERS ---
function telegram_send_notif($token, $otp, $username, $ip, $location, $ua) {
    $token_bot = TELEGRAM_BOT_TOKEN;
    $chat_id = TELEGRAM_CHAT_ID;
    
    // telegram_write_debug("SEND_NOTIF_START: Mengirim OTP ke Telegram. User: {$username} | IP: {$ip} | OTP: {$otp}");
    
    if (empty($token_bot) || $token_bot === 'YOUR_BOT_TOKEN_HERE') {
        // telegram_write_debug("SEND_NOTIF_ERROR: Token Bot Telegram kosong atau default.");
        return false;
    }
    if (empty($chat_id) || $chat_id === 'YOUR_CHAT_ID_HERE') {
        // telegram_write_debug("SEND_NOTIF_ERROR: Chat ID Telegram kosong atau default.");
        return false;
    }
    
    // Ambil detail User Agent yang ringkas
    $short_ua = 'Unknown';
    if (!empty($ua)) {
        if (strpos($ua, 'Windows') !== false) $short_ua = 'Windows';
        elseif (strpos($ua, 'iPhone') !== false) $short_ua = 'iPhone (iOS)';
        elseif (strpos($ua, 'iPad') !== false) $short_ua = 'iPad (iOS)';
        elseif (strpos($ua, 'Android') !== false) $short_ua = 'Android';
        elseif (strpos($ua, 'Macintosh') !== false) $short_ua = 'Mac (OS X)';
        elseif (strpos($ua, 'Linux') !== false) $short_ua = 'Linux';
    }
    
    // Gunakan HTML parse_mode agar lebih tangguh terhadap karakter spesial seperti _ atau ( ) dll.
    $safe_username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
    $safe_ip = htmlspecialchars($ip, ENT_QUOTES, 'UTF-8');
    $safe_location = htmlspecialchars($location, ENT_QUOTES, 'UTF-8');
    $safe_short_ua = htmlspecialchars($short_ua, ENT_QUOTES, 'UTF-8');
    $safe_otp = htmlspecialchars($otp, ENT_QUOTES, 'UTF-8');
    
    $message = "⚠️ <b>PERCOBAAN LOGIN DASHBOARD</b>\n\n"
             . "👤 <b>Username:</b> <code>{$safe_username}</code>\n"
             . "🌐 <b>IP Address:</b> <code>{$safe_ip}</code>\n"
             . "📍 <b>Lokasi:</b> <code>{$safe_location}</code>\n"
             . "🖥️ <b>Perangkat:</b> <code>{$safe_short_ua}</code>\n\n"
             . "🔑 <b>KODE OTP:</b> <code>{$safe_otp}</code>\n\n"
             . "Masukkan kode OTP di atas pada halaman verifikasi login, atau klik tombol <b>Setujui</b> di bawah ini untuk mengizinkan otomatis.";
    
    // PERBAIKAN: Telegram inline_keyboard callback_data maksimal 64 byte.
    // "approve_" + token (64 karakter hex dari random_bytes(32) = 64 byte) = 72 byte (gagal/BUTTON_DATA_INVALID).
    // Kita pangkas token di callback_data atau gunakan substring, misal ambil 32 karakter pertama saja (16 bytes awal).
    // Karena token tetap unik dan aman meskipun 32 karakter pertama (dari random_bytes(32)).
    $short_token = substr($token, 0, 32);
             
    $keyboard = [
        'inline_keyboard' => [
            [
                ['text' => '✅ Setujui', 'callback_data' => "approve_{$short_token}"],
                ['text' => '❌ Tolak', 'callback_data' => "reject_{$short_token}"]
            ]
        ]
    ];
    
    $payload = [
        'chat_id' => $chat_id,
        'text' => $message,
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode($keyboard)
    ];
    
    $ch = curl_init("https://api.telegram.org/bot{$token_bot}/sendMessage");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    // Bypassing SSL validation for maximum resilience on all hosting setups
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    $res = curl_exec($ch);
    $curl_err = curl_error($ch);
    $curl_info = curl_getinfo($ch);
    $http_code = $curl_info['http_code'] ?? 0;
    curl_close($ch);
    
    if ($res === false) {
        // telegram_write_debug("SEND_NOTIF_ERROR: Curl gagal dilaksanakan. Error: {$curl_err}");
    } else {
        $res_decoded = json_decode($res, true);
        if (isset($res_decoded['ok']) && $res_decoded['ok'] === true) {
            // telegram_write_debug("SEND_NOTIF_SUCCESS: Pengiriman sukses! Msg ID: " . ($res_decoded['result']['message_id'] ?? 'unknown'));
        } else {
            // // telegram_write_debug("SEND_NOTIF_FAILED: API Telegram mengembalikan error - Response: {$res}");
        }
    }
    
    return $res;
}

function telegram_answer_callback($callback_id, $text) {
    $token_bot = TELEGRAM_BOT_TOKEN;
    $payload = [
        'callback_query_id' => $callback_id,
        'text' => $text
    ];
    // // telegram_write_debug("CALLBACK_ANSWER: Menjawab callback {$callback_id} dengan pesan: '{$text}'");
    
    $ch = curl_init("https://api.telegram.org/bot{$token_bot}/answerCallbackQuery");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_exec($ch);
    curl_close($ch);
}

function telegram_edit_message($chat_id, $message_id, $text) {
    $token_bot = TELEGRAM_BOT_TOKEN;
    $payload = [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    // // telegram_write_debug("EDIT_MESSAGE: Mengubah isi pesan Chat ID: {$chat_id} | Msg ID: {$message_id}");
    
    $ch = curl_init("https://api.telegram.org/bot{$token_bot}/editMessageText");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_exec($ch);
    curl_close($ch);
}

// --- POLLING & WEBHOOK ENDPOINTS ---

// 0. Endpoint untuk melihat log debug secara langsung di browser
if (isset($_GET['view_debug'])) {
    header('Content-Type: text/plain; charset=utf-8');
    $file_path = __DIR__ . '/debug_verif_tele.txt';
    if (file_exists($file_path)) {
        echo file_get_contents($file_path);
    } else {
        echo "Log file debug_verif_tele.txt belum dibuat. Silakan coba login terlebih dahulu.";
    }
    exit;
}

// 1. Endpoint Polling untuk Halaman Login
if (isset($_GET['check_confirmation'])) {
    header('Content-Type: application/json');
    $token = $_GET['check_confirmation'] ?? '';
    $pdo = telegram_get_pdo();
    if ($pdo && !empty($token)) {
        $stmt = $pdo->prepare("SELECT status FROM login_confirmations WHERE token = ?");
        $stmt->execute([$token]);
        $status = $stmt->fetchColumn();
        echo json_encode(['status' => $status ?: 'not_found']);
    } else {
        echo json_encode(['status' => 'db_error']);
    }
    exit;
}

// 2. Endpoint Webhook untuk Telegram Bot
if (isset($_GET['webhook']) || (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false)) {
    $content = file_get_contents("php://input");
    $update = json_decode($content, true);
    
    if (isset($update['callback_query'])) {
        $callback = $update['callback_query'];
        $data = $callback['data'];
        $callback_id = $callback['id'];
        $chat_id = $callback['message']['chat']['id'];
        $message_id = $callback['message']['message_id'];
        
        $pdo = telegram_get_pdo();
        if ($pdo) {
            telegram_init_db($pdo);
            
            if (strpos($data, 'approve_') === 0) {
                $token_part = substr($data, 8);
                
                // Cari menggunakan prefix LIKE karena token di DB mungkin 64 karakter sedangkan callback_data mengirim 32 karakter pertama
                $stmt = $pdo->prepare("SELECT * FROM login_confirmations WHERE token LIKE ?");
                $stmt->execute([$token_part . '%']);
                $conf = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($conf) {
                    $full_token = $conf['token'];
                    if ($conf['status'] === 'pending') {
                        $stmt = $pdo->prepare("UPDATE login_confirmations SET status = 'approved' WHERE token = ?");
                        $stmt->execute([$full_token]);
                        
                        telegram_answer_callback($callback_id, "Login telah disetujui!");
                        
                        $safe_username = htmlspecialchars($conf['username'] ?? '', ENT_QUOTES, 'UTF-8');
                        $safe_ip = htmlspecialchars($conf['ip_address'] ?? '', ENT_QUOTES, 'UTF-8');
                        $safe_location = htmlspecialchars($conf['location'] ?? '', ENT_QUOTES, 'UTF-8');
                        $ua = $conf['user_agent'] ?? '';
                        $short_ua = 'Unknown';
                        if (!empty($ua)) {
                            if (strpos($ua, 'Windows') !== false) $short_ua = 'Windows';
                            elseif (strpos($ua, 'iPhone') !== false) $short_ua = 'iPhone (iOS)';
                            elseif (strpos($ua, 'iPad') !== false) $short_ua = 'iPad (iOS)';
                            elseif (strpos($ua, 'Android') !== false) $short_ua = 'Android';
                            elseif (strpos($ua, 'Macintosh') !== false) $short_ua = 'Mac (OS X)';
                            elseif (strpos($ua, 'Linux') !== false) $short_ua = 'Linux';
                        }
                        $safe_short_ua = htmlspecialchars($short_ua, ENT_QUOTES, 'UTF-8');
                        $safe_otp = htmlspecialchars($conf['otp_code'] ?? '', ENT_QUOTES, 'UTF-8');
                        
                        $new_text = "⚠️ <b>PERCOBAAN LOGIN DASHBOARD</b>\n\n"
                                  . "👤 <b>Username:</b> <code>{$safe_username}</code>\n"
                                  . "🌐 <b>IP Address:</b> <code>{$safe_ip}</code>\n"
                                  . "📍 <b>Lokasi:</b> <code>{$safe_location}</code>\n"
                                  . "🖥️ <b>Perangkat:</b> <code>{$safe_short_ua}</code>\n\n"
                                  . "🔑 <b>KODE OTP:</b> <code>{$safe_otp}</code>\n\n"
                                  . "✅ <b>DISETUJUI OLEH OWNER</b>";
                                  
                        telegram_edit_message($chat_id, $message_id, $new_text);
                    } else {
                        telegram_answer_callback($callback_id, "Sudah diproses sebelumnya (" . $conf['status'] . ")");
                    }
                } else {
                    telegram_answer_callback($callback_id, "Sesi tidak ditemukan.");
                }
            } elseif (strpos($data, 'reject_') === 0) {
                $token_part = substr($data, 7);
                
                // Cari menggunakan prefix LIKE karena token di DB mungkin 64 karakter sedangkan callback_data mengirim 32 karakter pertama
                $stmt = $pdo->prepare("SELECT * FROM login_confirmations WHERE token LIKE ?");
                $stmt->execute([$token_part . '%']);
                $conf = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($conf) {
                    $full_token = $conf['token'];
                    if ($conf['status'] === 'pending') {
                        $stmt = $pdo->prepare("UPDATE login_confirmations SET status = 'rejected' WHERE token = ?");
                        $stmt->execute([$full_token]);
                        
                        telegram_answer_callback($callback_id, "Login telah ditolak!");
                        
                        $safe_username = htmlspecialchars($conf['username'] ?? '', ENT_QUOTES, 'UTF-8');
                        $safe_ip = htmlspecialchars($conf['ip_address'] ?? '', ENT_QUOTES, 'UTF-8');
                        $safe_location = htmlspecialchars($conf['location'] ?? '', ENT_QUOTES, 'UTF-8');
                        $ua = $conf['user_agent'] ?? '';
                        $short_ua = 'Unknown';
                        if (!empty($ua)) {
                            if (strpos($ua, 'Windows') !== false) $short_ua = 'Windows';
                            elseif (strpos($ua, 'iPhone') !== false) $short_ua = 'iPhone (iOS)';
                            elseif (strpos($ua, 'iPad') !== false) $short_ua = 'iPad (iOS)';
                            elseif (strpos($ua, 'Android') !== false) $short_ua = 'Android';
                            elseif (strpos($ua, 'Macintosh') !== false) $short_ua = 'Mac (OS X)';
                            elseif (strpos($ua, 'Linux') !== false) $short_ua = 'Linux';
                        }
                        $safe_short_ua = htmlspecialchars($short_ua, ENT_QUOTES, 'UTF-8');
                        $safe_otp = htmlspecialchars($conf['otp_code'] ?? '', ENT_QUOTES, 'UTF-8');
                        
                        $new_text = "⚠️ <b>PERCOBAAN LOGIN DASHBOARD</b>\n\n"
                                  . "👤 <b>Username:</b> <code>{$safe_username}</code>\n"
                                  . "🌐 <b>IP Address:</b> <code>{$safe_ip}</code>\n"
                                  . "📍 <b>Lokasi:</b> <code>{$safe_location}</code>\n"
                                  . "🖥️ <b>Perangkat:</b> <code>{$safe_short_ua}</code>\n\n"
                                  . "🔑 <b>KODE OTP:</b> <code>{$safe_otp}</code>\n\n"
                                  . "❌ <b>DITOLAK OLEH OWNER</b>";
                                  
                        telegram_edit_message($chat_id, $message_id, $new_text);
                    } else {
                        telegram_answer_callback($callback_id, "Sudah diproses sebelumnya (" . $conf['status'] . ")");
                    }
                } else {
                    telegram_answer_callback($callback_id, "Sesi tidak ditemukan.");
                }
            }
        } else {
            telegram_answer_callback($callback_id, "Gagal koneksi ke database.");
        }
        exit;
    }
}

// --- INTERCEPTOR: TAMPILKAN LAYAR VERIFIKASI JIKA ADA PENDING VERIFICATION ---
if (isset($_SESSION['pending_verification_token'])) {
    $pending_token = $_SESSION['pending_verification_token'];
    $pending_user = $_SESSION['pending_verification_user'];
    $pending_table = $_SESSION['pending_verification_table'];
    $pending_redirect = $_SESSION['pending_verification_redirect'] ?? '?';
    
    // Dapatkan koneksi PDO
    $db_connection = telegram_get_pdo();
    
    $login_msg = '';
    if ($db_connection) {
        telegram_init_db($db_connection);
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_otp'])) {
            $entered_otp = trim($_POST['otp_code'] ?? '');
            
            $stmt = $db_connection->prepare("SELECT * FROM login_confirmations WHERE token = ? AND otp_code = ? AND status = 'pending'");
            $stmt->execute([$pending_token, $entered_otp]);
            $match = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($match) {
                $stmt = $db_connection->prepare("UPDATE login_confirmations SET status = 'approved' WHERE token = ?");
                $stmt->execute([$pending_token]);
            } else {
                $login_msg = "<div style='color:#fca5a5;background:rgba(239,68,68,0.1);padding:12px;border-radius:10px;border:1px solid rgba(239,68,68,0.2);margin-bottom:20px;font-size:14px;text-align:center;'>Kode OTP salah atau telah kadaluarsa!</div>";
            }
        }
        
        // Cek status terbaru
        $stmt = $db_connection->prepare("SELECT * FROM login_confirmations WHERE token = ?");
        $stmt->execute([$pending_token]);
        $conf_row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($conf_row && $conf_row['status'] === 'approved') {
            // Setujui Login! Update allowed_device_token dan allowed_location
            $new_device_token_hash = $conf_row['new_device_token_hash'];
            $user_agent = $conf_row['user_agent'];
            $current_location = $conf_row['location'];
            
            // Simpan ke database target
            $stmt = $db_connection->prepare("UPDATE `{$pending_table}` SET allowed_device_token = ?, allowed_user_agent = ?, allowed_location = ? WHERE username = ?");
            $stmt->execute([$new_device_token_hash, $user_agent, $current_location, $pending_user]);
            
            // Pasang cookie di browser
            $new_device_token = $_SESSION['pending_new_device_token'];
            telegram_set_device_cookie($new_device_token);
            
            // Daftarkan session login admin
            $_SESSION['admin_logged_in'] = true;
            
            // Ambil data admin lengkap untuk sinkronisasi session id & name
            $stmt = $db_connection->prepare("SELECT * FROM `{$pending_table}` WHERE username = ?");
            $stmt->execute([$pending_user]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $_SESSION['admin_id'] = $admin['id'] ?? $admin['id_riwayat'] ?? 1;
            $_SESSION['admin_name'] = $admin['username'];
            $_SESSION['admin_user'] = $admin['username'];
            $_SESSION['admin_role'] = $admin['role'] ?? 'admin';
            
            // Bersihkan session pending
            unset($_SESSION['pending_verification_token']);
            unset($_SESSION['pending_verification_user']);
            unset($_SESSION['pending_verification_table']);
            unset($_SESSION['pending_verification_redirect']);
            unset($_SESSION['pending_new_device_token']);
            
            header("Location: {$pending_redirect}");
            exit;
        } elseif ($conf_row && $conf_row['status'] === 'rejected') {
            $login_msg = "<div style='color:#fca5a5;background:rgba(239,68,68,0.1);padding:12px;border-radius:10px;border:1px solid rgba(239,68,68,0.2);margin-bottom:20px;font-size:14px;text-align:center;'>Login ditolak via Telegram.</div>";
            unset($_SESSION['pending_verification_token']);
        }
    } else {
        $login_msg = "<div style='color:#fca5a5;background:rgba(239,68,68,0.1);padding:12px;border-radius:10px;border:1px solid rgba(239,68,68,0.2);margin-bottom:20px;font-size:14px;text-align:center;'>Gagal menghubungkan ke database keamanan.</div>";
    }
    
    // Render Layar Verifikasi
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verifikasi Keamanan - Telegram OTP</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
        <style>body{font-family:'Plus Jakarta Sans',sans-serif;}</style>
    </head>
    <body class="bg-slate-900 flex items-center justify-center min-h-screen p-4 relative overflow-hidden">
        <div class="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
            <div class="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-indigo-600 rounded-full blur-[120px] opacity-20"></div>
            <div class="absolute bottom-[0%] right-[0%] w-[40%] h-[40%] bg-blue-500 rounded-full blur-[100px] opacity-20"></div>
        </div>
        <div class="bg-white/10 backdrop-blur-lg border border-white/20 p-8 rounded-2xl shadow-2xl w-full max-w-md relative z-10 text-white">
            <div class="text-center mb-6">
                <div class="w-16 h-16 bg-indigo-600/30 text-indigo-400 rounded-full flex items-center justify-center mx-auto mb-4 border border-indigo-500/30">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                </div>
                <h1 class="text-xl font-bold tracking-tight">Verifikasi Keamanan</h1>
                <p class="text-slate-400 text-sm mt-1">Kami mendeteksi perangkat atau lokasi login baru untuk mengamankan akun Anda.</p>
            </div>
            
            <?= $login_msg ?>
            
            <div class="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4 mb-6 text-sm text-slate-300 space-y-2">
                <div class="flex justify-between"><span class="text-slate-400">Username:</span> <span class="font-semibold text-white"><?= htmlspecialchars($pending_user) ?></span></div>
                <div class="flex justify-between"><span class="text-slate-400">IP Address:</span> <span class="font-mono text-white"><?= htmlspecialchars($conf_row['ip_address'] ?? '') ?></span></div>
                <div class="flex justify-between"><span class="text-slate-400">Lokasi:</span> <span class="text-white"><?= htmlspecialchars($conf_row['location'] ?? '') ?></span></div>
            </div>
            
            <form method="POST" class="space-y-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-300 uppercase mb-2">Kode OTP Telegram</label>
                    <input type="text" name="otp_code" class="w-full bg-slate-800/50 border border-slate-700 text-white rounded-lg px-4 py-3 text-center text-xl font-bold tracking-widest focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all placeholder-slate-600" placeholder="••••••" autocomplete="off" required>
                </div>
                <button type="submit" name="verify_otp" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 rounded-lg shadow-lg hover:shadow-indigo-500/30 transition-all duration-200">
                    Verifikasi Kode
                </button>
            </form>
            
            <div class="mt-6 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800 pt-4">
                <div class="flex items-center gap-1.5">
                    <span class="flex h-2 w-2 relative">
                      <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    Menunggu konfirmasi Telegram...
                </div>
                <a href="?action=logout" class="text-slate-400 hover:text-red-400 font-medium">Batal</a>
            </div>
        </div>
        
        <script>
            // Polling otomatis tiap 2.5 detik untuk mengecek apakah persetujuan disetujui via tombol Telegram
            setInterval(function() {
                fetch('telegram_helper.php?check_confirmation=<?= $pending_token ?>')
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'approved') {
                            window.location.reload();
                        } else if (data.status === 'rejected') {
                            window.location.href = '?action=logout';
                        }
                    })
                    .catch(err => console.error(err));
            }, 2500);
        </script>
    </body>
    </html>
    <?php
    exit;
}
