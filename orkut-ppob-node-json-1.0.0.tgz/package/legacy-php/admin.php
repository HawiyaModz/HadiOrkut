<?php
session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/telegram_helper.php';

// ==========================================
// SECURITY UTILITIES (ANTI-BRUTEFORCE, ALLOW DEVICE, ALLOW LOCATION)
// ==========================================
if (!function_exists('sec_get_client_ip')) {
    function sec_get_client_ip() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ips[0]);
        } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        return $ip;
    }
}

if (!function_exists('sec_get_ip_location')) {
    function sec_get_ip_location($ip) {
        if ($ip === '127.0.0.1' || $ip === '::1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0) {
            return 'Local|Local|Local';
        }
        $url = "http://ip-api.com/json/" . urlencode($ip);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 3);
        $res = curl_exec($ch);
        curl_close($ch);
        if ($res) {
            $data = json_decode($res, true);
            if (isset($data['status']) && $data['status'] === 'success') {
                $city = $data['city'] ?? 'Unknown';
                $region = $data['regionName'] ?? 'Unknown';
                $country = $data['country'] ?? 'Unknown';
                return "{$city}|{$region}|{$country}";
            }
        }
        return 'Unknown|Unknown|Unknown';
    }
}

if (!function_exists('sec_parse_location')) {
    function sec_parse_location($loc_str) {
        $res = [
            'lat' => null,
            'lng' => null,
            'kecamatan' => '',
            'city' => '',
            'state' => '',
            'country' => ''
        ];
        if (empty($loc_str)) return $res;
        
        $parts = explode('|', $loc_str);
        $first = trim($parts[0] ?? '');
        if (strpos($first, ',') !== false) {
            $coords = explode(',', $first);
            if (count($coords) === 2 && is_numeric($coords[0]) && is_numeric($coords[1])) {
                $res['lat'] = (float)$coords[0];
                $res['lng'] = (float)$coords[1];
            }
            array_shift($parts);
        }
        
        $res['kecamatan'] = trim($parts[0] ?? '');
        $res['city'] = trim($parts[1] ?? '');
        $res['state'] = trim($parts[2] ?? '');
        $res['country'] = trim($parts[3] ?? '');
        
        return $res;
    }
}

if (!function_exists('sec_is_location_allowed')) {
    function sec_is_location_allowed($allowed, $current) {
        if (empty($allowed) || $allowed === 'Unknown|Unknown|Unknown') return true;
        if (empty($current) || $current === 'Unknown|Unknown|Unknown') return true;
        
        $a = sec_parse_location($allowed);
        $c = sec_parse_location($current);
        
        // 1. Try GPS Distance if coordinates exist
        if ($a['lat'] !== null && $a['lng'] !== null && $c['lat'] !== null && $c['lng'] !== null) {
            $earth_radius = 6371; // km
            $dLat = deg2rad($c['lat'] - $a['lat']);
            $dLon = deg2rad($c['lng'] - $a['lng']);
            $val = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($a['lat'])) * cos(deg2rad($c['lat'])) * sin($dLon/2) * sin($dLon/2);
            $dist = $earth_radius * 2 * atan2(sqrt($val), sqrt(1-$val));
            
            // Within 25 km covers Kecamatan/City
            if ($dist <= 25) {
                return true;
            }
        }
        
        // 2. Fallback to loose matching
        if (!empty($a['country']) && !empty($c['country'])) {
            if (strcasecmp($a['country'], $c['country']) !== 0) return false;
        }
        
        // Match Kecamatan
        if (!empty($a['kecamatan']) && !empty($c['kecamatan'])) {
            if (stripos($a['kecamatan'], $c['kecamatan']) !== false || stripos($c['kecamatan'], $a['kecamatan']) !== false) {
                return true;
            }
        }
        
        // Match City
        if (!empty($a['city']) && !empty($c['city'])) {
            if (stripos($a['city'], $c['city']) !== false || stripos($c['city'], $a['city']) !== false) {
                return true;
            }
        }
        
        // Match State
        if (!empty($a['state']) && !empty($c['state'])) {
            if (stripos($a['state'], $c['state']) !== false || stripos($c['state'], $a['state']) !== false) {
                return true;
            }
        }
        
        if (strcasecmp($allowed, $current) === 0) {
            return true;
        }
        
        return false;
    }
}

if (!function_exists('sec_init_db')) {
    function sec_init_db($conn, $table) {
        $conn->exec("CREATE TABLE IF NOT EXISTS login_attempts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            ip_address VARCHAR(45) NOT NULL,
            username VARCHAR(100) NOT NULL,
            attempt_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX (ip_address, attempt_time),
            INDEX (username, attempt_time)
        )");
        try { $conn->exec("ALTER TABLE `{$table}` ADD COLUMN allowed_device_token VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
        try { $conn->exec("ALTER TABLE `{$table}` ADD COLUMN allowed_user_agent VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
        try { $conn->exec("ALTER TABLE `{$table}` ADD COLUMN allowed_location VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
    }
}

if (isset($pdo) && $pdo) {
    sec_init_db($pdo, 'admins');
}

// Handle Logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// Handle Login
$login_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($pdo) {
        $ip = sec_get_client_ip();

        // Check Brute Force
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM login_attempts WHERE (ip_address = ? OR username = ?) AND attempt_time > NOW() - INTERVAL 10 MINUTE");
        $stmt->execute([$ip, $username]);
        if ($stmt->fetchColumn() >= 5) {
            $login_error = "Terlalu banyak percobaan login. IP atau Username diblokir sementara selama 10 menit.";
        } else {
            $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
            $stmt->execute([$username]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($admin && password_verify($password, $admin['password'])) {
                $gps_loc = trim($_POST['gps_location'] ?? '');
                $current_location = !empty($gps_loc) ? $gps_loc : sec_get_ip_location($ip);
                $allowed_token_hash = $admin['allowed_device_token'] ?? null;
                $allowed_location = $admin['allowed_location'] ?? null;
                $device_cookie = $_COOKIE['admin_device_token'] ?? '';
                $login_allowed = true;

                if (!empty($allowed_token_hash)) {
                    $cookie_matches = !empty($device_cookie) && hash_equals($allowed_token_hash, hash('sha256', $device_cookie));
                    $location_matches = sec_is_location_allowed($allowed_location, $current_location);
                    
                    if (!$cookie_matches || !$location_matches) {
                        if (defined('TELEGRAM_BOT_TOKEN') && TELEGRAM_BOT_TOKEN !== 'YOUR_BOT_TOKEN_HERE' && !empty(TELEGRAM_BOT_TOKEN)) {
                            $confirm_token = bin2hex(random_bytes(32));
                            $new_device_token = bin2hex(random_bytes(32));
                            $new_token_hash = hash('sha256', $new_device_token);
                            $otp_code = strval(rand(100000, 999999));
                            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
                            
                            telegram_init_db($pdo);
                            
                            $stmt = $pdo->prepare("INSERT INTO login_confirmations (token, username, ip_address, user_agent, location, new_device_token_hash, otp_code, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
                            $stmt->execute([$confirm_token, $username, $ip, $user_agent, $current_location, $new_token_hash, $otp_code]);
                            
                            telegram_send_notif($confirm_token, $otp_code, $username, $ip, $current_location, $user_agent);
                            
                            $_SESSION['pending_verification_token'] = $confirm_token;
                            $_SESSION['pending_verification_user'] = $username;
                            $_SESSION['pending_verification_table'] = 'admins';
                            $_SESSION['pending_verification_redirect'] = 'admin.php';
                            $_SESSION['pending_verification_db_var'] = 'pdo';
                            $_SESSION['pending_new_device_token'] = $new_device_token;
                            
                            header("Location: ?");
                            exit;
                        } else {
                            if (!$cookie_matches) {
                                $stmt = $pdo->prepare("INSERT INTO login_attempts (ip_address, username) VALUES (?, ?)");
                                $stmt->execute([$ip, $username]);
                                $login_error = "Akses ditolak: Perangkat tidak dikenali. Login hanya diperbolehkan dari perangkat pertama yang terdaftar.";
                                $login_allowed = false;
                            } elseif (!$location_matches) {
                                $stmt = $pdo->prepare("INSERT INTO login_attempts (ip_address, username) VALUES (?, ?)");
                                $stmt->execute([$ip, $username]);
                                $login_error = "Akses ditolak: Lokasi login tidak sah ({$current_location}).";
                                $login_allowed = false;
                            }
                        }
                    }
                } else {
                    // Register Device & Location
                    $new_device_token = bin2hex(random_bytes(32));
                    $new_token_hash = hash('sha256', $new_device_token);
                    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
                    
                    $stmt = $pdo->prepare("UPDATE admins SET allowed_device_token = ?, allowed_user_agent = ?, allowed_location = ? WHERE id = ?");
                    $stmt->execute([$new_token_hash, $user_agent, $current_location, $admin['id']]);
                    
                    telegram_set_device_cookie($new_device_token);
                }

                if ($login_allowed) {
                    $_SESSION['admin_logged_in'] = true;
                    header("Location: admin.php");
                    exit;
                }
            } else {
                $stmt = $pdo->prepare("INSERT INTO login_attempts (ip_address, username) VALUES (?, ?)");
                $stmt->execute([$ip, $username]);
                $login_error = 'Username atau password salah!';
            }
        }
    } else {
        $login_error = 'Koneksi database gagal. Cek db.php';
    }
}

$isLoggedIn = !empty($_SESSION['admin_logged_in']);

// Handle API Endpoints
if ($isLoggedIn && isset($_GET['action']) && $_GET['action'] !== 'logout') {
    header('Content-Type: application/json');
    $action = $_GET['action'];

    if (!$pdo) {
        echo json_encode(['error' => 'Koneksi database gagal: ' . ($db_setup_error ?? 'Unknown error')]);
        exit;
    }

    // Auto-create memberships & membership_prices tables if they do not exist
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS memberships (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS membership_prices (
            id INT AUTO_INCREMENT PRIMARY KEY,
            membership_name VARCHAR(100) NOT NULL,
            buyer_sku_code VARCHAR(100) NOT NULL,
            price_adjustment INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_membership_sku (membership_name, buyer_sku_code)
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS Member (
            id INT AUTO_INCREMENT PRIMARY KEY,
            id_user VARCHAR(11) DEFAULT NULL,
            nama_user VARCHAR(255) DEFAULT NULL,
            nomor_telepon VARCHAR(20) DEFAULT NULL,
            paylater VARCHAR(10) NOT NULL DEFAULT 'tidak',
            `limit` INT NOT NULL DEFAULT 0,
            sisa_pinjaman INT NOT NULL DEFAULT 0,
            total_pinjaman INT NOT NULL DEFAULT 0,
            total_bayar INT NOT NULL DEFAULT 0,
            email_user VARCHAR(255) DEFAULT NULL,
            saldo_user INT DEFAULT 0,
            jumlah_transaksi INT NOT NULL DEFAULT 0,
            nama_membership VARCHAR(255) NOT NULL DEFAULT 'Umum',
            poin_member INT NOT NULL DEFAULT 0,
            last_login DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            restricted_products TEXT DEFAULT NULL,
            UNIQUE KEY uq_id_user (id_user)
        ) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

        // check if column restricted_products exists
        $qCol = $pdo->query("SHOW COLUMNS FROM Member LIKE 'restricted_products'");
        if ($qCol->rowCount() === 0) {
            $pdo->exec("ALTER TABLE Member ADD COLUMN restricted_products TEXT DEFAULT NULL");
        }
    } catch (PDOException $e) {
        // Log error silently
    }

    if (!function_exists('curl_init')) {
        echo json_encode(['error' => 'PHP Extension CURL tidak aktif! Silakan aktifkan di hosting Anda.']);
        exit;
    }

    // Helper to get config
    function getConfig($pdo, $key, $default = '')
    {
        $stmt = $pdo->prepare("SELECT key_value FROM settings WHERE key_name = ?");
        $stmt->execute([$key]);
        $res = $stmt->fetchColumn();
        return $res !== false ? $res : $default;
    }

    // Helper to set config
    function setConfig($pdo, $key, $value)
    {
        $stmt = $pdo->prepare("INSERT INTO settings (key_name, key_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE key_value = ?");
        $stmt->execute([$key, $value, $value]);
    }

    if ($action === 'get_config') {
        $stmt = $pdo->prepare("SELECT username FROM admins LIMIT 1");
        $stmt->execute();
        $admin_username = $stmt->fetchColumn();

        echo json_encode([
            'admin_username' => $admin_username ?: '',
            'okeconnect_member_id' => getConfig($pdo, 'okeconnect_member_id'),
            'okeconnect_pin' => getConfig($pdo, 'okeconnect_pin'),
            'webhook_secret' => getConfig($pdo, 'okeconnect_password'),
            'margin_global' => (int)getConfig($pdo, 'global_margin', 0),
            'ppob_secret' => getConfig($pdo, 'ppob_secret'),
            'token_bo' => getConfig($pdo, 'token_bo'),
            'telegram_bot_token_ppob' => getConfig($pdo, 'telegram_bot_token_ppob'),
            'telegram_chat_id' => getConfig($pdo, 'telegram_chat_id'),
            'token_fonnte' => getConfig($pdo, 'token_fonnte'),
        ]);
        exit;
    }

    if ($action === 'save_config') {
        $data = json_decode(file_get_contents('php://input'), true);
        setConfig($pdo, 'okeconnect_member_id', $data['okeconnect_member_id'] ?? '');
        setConfig($pdo, 'okeconnect_pin', $data['okeconnect_pin'] ?? '');
        setConfig($pdo, 'okeconnect_password', $data['webhook_secret'] ?? '');
        setConfig($pdo, 'global_margin', $data['margin_global'] ?? 0);
        setConfig($pdo, 'ppob_secret', $data['ppob_secret'] ?? '');
        setConfig($pdo, 'token_bo', $data['token_bo'] ?? '');
        setConfig($pdo, 'telegram_bot_token_ppob', $data['telegram_bot_token_ppob'] ?? '');
        setConfig($pdo, 'telegram_chat_id', $data['telegram_chat_id'] ?? '');
        setConfig($pdo, 'token_fonnte', $data['token_fonnte'] ?? '');
        echo json_encode(['success' => true, 'message' => 'Konfigurasi berhasil disimpan']);
        exit;
    }

    if ($action === 'update_security') {
        $data = json_decode(file_get_contents('php://input'), true);
        $new_username = $data['username'] ?? '';
        $current_password = $data['current_password'] ?? '';
        $new_password = $data['new_password'] ?? '';

        if (empty($new_username)) {
            echo json_encode(['error' => 'Username tidak boleh kosong']);
            exit;
        }

        // Get current admin
        $stmt = $pdo->prepare("SELECT * FROM admins LIMIT 1");
        $stmt->execute();
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$admin) {
            echo json_encode(['error' => 'Admin tidak ditemukan']);
            exit;
        }

        if (!password_verify($current_password, $admin['password'])) {
            echo json_encode(['error' => 'Password saat ini salah']);
            exit;
        }

        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE admins SET username = ?, password = ? WHERE id = ?");
            $stmt->execute([$new_username, $hashed_password, $admin['id']]);
        } else {
            $stmt = $pdo->prepare("UPDATE admins SET username = ? WHERE id = ?");
            $stmt->execute([$new_username, $admin['id']]);
        }

        echo json_encode(['success' => true, 'message' => 'Keamanan berhasil diperbarui']);
        exit;
    }

    if ($action === 'get_categories') {
        $type = $_GET['type'] ?? 'prabayar';
        $stmt = $pdo->prepare("SELECT DISTINCT category FROM products WHERE product_type = ? AND category IS NOT NULL AND category != '' ORDER BY category ASC");
        $stmt->execute([$type]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_COLUMN));
        exit;
    }

    if ($action === 'get_memberships') {
        $stmt = $pdo->query("SELECT * FROM memberships ORDER BY name ASC");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        exit;
    }

    if ($action === 'create_membership') {
        $data = json_decode(file_get_contents('php://input'), true);
        $name = trim($data['name'] ?? '');
        if ($name === '') {
            echo json_encode(['success' => false, 'message' => 'Nama membership tidak boleh kosong']);
            exit;
        }
        try {
            $stmt = $pdo->prepare("INSERT INTO memberships (name) VALUES (?)");
            $stmt->execute([$name]);
            echo json_encode(['success' => true, 'message' => 'Membership baru berhasil disimpan']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Gagal menyimpan: Membership "' . htmlspecialchars($name) . '" sudah ada atau database error.']);
        }
        exit;
    }

    if ($action === 'delete_membership') {
        $data = json_decode(file_get_contents('php://input'), true);
        $name = trim($data['name'] ?? '');
        if ($name !== '') {
            try {
                $stmt = $pdo->prepare("DELETE FROM memberships WHERE name = ?");
                $stmt->execute([$name]);
                $stmt = $pdo->prepare("DELETE FROM membership_prices WHERE membership_name = ?");
                $stmt->execute([$name]);
                echo json_encode(['success' => true, 'message' => 'Membership "' . htmlspecialchars($name) . '" berhasil dihapus']);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Gagal menghapus: ' . $e->getMessage()]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Nama tidak valid']);
        }
        exit;
    }

    if ($action === 'get_membership_prices') {
        $membership_name = $_GET['membership_name'] ?? '';
        $type = $_GET['type'] ?? 'prepaid';
        $search = $_GET['search'] ?? '';
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = in_array((int)($_GET['limit'] ?? 10), [10, 20, 50, 100]) ? (int)$_GET['limit'] : 10;
        $offset = ($page - 1) * $limit;

        $sql = "SELECT p.buyer_sku_code, p.product_name, p.category, p.brand, p.price, p.sell_price, 
                      COALESCE(mp.price_adjustment, 0) as price_adjustment
               FROM products p
               LEFT JOIN membership_prices mp ON p.buyer_sku_code = mp.buyer_sku_code AND mp.membership_name = ?
               WHERE p.product_type = ?";
        $params = [$membership_name, $type];

        if ($search !== '') {
            $sql .= " AND (p.product_name LIKE ? OR p.buyer_sku_code LIKE ? OR p.brand LIKE ?)";
            $sp = "%$search%";
            array_push($params, $sp, $sp, $sp);
        }

        $sql .= " ORDER BY p.brand ASC, p.sell_price ASC LIMIT $limit OFFSET $offset";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Count total matching items
        $count_sql = "SELECT COUNT(*) FROM products p WHERE p.product_type = ?";
        $count_params = [$type];
        if ($search !== '') {
            $count_sql .= " AND (p.product_name LIKE ? OR p.buyer_sku_code LIKE ? OR p.brand LIKE ?)";
            array_push($count_params, $sp, $sp, $sp);
        }
        $stmt_count = $pdo->prepare($count_sql);
        $stmt_count->execute($count_params);
        $total = $stmt_count->fetchColumn();

        $hasNext = ($offset + $limit) < $total;

        echo json_encode([
            'data' => $data,
            'hasNext' => $hasNext,
            'total' => $total
        ]);
        exit;
    }

    if ($action === 'save_membership_price') {
        $data = json_decode(file_get_contents('php://input'), true);
        $membership_name = $data['membership_name'] ?? '';
        $skus = $data['skus'] ?? [];
        $price_adjustment = (int)($data['price_adjustment'] ?? 0);

        if (empty($membership_name) || empty($skus)) {
            echo json_encode(['success' => false, 'message' => 'Parameter tidak lengkap: membership name dan produk wajib dipilih']);
            exit;
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO membership_prices (membership_name, buyer_sku_code, price_adjustment) 
                                 VALUES (?, ?, ?) 
                                 ON DUPLICATE KEY UPDATE price_adjustment = ?");
            foreach ($skus as $sku) {
                $stmt->execute([$membership_name, $sku, $price_adjustment, $price_adjustment]);
            }
            echo json_encode(['success' => true, 'message' => 'Penyesuaian harga membership berhasil disimpan untuk ' . count($skus) . ' produk']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Gagal menyimpan harga: ' . $e->getMessage()]);
        }
        exit;
    }

    if ($action === 'get_products') {
        $type = $_GET['type'] ?? 'prabayar';
        $search = $_GET['search'] ?? '';
        $status_filter = $_GET['status'] ?? '';
        $sort_by = $_GET['sort_by'] ?? 'brand';
        $sort_dir = strtoupper($_GET['sort_dir'] ?? 'ASC');
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = in_array((int)($_GET['limit'] ?? 10), [10, 20, 50, 100, 500]) ? (int)$_GET['limit'] : 10;
        $offset = ($page - 1) * $limit;

        if (!in_array($sort_dir, ['ASC', 'DESC'])) $sort_dir = 'ASC';

        $allowed_sorts = [
            'buyer_sku_code' => 'buyer_sku_code',
            'product_name' => 'product_name',
            'category' => 'category',
            'brand' => 'brand',
            'price' => 'price',
            'sell_price' => 'sell_price',
            'status' => 'buyer_product_status'
        ];
        $sort_col = $allowed_sorts[$sort_by] ?? 'brand';

        $sql = "SELECT * FROM products WHERE product_type = ?";
        $params = [$type];

        if ($search) {
            $sql .= " AND (product_name LIKE ? OR buyer_sku_code LIKE ? OR brand LIKE ? OR category LIKE ?)";
            $sp = "%$search%";
            array_push($params, $sp, $sp, $sp, $sp);
        }

        if ($status_filter === 'aktif') {
            $sql .= " AND buyer_product_status = 1 AND seller_product_status = 1";
        } elseif ($status_filter === 'gangguan') {
            $sql .= " AND (buyer_product_status = 0 OR seller_product_status = 0)";
        }

        $sql .= " ORDER BY $sort_col $sort_dir LIMIT $limit OFFSET $offset";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $count_sql = "SELECT COUNT(*) FROM products WHERE product_type = ?";
        $count_params = [$type];
        if ($search) {
            $count_sql .= " AND (product_name LIKE ? OR buyer_sku_code LIKE ? OR brand LIKE ? OR category LIKE ?)";
            array_push($count_params, $sp, $sp, $sp, $sp);
        }
        if ($status_filter === 'aktif') {
            $count_sql .= " AND buyer_product_status = 1 AND seller_product_status = 1";
        } elseif ($status_filter === 'gangguan') {
            $count_sql .= " AND (buyer_product_status = 0 OR seller_product_status = 0)";
        }
        $stmt_count = $pdo->prepare($count_sql);
        $stmt_count->execute($count_params);
        $total = $stmt_count->fetchColumn();

        $hasNext = ($offset + $limit) < $total;

        echo json_encode(['data' => $data, 'hasNext' => $hasNext, 'total' => $total]);
        exit;
    }

    if ($action === 'sync_products') {
        set_time_limit(600);

        $ch = curl_init('https://okeconnect.com/harga/json?id=905ccd028329b0a');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true
        ]);

        $response = curl_exec($ch);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            echo json_encode(['error' => 'CURL Error: ' . $curl_error]);
            exit;
        }

        $res_data = json_decode($response, true);
        
        $type = 'prepaid';
        
        $data = ['data' => []];
        if (is_array($res_data)) {
            foreach($res_data as $p) {
                // translate
                $data['data'][] = [
                    'buyer_sku_code' => $p['kode'] ?? '',
                    'product_name' => $p['keterangan'] ?? '',
                    'category' => $p['kategori'] ?? '',
                    'brand' => $p['produk'] ?? '',
                    'type' => 'Umum',
                    'seller_name' => 'OkeConnect',
                    'price' => (int)($p['harga'] ?? 0),
                    'buyer_product_status' => (isset($p['status']) && $p['status'] == '1') ? 1 : 0,
                    'seller_product_status' => 1,
                    'unlimited_stock' => 1,
                    'stock' => 9999,
                    'multi' => 0,
                    'desc' => $p['keterangan'] ?? ''
                ];
            }
        }


        // =========================
        // VALIDASI RESPONSE
        // =========================
        if (!isset($data['data'])) {
            echo json_encode(['error' => 'Response tidak valid']);
            exit;
        }

        // 🔥 jika error dari API
        if (isset($data['data']['rc'])) {
            if ($data['data']['rc'] !== '00') {
                echo json_encode([
                    'error' => $data['data']['message'] ?? 'API Error'
                ]);
                exit;
            }
        }

        // harus array list produk
        if (!is_array($data['data']) || isset($data['data']['rc'])) {
            echo json_encode(['error' => 'Format data tidak valid']);
            exit;
        }

        // file_put_contents('debugsync.txt', json_encode($data, JSON_PRETTY_PRINT), FILE_APPEND);

        $global_margin = (int)getConfig($pdo, 'global_margin', 0);

        $pdo->beginTransaction();
        try {

            // 🔥 ambil margin lama
            $stmt = $pdo->query("SELECT buyer_sku_code, margin FROM products");
            $existingMargins = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

            // 🔥 kumpulkan SKU dari API
            $api_skus = [];

            $insertStmt = $pdo->prepare("INSERT INTO products 
            (buyer_sku_code, product_name, category, brand, type, seller_name, price, sell_price, margin, admin, commission, buyer_product_status, seller_product_status, unlimited_stock, stock, multi, start_cut_off, end_cut_off, description, product_type) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
            category=?, brand=?, type=?, seller_name=?, price=?, sell_price=?, admin=?, commission=?, buyer_product_status=?, seller_product_status=?, unlimited_stock=?, stock=?, multi=?, start_cut_off=?, end_cut_off=?, description=?");

            foreach ($data['data'] as $item) {

                if (!is_array($item)) continue;
                if (empty($item['buyer_sku_code'])) continue;

                $sku = $item['buyer_sku_code'];
                $api_skus[] = $sku;

                $price = $item['price'] ?? 0;
                $admin_fee = (int)($item['admin'] ?? 0);
                $commission = (int)($item['commission'] ?? 0);

                $margin = $existingMargins[$sku] ?? $global_margin;
                $sell_price = $price + $margin;

                $insertStmt->execute([
                    $sku,
                    $item['product_name'] ?? '',
                    $item['category'] ?? '',
                    $item['brand'] ?? '',
                    $item['type'] ?? '',
                    $item['seller_name'] ?? '',
                    $price,
                    $sell_price,
                    $margin,
                    $admin_fee,
                    $commission,
                    !empty($item['buyer_product_status']) ? 1 : 0,
                    !empty($item['seller_product_status']) ? 1 : 0,
                    !empty($item['unlimited_stock']) ? 1 : 0,
                    $item['stock'] ?? 0,
                    !empty($item['multi']) ? 1 : 0,
                    $item['start_cut_off'] ?? '',
                    $item['end_cut_off'] ?? '',
                    $item['desc'] ?? '',
                    $type,

                    // ON DUPLICATE
                    $item['category'] ?? '',
                    $item['brand'] ?? '',
                    $item['type'] ?? '',
                    $item['seller_name'] ?? '',
                    $price,
                    $sell_price,
                    $admin_fee,
                    $commission,
                    !empty($item['buyer_product_status']) ? 1 : 0,
                    !empty($item['seller_product_status']) ? 1 : 0,
                    !empty($item['unlimited_stock']) ? 1 : 0,
                    $item['stock'] ?? 0,
                    !empty($item['multi']) ? 1 : 0,
                    $item['start_cut_off'] ?? '',
                    $item['end_cut_off'] ?? '',
                    $item['desc'] ?? ''
                ]);
            }

            // =========================
            // 🔥 NONAKTIFKAN PRODUK YANG HILANG
            // =========================
            if (!empty($api_skus)) {
                $in = str_repeat('?,', count($api_skus) - 1) . '?';

                $stmt = $pdo->prepare("
                UPDATE products 
                SET buyer_product_status = 0 
                WHERE product_type = ? 
                AND buyer_sku_code NOT IN ($in)
            ");

                $params = array_merge([$type], $api_skus);
                $stmt->execute($params);
            }

            $pdo->commit();

            echo json_encode([
                'success' => true,
                'message' => 'Sinkronisasi berhasil!',
                'total_api' => count($data['data']),
                'processed' => count($api_skus)
            ]);
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(['error' => 'Database Error: ' . $e->getMessage()]);
        }

        exit;
    }

    if ($action === 'update_margin') {
        $data = json_decode(file_get_contents('php://input'), true);
        $type = $data['type'] ?? '';
        $margin = (int)($data['margin'] ?? 0);
        $product_type = $data['product_type'] ?? 'prepaid';

        if ($type === 'global') {
            $stmt = $pdo->prepare("UPDATE products SET margin = ?, sell_price = price + ? WHERE product_type = ?");
            $stmt->execute([$margin, $margin, $product_type]);
        } elseif ($type === 'category') {
            $category = $data['category'] ?? '';
            $stmt = $pdo->prepare("UPDATE products SET margin = ?, sell_price = price + ? WHERE category = ? AND product_type = ?");
            $stmt->execute([$margin, $margin, $category, $product_type]);
        } elseif ($type === 'selected') {
            $skus = $data['skus'] ?? [];
            if (!empty($skus)) {
                $in = str_repeat('?,', count($skus) - 1) . '?';
                $params = array_merge([$margin, $margin], $skus);
                $stmt = $pdo->prepare("UPDATE products SET margin = ?, sell_price = price + ? WHERE buyer_sku_code IN ($in)");
                $stmt->execute($params);
            }
        }
        echo json_encode(['success' => true, 'message' => 'Margin berhasil diperbarui']);
        exit;
    }

    if ($action === 'update_display') {
        $data = json_decode(file_get_contents('php://input'), true);
        $type = $data['type'] ?? '';
        $display = (int)($data['display'] ?? 1);
        $product_type = $data['product_type'] ?? 'prepaid';

        if ($type === 'global') {
            $stmt = $pdo->prepare("UPDATE products SET display = ? WHERE product_type = ?");
            $stmt->execute([$display, $product_type]);
        } elseif ($type === 'category') {
            $category = $data['category'] ?? '';
            $stmt = $pdo->prepare("UPDATE products SET display = ? WHERE category = ? AND product_type = ?");
            $stmt->execute([$display, $category, $product_type]);
        } elseif ($type === 'selected') {
            $skus = $data['skus'] ?? [];
            if (!empty($skus)) {
                $in = str_repeat('?,', count($skus) - 1) . '?';
                $params = array_merge([$display], $skus);
                $stmt = $pdo->prepare("UPDATE products SET display = ? WHERE buyer_sku_code IN ($in)");
                $stmt->execute($params);
            }
        }
        echo json_encode(['success' => true, 'message' => 'Status tampilan berhasil diperbarui']);
        exit;
    }

    if ($action === 'edit_product_name') {
        $data = json_decode(file_get_contents('php://input'), true);
        $sku = $data['buyer_sku_code'] ?? '';
        $new_name = $data['product_name'] ?? '';

        if (empty($sku)) {
            echo json_encode(['error' => 'SKU tidak boleh kosong']);
            exit;
        }
        if (is_null($new_name) || trim($new_name) === '') {
            echo json_encode(['error' => 'Nama produk tidak boleh kosong']);
            exit;
        }

        $stmt = $pdo->prepare("UPDATE products SET product_name = ? WHERE buyer_sku_code = ?");
        $stmt->execute([trim($new_name), $sku]);

        echo json_encode(['success' => true, 'message' => 'Nama produk berhasil diubah']);
        exit;
    }

    if ($action === 'get_transactions') {
        $search = $_GET['search'] ?? '';
        $sort_by = $_GET['sort_by'] ?? 'created_at';
        $sort_dir = strtoupper($_GET['sort_dir'] ?? 'DESC');
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = in_array((int)($_GET['limit'] ?? 10), [10, 20, 50, 100, 500]) ? (int)$_GET['limit'] : 10;
        $offset = ($page - 1) * $limit;

        if (!in_array($sort_dir, ['ASC', 'DESC'])) $sort_dir = 'DESC';

        $allowed_sorts = [
            'ref_id' => 't.ref_id',
            'created_at' => 't.created_at',
            'product_name' => 'p.product_name',
            'buyer_sku_code' => 't.buyer_sku_code',
            'customer_no' => 't.customer_no',
            'price' => 't.price',
            'sn' => 't.sn',
            'status' => 't.status'
        ];
        $sort_col = $allowed_sorts[$sort_by] ?? 't.created_at';

        $sql = "SELECT t.*, p.product_name FROM transactions t LEFT JOIN products p ON t.buyer_sku_code = p.buyer_sku_code WHERE 1=1";
        $params = [];

        if ($search) {
            $sql .= " AND (
                t.ref_id LIKE ?
                OR t.buyer_sku_code LIKE ?
                OR t.customer_no LIKE ?
                OR t.sn LIKE ?
                OR p.product_name LIKE ?
                OR t.nama_user LIKE ?
                OR t.id_user LIKE ?
                OR t.ip LIKE ?
                OR t.created_at LIKE ?
            )";

            $sp = "%$search%";
            array_push(
                $params,
                $sp, $sp, $sp, $sp, $sp,
                $sp, $sp, $sp, $sp
            );
        }

        $sql .= " ORDER BY $sort_col $sort_dir LIMIT $limit OFFSET $offset";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $count_sql = "SELECT COUNT(*) FROM transactions t LEFT JOIN products p ON t.buyer_sku_code = p.buyer_sku_code WHERE 1=1";
        $count_params = [];
        if ($search) {
            $count_sql .= " AND (t.ref_id LIKE ? OR t.buyer_sku_code LIKE ? OR t.customer_no LIKE ? OR t.sn LIKE ? OR p.product_name LIKE ?)";
            array_push($count_params, $sp, $sp, $sp, $sp, $sp);
        }
        $stmt_count = $pdo->prepare($count_sql);
        $stmt_count->execute($count_params);
        $total = $stmt_count->fetchColumn();

        $hasNext = ($offset + $limit) < $total;

        echo json_encode(['data' => $data, 'hasNext' => $hasNext, 'total' => $total]);
        exit;
    }

    if ($action === 'transaction') {
        $data = json_decode(file_get_contents('php://input'), true);
        $username = getConfig($pdo, 'okeconnect_member_id');
        $apikey = getConfig($pdo, 'okeconnect_pin');
        $ref_id = $data['ref_id'] ?? '';
        $sign = md5($username . $apikey . $ref_id);

        $payload = [
            'username' => $username,
            'buyer_sku_code' => $data['buyer_sku_code'] ?? '',
            'customer_no' => $data['customer_no'] ?? '',
            'ref_id' => $ref_id,
            'sign' => $sign
        ];

        if (isset($data['commands'])) {
            $payload['commands'] = $data['commands'];
        }
        if (isset($data['testing']) && $data['testing']) {
            $payload['testing'] = true;
        }

        $ch = curl_init('https://h2h.okeconnect.com/trx');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        $response = curl_exec($ch);
        curl_close($ch);

        $resData = json_decode($response, true);

        if (isset($resData['data'])) {
            $trx = $resData['data'];
            $stmt = $pdo->prepare("INSERT INTO transactions (ref_id, buyer_sku_code, customer_no, command, status, message, rc, sn, price, selling_price, customer_name, desc_detail) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE status=?, message=?, rc=?, sn=?, price=?, selling_price=?, customer_name=?, desc_detail=?");
            $stmt->execute([
                $trx['ref_id'] ?? '',
                $trx['buyer_sku_code'] ?? '',
                $trx['customer_no'] ?? '',
                $data['commands'] ?? '',
                $trx['status'] ?? '',
                $trx['message'] ?? '',
                $trx['rc'] ?? '',
                $trx['sn'] ?? '',
                $trx['price'] ?? 0,
                $trx['selling_price'] ?? 0,
                $trx['customer_name'] ?? '',
                json_encode($trx['desc'] ?? ''),
                $trx['status'] ?? '',
                $trx['message'] ?? '',
                $trx['rc'] ?? '',
                $trx['sn'] ?? '',
                $trx['price'] ?? 0,
                $trx['selling_price'] ?? 0,
                $trx['customer_name'] ?? '',
                json_encode($trx['desc'] ?? '')
            ]);
        }

        echo $response;
        exit;
    }

    if ($action === 'get_balance') {
        $username = getConfig($pdo, 'okeconnect_member_id');
        $apikey = getConfig($pdo, 'okeconnect_pin');

        $password = getConfig($pdo, 'okeconnect_password');

        if (empty($username) || empty($apikey) || empty($password)) {
            echo json_encode(['balance' => 0, 'error' => 'Belum disetting']);
            exit;
        }

        $memberID = urlencode($username);
        $pin = urlencode($apikey);
        $pass = urlencode($password);
        
        $url = "https://h2h.okeconnect.com/trx/balance?memberID=$memberID&pin=$pin&password=$pass";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err) {
            echo json_encode(['balance' => 0, 'error' => 'cURL Error']);
            exit;
        }

        // Response expected: "Saldo 284.939"
        if (preg_match('/Saldo\s+([0-9\.]+)/i', $response, $matches)) {
            $balance = str_replace('.', '', $matches[1]);
            echo json_encode(['balance' => (int)$balance]);
        } else {
            echo json_encode(['balance' => 0, 'error' => 'Unknown format: ' . $response]);
        }

        // simpan debug data ke file debugsaldo.txt
        $debugData = "Request: GET balance\nResponse: " . $response . "\nError: " . $err . "\n\nUsername: " . $username . "\nAPI Key: " . $apikey . "\nTime: " . date('Y-m-d H:i:s') . "\n-------------------------\n";
        // file_put_contents('debugsaldo.txt', $debugData, FILE_APPEND);
        exit;
    }

    if ($action === 'get_stats') {
        $sql = "SELECT 
            SUM(CASE WHEN created_at >= CURDATE() 
                THEN selling_price ELSE 0 END) as daily_revenue,

            SUM(CASE WHEN created_at >= CURDATE() 
                THEN (COALESCE(selling_price,0) - COALESCE(price,0)) 
                ELSE 0 END) as daily_profit,

            SUM(CASE WHEN created_at >= DATE_FORMAT(CURDATE(),'%Y-%m-01') 
                THEN 1 ELSE 0 END) as monthly_orders,

            SUM(CASE WHEN created_at >= DATE_FORMAT(CURDATE(),'%Y-%m-01') 
                THEN selling_price ELSE 0 END) as monthly_revenue,

            SUM(CASE WHEN created_at >= DATE_FORMAT(CURDATE(),'%Y-%m-01') 
                THEN (COALESCE(selling_price,0) - COALESCE(price,0)) 
                ELSE 0 END) as monthly_profit,

            SUM(COALESCE(selling_price,0)) as total_revenue,

            SUM(COALESCE(selling_price,0) - COALESCE(price,0)) as total_profit,

            ROUND(
                (
                    SUM(COALESCE(selling_price,0) - COALESCE(price,0))
                    /
                    NULLIF(SUM(COALESCE(selling_price,0)),0)
                ) * 100,
                2
            ) AS profit_margin
            

        FROM transactions
        WHERE status IN ('Sukses', 'Success', 'Berhasil')
        AND command IN ('topup', 'pay', 'pay-pasca')";

        $stmt = $pdo->query($sql);
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);


        echo json_encode([
            'daily_revenue'   => (int)($stats['daily_revenue'] ?? 0),
            'daily_profit'    => (int)($stats['daily_profit'] ?? 0),

            'monthly_orders'  => (int)($stats['monthly_orders'] ?? 0),
            'monthly_revenue' => (int)($stats['monthly_revenue'] ?? 0),
            'monthly_profit'  => (int)($stats['monthly_profit'] ?? 0),

            'total_revenue'   => (int)($stats['total_revenue'] ?? 0),
            'total_profit'    => (int)($stats['total_profit'] ?? 0),

            'profit_margin'   => (float)($stats['profit_margin'] ?? 0)
        ]);
        exit;
    }

    if ($action === 'get_members') {
        $search = $_GET['search'] ?? '';
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = in_array((int)($_GET['limit'] ?? 10), [10, 20, 50, 100]) ? (int)$_GET['limit'] : 10;
        $offset = ($page - 1) * $limit;

        $sql = "SELECT * FROM Member WHERE 1=1";
        $params = [];

        if ($search !== '') {
            $sql .= " AND (nama_user LIKE ? OR id_user LIKE ? OR nomor_telepon LIKE ? OR email_user LIKE ?)";
            $sp = "%$search%";
            array_push($params, $sp, $sp, $sp, $sp);
        }

        $sql .= " ORDER BY last_login DESC LIMIT $limit OFFSET $offset";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $count_sql = "SELECT COUNT(*) FROM Member WHERE 1=1";
        $count_params = [];
        if ($search !== '') {
            $count_sql .= " AND (nama_user LIKE ? OR id_user LIKE ? OR nomor_telepon LIKE ? OR email_user LIKE ?)";
            array_push($count_params, $sp, $sp, $sp, $sp);
        }
        $stmt_count = $pdo->prepare($count_sql);
        $stmt_count->execute($count_params);
        $total = $stmt_count->fetchColumn();

        $hasNext = ($offset + $limit) < $total;

        echo json_encode([
            'data' => $data,
            'hasNext' => $hasNext,
            'total' => $total
        ]);
        exit;
    }

    if ($action === 'get_member_detail') {
        $id_user = $_GET['id_user'] ?? '';
        if (empty($id_user)) {
            echo json_encode(['error' => 'Parameter id_user wajib diisi.']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM Member WHERE id_user = ?");
        $stmt->execute([$id_user]);
        $member = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$member) {
            echo json_encode(['error' => 'Member tidak ditemukan.']);
            exit;
        }

        // Ambil riwayat transaksi member tersebut
        $stmt_tx = $pdo->prepare("SELECT t.*, p.product_name FROM transactions t LEFT JOIN products p ON t.buyer_sku_code = p.buyer_sku_code WHERE t.id_user = ? ORDER BY t.created_at DESC LIMIT 50");
        $stmt_tx->execute([$id_user]);
        $transactions = $stmt_tx->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'member' => $member,
            'transactions' => $transactions
        ]);
        exit;
    }

    if ($action === 'save_member') {
        $data = json_decode(file_get_contents('php://input'), true);
        $id_user = trim($data['id_user'] ?? '');
        $nama_user = trim($data['nama_user'] ?? '');
        $nomor_telepon = trim($data['nomor_telepon'] ?? '');
        $paylater = trim($data['paylater'] ?? 'tidak');
        $limit = (int)($data['limit'] ?? 0);
        $sisa_pinjaman = (int)($data['sisa_pinjaman'] ?? 0);
        $total_pinjaman = (int)($data['total_pinjaman'] ?? 0);
        $total_bayar = (int)($data['total_bayar'] ?? 0);
        $email_user = trim($data['email_user'] ?? '');
        $saldo_user = (int)($data['saldo_user'] ?? 0);
        $nama_membership = trim($data['nama_membership'] ?? 'Umum');
        $poin_member = (int)($data['poin_member'] ?? 0);
        $restricted_products = trim($data['restricted_products'] ?? '');

        if (empty($id_user) || empty($nama_user)) {
            echo json_encode(['success' => false, 'message' => 'ID User dan Nama User wajib diisi.']);
            exit;
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO Member 
                (id_user, nama_user, nomor_telepon, paylater, `limit`, sisa_pinjaman, total_pinjaman, total_bayar, email_user, saldo_user, nama_membership, poin_member, restricted_products) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    nama_user = VALUES(nama_user),
                    nomor_telepon = VALUES(nomor_telepon),
                    paylater = VALUES(paylater),
                    `limit` = VALUES(`limit`),
                    sisa_pinjaman = VALUES(sisa_pinjaman),
                    total_pinjaman = VALUES(total_pinjaman),
                    total_bayar = VALUES(total_bayar),
                    email_user = VALUES(email_user),
                    saldo_user = VALUES(saldo_user),
                    nama_membership = VALUES(nama_membership),
                    poin_member = VALUES(poin_member),
                    restricted_products = VALUES(restricted_products)
            ");
            $stmt->execute([
                $id_user, $nama_user, $nomor_telepon, $paylater, $limit, $sisa_pinjaman, $total_pinjaman, $total_bayar, $email_user, $saldo_user, $nama_membership, $poin_member, $restricted_products
            ]);
            echo json_encode(['success' => true, 'message' => 'Data member berhasil disimpan.']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Gagal menyimpan member: ' . $e->getMessage()]);
        }
        exit;
    }

    if ($action === 'delete_member') {
        $data = json_decode(file_get_contents('php://input'), true);
        $id_user = trim($data['id_user'] ?? '');
        if (empty($id_user)) {
            echo json_encode(['success' => false, 'message' => 'ID User tidak boleh kosong.']);
            exit;
        }
        try {
            $stmt = $pdo->prepare("DELETE FROM Member WHERE id_user = ?");
            $stmt->execute([$id_user]);
            echo json_encode(['success' => true, 'message' => 'Member berhasil dihapus.']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Gagal menghapus member: ' . $e->getMessage()]);
        }
        exit;
    }

    if ($action === 'get_report_stats') {
        $preset = $_GET['preset'] ?? 'this_month';
        $start_date = $_GET['start_date'] ?? '';
        $end_date = $_GET['end_date'] ?? '';

        if ($preset === 'today') {
            $start_date = date('Y-m-d');
            $end_date = date('Y-m-d');
        } elseif ($preset === 'this_month') {
            $start_date = date('Y-m-01');
            $end_date = date('Y-m-t');
        } elseif ($preset === 'this_year') {
            $start_date = date('Y-01-01');
            $end_date = date('Y-12-31');
        } elseif ($preset === 'last_7_days') {
            $start_date = date('Y-m-d', strtotime('-6 days'));
            $end_date = date('Y-m-d');
        } elseif ($preset === 'last_30_days') {
            $start_date = date('Y-m-d', strtotime('-29 days'));
            $end_date = date('Y-m-d');
        }

        if (empty($start_date)) $start_date = date('Y-m-01');
        if (empty($end_date)) $end_date = date('Y-m-d');

        $start_datetime = $start_date . ' 00:00:00';
        $end_datetime = $end_date . ' 23:59:59';

        // 1. Summary
        $stmt = $pdo->prepare("SELECT
            COUNT(*) as total_orders,
            SUM(CASE WHEN LOWER(TRIM(status)) IN ('sukses', 'success', 'berhasil', 'completed', 'complete') THEN COALESCE(selling_price, 0) ELSE 0 END) as total_revenue,
            SUM(CASE WHEN LOWER(TRIM(status)) IN ('sukses', 'success', 'berhasil', 'completed', 'complete') THEN (COALESCE(selling_price, 0) - COALESCE(price, 0)) ELSE 0 END) as total_profit,
            SUM(CASE WHEN LOWER(TRIM(status)) IN ('sukses', 'success', 'berhasil', 'completed', 'complete') THEN 1 ELSE 0 END) as total_completed,
            SUM(CASE WHEN LOWER(TRIM(status)) IN ('pending', 'active', 'waiting', 'processing') THEN 1 ELSE 0 END) as total_pending,
            SUM(CASE WHEN LOWER(TRIM(status)) NOT IN ('sukses', 'success', 'berhasil', 'completed', 'complete', 'pending', 'active', 'waiting', 'processing') THEN 1 ELSE 0 END) as total_failed
        FROM transactions
        WHERE created_at >= ? AND created_at <= ?");
        $stmt->execute([$start_datetime, $end_datetime]);
        $summary = $stmt->fetch(PDO::FETCH_ASSOC);

        // 2. Daily Chart
        $stmtDaily = $pdo->prepare("SELECT
            DATE(created_at) as date_str,
            COUNT(*) as count,
            SUM(CASE WHEN LOWER(TRIM(status)) IN ('sukses', 'success', 'berhasil', 'completed', 'complete') THEN COALESCE(selling_price, 0) ELSE 0 END) as revenue,
            SUM(CASE WHEN LOWER(TRIM(status)) IN ('sukses', 'success', 'berhasil', 'completed', 'complete') THEN (COALESCE(selling_price, 0) - COALESCE(price, 0)) ELSE 0 END) as profit
        FROM transactions
        WHERE created_at >= ? AND created_at <= ?
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at) ASC");
        $stmtDaily->execute([$start_datetime, $end_datetime]);
        $dailyRows = $stmtDaily->fetchAll(PDO::FETCH_ASSOC);

        $dailyMap = [];
        foreach ($dailyRows as $row) {
            $dailyMap[$row['date_str']] = $row;
        }

        $dailyChart = [];
        $current = strtotime($start_date);
        $endTs = strtotime($end_date);

        $indMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

        while ($current <= $endTs) {
            $dStr = date('Y-m-d', $current);
            $dayNum = date('d', $current);
            $monthNum = (int)date('m', $current) - 1;
            $yearNum = date('Y', $current);

            $label = $dayNum . ' ' . ($indMonths[$monthNum] ?? '');
            $fullLabel = $dayNum . ' ' . ($indMonths[$monthNum] ?? '') . ' ' . $yearNum;

            if (isset($dailyMap[$dStr])) {
                $dailyChart[] = [
                    'date' => $dStr,
                    'label' => $label,
                    'full_label' => $fullLabel,
                    'count' => (int)$dailyMap[$dStr]['count'],
                    'revenue' => (float)$dailyMap[$dStr]['revenue'],
                    'profit' => (float)$dailyMap[$dStr]['profit']
                ];
            } else {
                $dailyChart[] = [
                    'date' => $dStr,
                    'label' => $label,
                    'full_label' => $fullLabel,
                    'count' => 0,
                    'revenue' => 0,
                    'profit' => 0
                ];
            }

            $current = strtotime('+1 day', $current);
            if (count($dailyChart) > 366) break;
        }

        // 3. Status Chart
        $stmtStatus = $pdo->prepare("SELECT
            CASE 
                WHEN LOWER(TRIM(status)) IN ('sukses', 'success', 'berhasil', 'completed', 'complete') THEN 'Lunas / Selesai'
                WHEN LOWER(TRIM(status)) IN ('pending', 'active', 'waiting', 'processing') THEN 'Pending'
                ELSE 'Dibatalkan / Gagal'
            END as status_group,
            COUNT(*) as count
        FROM transactions
        WHERE created_at >= ? AND created_at <= ?
        GROUP BY status_group");
        $stmtStatus->execute([$start_datetime, $end_datetime]);
        $statusRows = $stmtStatus->fetchAll(PDO::FETCH_ASSOC);

        $statusDist = [
            'Lunas / Selesai' => 0,
            'Pending' => 0,
            'Dibatalkan / Gagal' => 0
        ];
        foreach ($statusRows as $sr) {
            $statusDist[$sr['status_group']] = (int)$sr['count'];
        }

        // 4. Service / Top Products Chart
        $stmtService = $pdo->prepare("SELECT
            COALESCE(p.product_name, t.buyer_sku_code) as service,
            COUNT(*) as count
        FROM transactions t
        LEFT JOIN products p ON t.buyer_sku_code = p.buyer_sku_code
        WHERE t.created_at >= ? AND t.created_at <= ?
        GROUP BY service
        ORDER BY count DESC
        LIMIT 5");
        $stmtService->execute([$start_datetime, $end_datetime]);
        $serviceRows = $stmtService->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'summary' => [
                'total_orders' => (int)($summary['total_orders'] ?? 0),
                'total_revenue' => (float)($summary['total_revenue'] ?? 0),
                'total_profit' => (float)($summary['total_profit'] ?? 0),
                'total_completed' => (int)($summary['total_completed'] ?? 0),
                'total_pending' => (int)($summary['total_pending'] ?? 0),
                'total_failed' => (int)($summary['total_failed'] ?? 0),
            ],
            'daily_chart' => $dailyChart,
            'status_chart' => $statusDist,
            'service_chart' => $serviceRows
        ]);
        exit;
    }

    if ($action === 'export_transactions') {
        $preset = $_GET['preset'] ?? 'custom';
        $start_date = $_GET['start_date'] ?? '';
        $end_date = $_GET['end_date'] ?? '';
        $status_filter = trim($_GET['status'] ?? '');
        $format = strtolower($_GET['format'] ?? 'csv');

        if ($preset === 'today') {
            $start_date = date('Y-m-d');
            $end_date = date('Y-m-d');
        } elseif ($preset === 'this_month') {
            $start_date = date('Y-m-01');
            $end_date = date('Y-m-t');
        } elseif ($preset === 'this_year') {
            $start_date = date('Y-01-01');
            $end_date = date('Y-12-31');
        } elseif ($preset === 'last_7_days') {
            $start_date = date('Y-m-d', strtotime('-6 days'));
            $end_date = date('Y-m-d');
        } elseif ($preset === 'last_30_days') {
            $start_date = date('Y-m-d', strtotime('-29 days'));
            $end_date = date('Y-m-d');
        }

        if (empty($start_date)) $start_date = '2000-01-01';
        if (empty($end_date)) $end_date = date('Y-m-d');

        $start_datetime = $start_date . ' 00:00:00';
        $end_datetime = $end_date . ' 23:59:59';

        $sql = "SELECT t.*, p.product_name FROM transactions t LEFT JOIN products p ON t.buyer_sku_code = p.buyer_sku_code WHERE t.created_at >= ? AND t.created_at <= ?";
        $params = [$start_datetime, $end_datetime];

        if (!empty($status_filter)) {
            if ($status_filter === 'success' || $status_filter === 'completed') {
                $sql .= " AND LOWER(TRIM(t.status)) IN ('success', 'sukses', 'completed', 'complete', 'berhasil')";
            } elseif ($status_filter === 'pending') {
                $sql .= " AND LOWER(TRIM(t.status)) IN ('pending', 'active', 'waiting', 'processing')";
            } elseif ($status_filter === 'failed') {
                $sql .= " AND LOWER(TRIM(t.status)) IN ('failed', 'failure', 'gagal', 'cancelled', 'canceled', 'expired')";
            } else {
                $sql .= " AND LOWER(TRIM(t.status)) = ?";
                $params[] = strtolower($status_filter);
            }
        }

        $sql .= " ORDER BY t.created_at DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($format === 'json') {
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="Laporan_PPOB_' . $start_date . '_sd_' . $end_date . '.json"');
            echo json_encode($rows, JSON_PRETTY_PRINT);
            exit;
        } else {
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="Laporan_PPOB_' . $start_date . '_sd_' . $end_date . '.csv"');
            
            $output = fopen('php://output', 'w');
            fputs($output, "\xEF\xBB\xBF");
            
            fputcsv($output, [
                'Ref ID',
                'SKU Produk',
                'Nama Produk',
                'Nomor Tujuan',
                'Command',
                'Harga Modal (Rp)',
                'Harga Jual (Rp)',
                'Keuntungan (Rp)',
                'Status',
                'SN / Token',
                'Pesan',
                'Tanggal Dibuat',
                'Tanggal Diperbarui'
            ]);

            foreach ($rows as $row) {
                $profit = (float)($row['selling_price'] ?? 0) - (float)($row['price'] ?? 0);
                fputcsv($output, [
                    $row['ref_id'] ?? '',
                    $row['buyer_sku_code'] ?? '',
                    $row['product_name'] ?? '',
                    $row['customer_no'] ?? '',
                    $row['command'] ?? '',
                    $row['price'] ?? 0,
                    $row['selling_price'] ?? 0,
                    $profit,
                    $row['status'] ?? '',
                    $row['sn'] ?? '',
                    $row['message'] ?? '',
                    $row['created_at'] ?? '',
                    $row['updated_at'] ?? ''
                ]);
            }
            fclose($output);
            exit;
        }
    }

    // =========================================================================
    // [POSISI_ACTION_API] TAMBAHKAN ENDPOINT / ACTION API BACKEND BARU DI SINI
    // Contoh:
    // if ($action === 'nama_action_baru') {
    //     echo json_encode(['success' => true, 'data' => []]);
    //     exit;
    // }
    // =========================================================================
}

// Tampilkan form login jika belum login
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Okeconnect PPOB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #4f46e5;
            --bg: #f1f5f9;
            --sidebar-w: 260px;
            --text-color: #334155;
        }

        body {
            background: var(--bg);
            font-family: 'Inter', sans-serif;
            color: var(--text-color);
        }

        /* Layout */
        .sidebar {
            width: var(--sidebar-w);
            background: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            border-right: 1px solid rgba(226, 232, 240, 0.8);
            box-shadow: 4px 0 24px rgba(0, 0, 0, 0.02);
            z-index: 1030;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .main-content {
            margin-left: var(--sidebar-w);
            min-height: 100vh;
            transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            padding-bottom: 40px;
        }

        /* Sidebar Elements */
        .sidebar-header {
            height: 76px;
            display: flex;
            align-items: center;
            padding: 0 28px;
            font-weight: 800;
            font-size: 22px;
            color: var(--primary);
            border-bottom: 1px solid rgba(248, 250, 252, 0.8);
        }

        .sidebar-menu {
            padding: 24px 20px;
            flex: 1;
            overflow-y: auto;
        }

        .menu-label {
            padding: 0 16px;
            margin-bottom: 12px;
            font-size: 0.7rem;
            font-weight: 700;
            color: #94a3b8;
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }

        .nav-btn {
            display: flex;
            align-items: center;
            width: 100%;
            padding: 14px 18px;
            margin-bottom: 6px;
            color: #64748b;
            font-weight: 600;
            text-decoration: none;
            border-radius: 14px;
            border: none;
            background: transparent;
            text-align: left;
            transition: all 0.25s ease;
            font-size: 0.95rem;
        }

        .nav-btn i {
            width: 24px;
            font-size: 1.15rem;
            margin-right: 14px;
            text-align: center;
        }

        .nav-btn:hover {
            background: #f8fafc;
            color: var(--primary);
            transform: translateX(4px);
        }

        .nav-btn.active {
            background: linear-gradient(145deg, #eef2ff, #f8faff);
            color: var(--primary) !important;
            font-weight: 700;
            box-shadow: 0 2px 10px rgba(79, 70, 229, 0.08); /* Primary subtle shadow */
        }

        .hover-primary:hover {
            color: var(--primary) !important;
        }

        /* Header */
        .top-header {
            height: 76px;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 32px;
            position: sticky;
            top: 0;
            z-index: 1020;
            border-bottom: 1px solid rgba(226, 232, 240, 0.8);
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.02);
        }

        /* Cards */
        .card-custom {
            background: #fff;
            border-radius: 20px;
            border: 1px solid rgba(226, 232, 240, 0.8);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
            height: 100%;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .card-body-custom {
            padding: 28px;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            margin-bottom: 16px;
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0f172a;
            line-height: 1.2;
        }

        .stat-label {
            font-size: 0.875rem;
            color: #64748b;
            font-weight: 500;
        }

        /* Tables */
        .table-custom {
            margin: 0;
        }

        .table-custom thead th {
            background: #f8fafc;
            color: #64748b;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            border-top: none;
        }

        .table-custom tbody td {
            padding: 16px 24px;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
            font-size: 0.9rem;
        }

        .table-custom tr:last-child td {
            border-bottom: none;
        }

        .table-custom tr:hover td {
            background-color: #f8fafc;
        }

        /* Badges & Elements */
        .status-badge {
            padding: 6px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
        }

        .status-success {
            background: #dcfce7;
            color: #15803d;
        }

        .status-warning {
            background: #fef9c3;
            color: #a16207;
        }

        .status-danger {
            background: #fee2e2;
            color: #b91c1c;
        }

        .search-box {
            position: relative;
            max-width: 300px;
        }

        .search-box input {
            padding-left: 40px;
            border-radius: 10px;
            border: 1px solid #e2e8f0;
            font-size: 0.9rem;
            height: 40px;
        }

        .search-box i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
        }

        /* Mobile */
        .overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1025;
            display: none;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .overlay.show {
            display: block;
            opacity: 1;
        }

        @media (max-width: 991px) {
            .sidebar {
                transform: translateX(-100%);
                box-shadow: 4px 0 16px rgba(0, 0, 0, 0.1);
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

            .top-header {
                padding: 0 20px;
            }
        }

        /* Vue Transitions */
        .fade-enter-active,
        .fade-leave-active {
            transition: opacity 0.3s ease;
        }

        .fade-enter-from,
        .fade-leave-to {
            opacity: 0;
        }
    </style>
</head>

<body>
    <?php if (!$isLoggedIn): ?>
        <div class="d-flex align-items-center justify-content-center min-vh-100 p-4" style="background: #f8fafc;">
            <div class="card border-0 shadow-lg p-4 p-md-5" style="width: 100%; max-width: 420px; border-radius: 24px;">
                <div class="text-center mb-5">
                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                        <i class="fa-solid fa-bolt fa-xl"></i>
                    </div>
                    <h4 class="fw-bold text-dark">Welcome Back</h4>
                    <p class="text-muted small">Masuk untuk mengelola panel PPOB Anda</p>
                </div>

                <?php if ($login_error): ?>
                    <div class="alert alert-danger border-0 shadow-sm rounded-3 mb-4">
                        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($login_error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <input type="hidden" name="login" value="1">
                    <input type="hidden" name="gps_location" id="gps_location" value="">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Username</label>
                        <input type="text" name="username" class="form-control form-control-lg bg-light border-0 fs-6" placeholder="Masukkan username" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-secondary">Password</label>
                        <input type="password" name="password" class="form-control form-control-lg bg-light border-0 fs-6" placeholder="Masukkan password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-3 fw-bold rounded-3 shadow-sm transition">MASUK DASHBOARD</button>
                </form>
            </div>
        </div>
    <?php else: ?>
        <div id="app">
            <!-- Sidebar -->
            <div class="sidebar" :class="{ 'show': sidebarOpen }">
                <div class="sidebar-header">
                    <span>PPOB Panel</span>
                    <button class="btn btn-sm d-lg-none ms-auto text-secondary" @click="sidebarOpen = false"><i class="fa-solid fa-xmark fa-lg"></i></button>
                </div>
                <div class="sidebar-menu">
                    <div class="menu-label">Main Menu</div>
                    <button @click="activeTab = 'dashboard'; sidebarOpen = false" class="nav-btn" :class="{ 'active': activeTab === 'dashboard' }">
                        <i class="fa-solid fa-chart-pie"></i> Dashboard
                    </button>
                    <button @click="activeTab = 'config'; sidebarOpen = false" class="nav-btn" :class="{ 'active': activeTab === 'config' }">
                        <i class="fa-solid fa-sliders"></i> Konfigurasi
                    </button>
                    <button @click="activeTab = 'products'; sidebarOpen = false" class="nav-btn" :class="{ 'active': activeTab === 'products' }">
                        <i class="fa-solid fa-box"></i> Produk
                    </button>
                    <button @click="activeTab = 'transactions'; sidebarOpen = false" class="nav-btn" :class="{ 'active': activeTab === 'transactions' }">
                        <i class="fa-solid fa-list-alt"></i> Transaksi
                    </button>
                    <button @click="activeTab = 'membership'; sidebarOpen = false" class="nav-btn" :class="{ 'active': activeTab === 'membership' }">
                        <i class="fa-solid fa-users"></i> Membership
                    </button>
                    <button @click="activeTab = 'members'; sidebarOpen = false" class="nav-btn" :class="{ 'active': activeTab === 'members' }">
                        <i class="fa-solid fa-id-card"></i> Member
                    </button>
                    <button @click="activeTab = 'testing'; sidebarOpen = false" class="nav-btn" :class="{ 'active': activeTab === 'testing' }">
                        <i class="fa-solid fa-vial"></i> Testing API
                    </button>
                    <button @click="activeTab = 'security'; sidebarOpen = false" class="nav-btn" :class="{ 'active': activeTab === 'security' }">
                        <i class="fa-solid fa-shield-halved"></i> Keamanan
                    </button>
                    <button @click="activeTab = 'reports'; sidebarOpen = false; fetchReportStats();" class="nav-btn" :class="{ 'active': activeTab === 'reports' }">
                        <i class="fa-solid fa-chart-line"></i> Laporan
                    </button>
                    <!-- [POSISI_SIDEBAR_TAB] TAMBAHKAN TOMBOL MENU SIDEBAR BARU DI SINI -->
                </div>
                <div class="p-4 border-top">
                    <a href="?action=logout" class="btn btn-light w-100 text-danger fw-bold py-2 text-decoration-none d-block text-center">
                        <i class="fa-solid fa-power-off me-2"></i> Keluar
                    </a>
                </div>
            </div>

            <!-- Overlay for mobile -->
            <div class="overlay" :class="{ 'show': sidebarOpen }" @click="sidebarOpen = false"></div>

            <!-- Main Content -->
            <main class="main-content">
                <!-- Global Notification Toast -->
                <div class="position-fixed top-0 start-0 w-100 d-flex justify-content-center p-3" style="z-index: 1060; pointer-events: none;">
                    <Transition name="fade">
                        <div v-if="notification.show" :class="`alert ${notification.type === 'success' ? 'alert-success' : 'alert-danger'} shadow-lg d-flex align-items-center py-2 px-3 mb-0`" role="alert" style="max-width: 90%;">
                            <i :class="notification.type === 'success' ? 'fa-solid fa-check-circle me-2' : 'fa-solid fa-triangle-exclamation me-2'"></i>
                            <div class="fw-bold small">{{ notification.message }}</div>
                        </div>
                    </Transition>
                </div>

                <!-- Header -->
                <header class="top-header">
                    <div class="d-flex align-items-center">
                        <button class="btn btn-light d-lg-none me-3" @click="sidebarOpen = true">
                            <i class="fa-solid fa-bars"></i>
                        </button>
                        <h5 class="mb-0 fw-bold d-none d-md-block">
                            <span v-if="activeTab === 'dashboard'">Overview</span>
                            <span v-else-if="activeTab === 'config'">Konfigurasi Sistem</span>
                            <span v-else-if="activeTab === 'products'">Manajemen Produk</span>
                            <span v-else-if="activeTab === 'transactions'">Riwayat Transaksi</span>
                            <span v-else-if="activeTab === 'membership'">Tier Membership</span>
                            <span v-else-if="activeTab === 'members'">Manajemen Member</span>
                            <span v-else-if="activeTab === 'testing'">Testing API Transaksi</span>
                            <span v-else-if="activeTab === 'security'">Keamanan Akun</span>
                            <span v-else-if="activeTab === 'reports'">Laporan & Statistik Grafis</span>
                            <!-- [POSISI_HEADER_TITLE] TAMBAHKAN JUDUL HEADER TAB BARU DI SINI -->
                        </h5>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                        <div class="bg-white border px-3 py-2 rounded-pill d-flex align-items-center shadow-sm">
                            <i class="fa-solid fa-building-columns text-success me-2"></i>
                            <span class="fw-bold small text-dark">Saldo: {{ balanceError ? balanceError : 'Rp ' + formatNumber(balance) }}</span>
                        </div>
                        <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width:36px; height:36px; font-size:14px;">
                            A
                        </div>
                    </div>
                </header>

                <div class="container-fluid px-4 px-lg-1 py-1" style="max-width: 1400px; margin: 0 auto;">
                    <!-- Peringatan Database Error -->
                    <div v-if="dbError" class="alert alert-danger shadow-sm mb-4" role="alert">
                        <h5 class="alert-heading fw-bold"><i class="fa-solid fa-triangle-exclamation me-2"></i>Database Error!</h5>
                        <p>{{ dbError }}</p>
                        <hr>
                        <p class="mb-0 small">Silakan buka file <code>db.php</code> dan sesuaikan kredensial database Anda, lalu buat database MySQL di hosting Anda.</p>
                    </div>

                    <!-- Dashboard Tab -->
                    <div v-if="activeTab === 'dashboard'">
                        <div class="row g-4 mb-4">
                            <!-- Omset Hari Ini -->
                            <div class="col-sm-6 col-xl-3">
                                <div class="card-custom">
                                    <div class="card-body-custom">
                                        <div class="stat-badge bg-success bg-opacity-10 text-success">Hari Ini</div>
                                        <div class="stat-icon bg-success bg-opacity-10 text-success">
                                            <i class="fa-solid fa-money-bill-trend-up"></i>
                                        </div>
                                        <div class="stat-value mb-1">Rp {{ formatNumber(stats.daily_revenue) }}</div>
                                        <div class="stat-label">Omset Hari Ini</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Profit Hari Ini -->
                            <div class="col-sm-6 col-xl-3">
                                <div class="card-custom">
                                    <div class="card-body-custom">
                                        <div class="stat-badge bg-emerald bg-opacity-10 text-success">Profit</div>
                                        <div class="stat-icon bg-success bg-opacity-10 text-success">
                                            <i class="fa-solid fa-sack-dollar"></i>
                                        </div>
                                        <div class="stat-value mb-1">Rp {{ formatNumber(stats.daily_profit) }}</div>
                                        <div class="stat-label">Profit Hari Ini</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Order Bulan Ini -->
                            <div class="col-sm-6 col-xl-3">
                                <div class="card-custom">
                                    <div class="card-body-custom">
                                        <div class="stat-badge bg-primary bg-opacity-10 text-primary">Bulan Ini</div>
                                        <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                                            <i class="fa-solid fa-cart-shopping"></i>
                                        </div>
                                        <div class="stat-value mb-1">{{ formatNumber(stats.monthly_orders) }}</div>
                                        <div class="stat-label">Total Transaksi</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Omset Bulan Ini -->
                            <div class="col-sm-6 col-xl-3">
                                <div class="card-custom">
                                    <div class="card-body-custom">
                                        <div class="stat-badge bg-info bg-opacity-10 text-info">Bulanan</div>
                                        <div class="stat-icon bg-info bg-opacity-10 text-info">
                                            <i class="fa-solid fa-chart-column"></i>
                                        </div>
                                        <div class="stat-value mb-1">Rp {{ formatNumber(stats.monthly_revenue) }}</div>
                                        <div class="stat-label">Omset Bulan Ini</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row g-4 mb-4">
                    </div>

                    <div class="row g-4 mb-4">

                        <!-- Profit Bulan Ini -->
                        <div class="col-sm-6 col-xl-3">
                            <div class="card-custom">
                                <div class="card-body-custom">
                                    <div class="stat-badge bg-success bg-opacity-10 text-success">Bulanan</div>
                                    <div class="stat-icon bg-success bg-opacity-10 text-success">
                                        <i class="fa-solid fa-coins"></i>
                                    </div>
                                    <div class="stat-value mb-1">
                                        Rp {{ formatNumber(stats.monthly_profit) }}
                                    </div>
                                    <div class="stat-label">Profit Bulan Ini</div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Omset -->
                        <div class="col-sm-6 col-xl-3">
                            <div class="card-custom">
                                <div class="card-body-custom">
                                    <div class="stat-badge bg-warning bg-opacity-10 text-warning">Lifetime</div>
                                    <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                                        <i class="fa-solid fa-vault"></i>
                                    </div>
                                    <div class="stat-value mb-1">
                                        Rp {{ formatNumber(stats.total_revenue) }}
                                    </div>
                                    <div class="stat-label">Total Omset</div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Profit -->
                        <div class="col-sm-6 col-xl-3">
                            <div class="card-custom">
                                <div class="card-body-custom">
                                    <div class="stat-badge bg-success bg-opacity-10 text-success">Lifetime</div>
                                    <div class="stat-icon bg-success bg-opacity-10 text-success">
                                        <i class="fa-solid fa-piggy-bank"></i>
                                    </div>
                                    <div class="stat-value mb-1">
                                        Rp {{ formatNumber(stats.total_profit) }}
                                    </div>
                                    <div class="stat-label">Total Profit</div>
                                </div>
                            </div>
                        </div>

                        <!-- Profit Margin -->
                        <div class="col-sm-6 col-xl-3">
                            <div class="card-custom">
                                <div class="card-body-custom">
                                    <div
                                        class="stat-badge"
                                        :class="{
                                            'bg-danger bg-opacity-10 text-danger': stats.profit_margin < 5,
                                            'bg-warning bg-opacity-10 text-warning': stats.profit_margin >= 5 && stats.profit_margin < 10,
                                            'bg-success bg-opacity-10 text-success': stats.profit_margin >= 10
                                        }">
                                        Margin
                                    </div>

                                    <div
                                        class="stat-icon"
                                        :class="{
                                            'bg-danger bg-opacity-10 text-danger': stats.profit_margin < 5,
                                            'bg-warning bg-opacity-10 text-warning': stats.profit_margin >= 5 && stats.profit_margin < 10,
                                            'bg-success bg-opacity-10 text-success': stats.profit_margin >= 10
                                        }">
                                        <i class="fa-solid fa-percent"></i>
                                    </div>

                                    <div
                                        class="stat-value mb-1"
                                        :class="{
                                            'text-danger': stats.profit_margin < 5,
                                            'text-warning': stats.profit_margin >= 5 && stats.profit_margin < 10,
                                            'text-success': stats.profit_margin >= 10
                                        }">
                                        {{ stats.profit_margin }}%
                                    </div>

                                    <div class="stat-label">Profit Margin</div>
                                </div>
                            </div>
                        </div>

                    </div>

                        <!-- Table Section -->
                        <div class="card-custom p-0">
                            <div class="d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between p-4 border-bottom gap-3">
                                <h6 class="mb-0 fw-bold">Riwayat Pesanan Terbaru</h6>
                                <form @submit.prevent="fetchTransactions(false, false)" class="w-100" style="max-width: 360px;">
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0 text-muted">
                                            <i class="fa-solid fa-magnifying-glass"></i>
                                        </span>
                                        <input v-model="searchTransaction" type="text" class="form-control border-start-0" placeholder="Cari Ref ID, SKU, No Tujuan...">
                                        <button class="btn btn-primary" type="submit">
                                            <i class="fa-solid fa-magnifying-glass"></i> Cari
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-custom w-100">
                                    <thead>
                                        <tr>
                                            <th>ID / Waktu</th>
                                            <th>Layanan & SKU</th>
                                            <th>Target</th>
                                            <th>Harga</th>
                                            <th>SN / Keterangan</th>
                                            <th>Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-if="transactions.slice(0, 10).length === 0">
                                            <td colspan="7" class="text-center py-5 text-muted">
                                                <i class="fa-solid fa-receipt fs-1 mb-3 text-light"></i><br>
                                                Tidak ada transaksi ditemukan.
                                            </td>
                                        </tr>
                                        <tr v-for="trx in transactions.slice(0, 10)" :key="trx.id">
                                            <td>
                                                <div class="fw-bold text-dark">#{{ trx.ref_id }}</div>
                                                <div class="small text-muted">{{ new Date(trx.created_at).toLocaleString('id-ID') }}</div>
                                            </td>
                                            <td>
                                                <div class="fw-bold text-dark text-truncate" style="max-width: 200px;">{{ trx.product_name || trx.buyer_sku_code }}</div>
                                                <div class="small text-muted"><i class="fa-solid fa-box me-1"></i> {{ trx.buyer_sku_code }}</div>
                                            </td>
                                            <td>
                                                <div class="fw-bold text-primary small">{{ trx.customer_no }}</div>
                                            </td>
                                            <td class="fw-bold text-dark">Rp {{ formatNumber(trx.selling_price) }}</td>
                                            <td class="small text-muted" style="max-width: 200px;">
                                                <div class="text-truncate" :title="trx.sn || trx.message">{{ trx.sn || trx.message || '-' }}</div>
                                            </td>
                                            <td>
                                                <span :class="`status-badge ${trx.status === 'Sukses' ? 'status-success' : (trx.status === 'Pending' ? 'status-warning' : 'status-danger')}`">
                                                    {{ trx.status }}
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <button @click="showDetails(trx)" class="btn btn-sm btn-light text-primary border-0" title="Detail">
                                                    <i class="fa-solid fa-eye"></i>
                                                </button>
                                                <button @click="printReceipt(trx.ref_id)" class="btn btn-sm btn-light text-success border-0 ms-1" title="Cetak Struk">
                                                    <i class="fa-solid fa-print"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Konfigurasi Section -->
                    <div v-if="activeTab === 'config'">
                        <div class="row g-4">
                            <div class="col-lg-6">
                                <div class="card-custom">
                                    <div class="card-body-custom">
                                        <h5 class="fw-bold mb-4 border-bottom pb-2"><i class="fa-solid fa-key text-primary me-2"></i>Kredensial & Keamanan</h5>
                                        <div class="mb-3">
                                            <label class="form-label fw-medium text-secondary small">Member ID Okeconnect</label>
                                            <input v-model="config.okeconnect_member_id" type="text" class="form-control" placeholder="Member ID Okeconnect">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label fw-medium text-secondary small">PIN Okeconnect</label>
                                            <input v-model="config.okeconnect_pin" type="password" class="form-control" placeholder="PIN Okeconnect">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label fw-medium text-secondary small">Okeconnect Password</label>
                                            <input v-model="config.webhook_secret" type="text" class="form-control" placeholder="Kosongkan jika tidak menggunakan secret">
                                            <div class="form-text" style="font-size: 0.75rem;">Digunakan untuk memvalidasi callback webhook dari Okeconnect.</div>
                                        </div>
                                        <div class="mb-3 pt-3">
                                            <label class="form-label fw-medium text-secondary small">PPOB Secret Key (SHA256)</label>
                                            <p class="text-muted small mb-2">Gunakan secret ini di website PPOB Anda untuk men-generate signature SHA256.</p>
                                            <input v-model="config.ppob_secret" type="password" class="form-control" placeholder="Masukkan secret key acak">
                                        </div>
                                        <div class="mb-3 pt-3">
                                            <label class="form-label fw-medium text-secondary small">BukaOlshop Close Api</label>
                                            <input v-model="config.token_bo" type="password" class="form-control" placeholder="Ambil dari pengaturan BukaOlshop Anda">
                                        </div>
                                        <div class="mb-3 pt-3">
                                            <label class="form-label fw-medium text-secondary small">Telegram Bot Token</label>
                                            <input v-model="config.telegram_bot_token_ppob" type="text" class="form-control" placeholder="Masukkan token bot Telegram">
                                        </div>
                                        <div class="mb-3 pt-3 border-bottom">
                                            <label class="form-label fw-medium text-secondary small">Telegram Chat ID</label>
                                            <input v-model="config.telegram_chat_id" type="text" class="form-control" placeholder="Masukkan chat ID Telegram">
                                        </div>
                                        <div class="mb-3 pt-3">
                                            <label class="form-label fw-medium text-secondary small">Token Fonnte</label>
                                            <input v-model="config.token_fonnte" type="password" class="form-control" placeholder="Ambil dari pengaturan Fonnte Anda">
                                        </div>
                                        <button @click="saveConfig" :disabled="loading.config || dbError" class="btn btn-primary w-100 py-2 fw-medium">
                                            <i v-if="loading.config" class="fa-solid fa-spinner fa-spin me-2"></i>
                                            <i v-else class="fa-solid fa-save me-2"></i> Simpan Konfigurasi
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Daftar Harga -->
                    <div v-if="activeTab === 'products'">
                        <div class="card-custom mb-4 overflow-hidden border-0 shadow-sm">
                            <a data-bs-toggle="collapse" href="#bulkUpdateSection" role="button" aria-expanded="false" aria-controls="bulkUpdateSection" class="text-decoration-none text-dark d-block p-4 bg-white transition-all hover-bg-light">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="fw-bold mb-1"><i class="fa-solid fa-layer-group text-primary me-2"></i>Bulk Update Produk</h6>
                                    <div class="small text-muted">Update margin massal dan ubah status tampil produk</div>
                                </div>
                                <div class="bg-light rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                    <i class="fa-solid fa-chevron-down text-muted"></i>
                                </div>
                            </div>
                        </a>
                        <div class="collapse" id="bulkUpdateSection">
                            <div class="card-body-custom border-top" style="background-color: #f8fafc;">
                                <div class="row g-4">
                                    <div class="col-lg-6 mb-4 mb-lg-0">
                                        <h6 class="fw-bold mb-3"><i class="fa-solid fa-money-bill-wave text-success me-2"></i>Update Margin</h6>
                                        <div class="row g-3 align-items-end">
                                            <div class="col-12 col-md-6">
                                                <label class="form-label fw-medium text-secondary small">Terapkan ke</label>
                                                <select v-model="marginUpdate.type" class="form-select bg-white">
                                                    <option value="selected">Produk Terpilih ({{ selectedProducts.length }})</option>
                                                    <option value="category">Berdasarkan Kategori</option>
                                                    <option value="global">Semua Produk {{ priceType === 'prepaid' ? 'Prepaid' : 'Postpaid' }}</option>
                                                </select>
                                            </div>
                                            <div v-if="marginUpdate.type === 'category'" class="col-12 col-md-6">
                                                <label class="form-label fw-medium text-secondary small">Pilih Kategori</label>
                                                <select v-model="marginUpdate.category" class="form-select bg-white">
                                                    <option value="">-- Pilih Kategori --</option>
                                                    <option v-for="cat in uniqueCategories" :key="cat" :value="cat">{{ cat }}</option>
                                                </select>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <label class="form-label fw-medium text-secondary small">Margin Baru (Rp)</label>
                                                <input v-model="marginUpdate.amount" type="number" class="form-control bg-white" placeholder="Contoh: 1500">
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <button @click="updateMargin" :disabled="loading.margin || (marginUpdate.type === 'selected' && selectedProducts.length === 0) || (marginUpdate.type === 'category' && !marginUpdate.category)" class="btn btn-primary w-100">
                                                    <i v-if="loading.margin" class="fa-solid fa-spinner fa-spin me-2"></i>
                                                    <i v-else class="fa-solid fa-save me-2"></i> Terapkan
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <h6 class="fw-bold mb-3 pb-3 border-bottom d-lg-none"></h6>
                                        <h6 class="fw-bold mb-3"><i class="fa-solid fa-eye text-info me-2"></i>Atur Status Tampil</h6>
                                        <div class="row g-3 align-items-end">
                                            <div class="col-12 col-md-6">
                                                <label class="form-label fw-medium text-secondary small">Terapkan Ke</label>
                                                <select v-model="displayUpdate.type" class="form-select bg-white">
                                                    <option value="selected">Produk Terpilih ({{ selectedProducts.length }})</option>
                                                    <option value="category">Berdasarkan Kategori</option>
                                                    <option value="global">Semua Produk {{ priceType === 'prepaid' ? 'Prepaid' : 'Postpaid' }}</option>
                                                </select>
                                            </div>
                                            <div v-if="displayUpdate.type === 'category'" class="col-12 col-md-6">
                                                <label class="form-label fw-medium text-secondary small">Pilih Kategori</label>
                                                <select v-model="displayUpdate.category" class="form-select bg-white">
                                                    <option value="">-- Pilih Kategori --</option>
                                                    <option v-for="cat in uniqueCategories" :key="cat" :value="cat">{{ cat }}</option>
                                                </select>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <label class="form-label fw-medium text-secondary small">Status Display</label>
                                                <select v-model="displayUpdate.display" class="form-select bg-white">
                                                    <option value="1">Tampilkan</option>
                                                    <option value="0">Sembunyikan</option>
                                                </select>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <button @click="updateDisplay" :disabled="loading.margin || (displayUpdate.type === 'selected' && selectedProducts.length === 0) || (displayUpdate.type === 'category' && !displayUpdate.category)" class="btn btn-info text-white w-100">
                                                    <i v-if="loading.margin" class="fa-solid fa-spinner fa-spin me-2"></i>
                                                    <i v-else class="fa-solid fa-check me-2"></i> Terapkan
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-custom">
                        <div class="card-body-custom">
                            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
                                <h5 class="fw-bold mb-0"><i class="fa-solid fa-database text-success me-2"></i>Database Produk</h5>
                                <div class="d-flex flex-wrap align-items-center gap-2">
                                    <form @submit.prevent="fetchProductsFromDB(false, false)" style="width: 250px;">
                                        <div class="input-group input-group-sm">
                                            <span class="input-group-text bg-white border-end-0 text-muted">
                                                <i class="fa-solid fa-magnifying-glass"></i>
                                            </span>
                                            <input v-model="searchProduct" type="text" class="form-control border-start-0 text-muted" placeholder="Cari produk, SKU, brand...">
                                            <button class="btn btn-primary" type="submit">
                                                <i class="fa-solid fa-magnifying-glass"></i> Cari
                                            </button>
                                        </div>
                                    </form>
                                    <select v-model="productStatusFilter" @change="fetchProductsFromDB(false, false)" class="form-select form-select-sm w-auto">
                                        <option value="">Semua Status</option>
                                        <option value="aktif">Aktif</option>
                                        <option value="gangguan">Gangguan</option>
                                    </select>
                                    <button @click="syncProducts" :disabled="loading.prices || dbError" class="btn btn-sm btn-outline-primary" title="Sinkronisasi Produk">
                                        <i :class="loading.prices ? 'fa-solid fa-spinner fa-spin' : 'fa-solid fa-cloud-download-alt'"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="table-responsive border rounded-3">
                                <table class="table table-custom table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-center" style="width: 50px;">
                                                <input type="checkbox" :checked="selectAll" @change="toggleSelectAll" class="form-check-input">
                                            </th>
                                            <th @click="sortBy('buyer_sku_code')" style="cursor: pointer;">SKU Buyer <i :class="getSortIcon('buyer_sku_code')"></i></th>
                                            <th @click="sortBy('product_name')" style="cursor: pointer;">Nama Produk <i :class="getSortIcon('product_name')"></i></th>
                                            <th @click="sortBy('category')" style="cursor: pointer;">Kategori <i :class="getSortIcon('category')"></i></th>
                                            <th @click="sortBy('brand')" style="cursor: pointer;">Brand <i :class="getSortIcon('brand')"></i></th>
                                            <th @click="sortBy('price')" style="cursor: pointer;">Harga Asli <i :class="getSortIcon('price')"></i></th>
                                            <th @click="sortBy('sell_price')" class="text-primary" style="cursor: pointer;">Harga Jual <i :class="getSortIcon('sell_price')"></i></th>
                                            <th @click="sortBy('margin')" class="text-primary" style="cursor: pointer;">Margin <i :class="getSortIcon('margin')"></i></th>
                                            <th @click="sortBy('status')" style="cursor: pointer;">Status <i :class="getSortIcon('status')"></i></th>
                                            <th @click="sortBy('display')" style="cursor: pointer;" class="text-center">Display <i :class="getSortIcon('display')"></i></th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-if="priceList.length === 0">
                                            <td colspan="10" class="text-center py-5 text-muted">
                                                <i class="fa-solid fa-box-open fs-1 mb-3 text-light"></i><br>
                                                Tidak ada produk ditemukan.
                                            </td>
                                        </tr>
                                        <tr v-for="item in priceList" :key="item.buyer_sku_code">
                                            <td class="text-center">
                                                <input type="checkbox" :value="item.buyer_sku_code" v-model="selectedProducts" class="form-check-input">
                                            </td>
                                            <td class="font-monospace text-muted small">{{ item.buyer_sku_code }}</td>
                                            <td class="fw-medium">{{ item.product_name }}</td>
                                            <td><span class="badge bg-light text-dark border">{{ item.category }}</span></td>
                                            <td class="text-muted small">{{ item.brand }}</td>
                                            <td class="fw-medium text-muted">
                                                <span v-if="priceType === 'pasca'">
                                                    Admin: Rp {{ formatNumber(item.admin) }} <br>
                                                    Komisi: Rp {{ formatNumber(item.commission) }}
                                                </span>
                                                <span v-else>
                                                    Rp {{ formatNumber(item.price) }}
                                                </span>
                                            </td>
                                            <td class="fw-bold text-primary">
                                                <span v-if="priceType === 'pasca'">
                                                    Admin: Rp {{ formatNumber(item.admin + item.margin) }}
                                                    <span v-if="item.margin > 0" class="small text-success d-block fw-normal">+Rp {{ formatNumber(item.margin) }}</span>
                                                </span>
                                                <span v-else>
                                                    Rp {{ formatNumber(item.sell_price) }}
                                                    <span v-if="item.margin > 0" class="small text-success d-block fw-normal">+Rp {{ formatNumber(item.margin) }}</span>
                                                </span>
                                            </td>
                                            <td class="fw-bold text-primary">
                                                <span>
                                                    Rp {{ formatNumber(item.margin) }}
                                                </span>
                                            </td>
                                            <td>
                                                <span :class="`status-badge ${item.buyer_product_status == 1 && item.seller_product_status == 1 ? 'status-success' : 'status-danger'}`">
                                                    <i :class="`me-1 ${item.buyer_product_status == 1 && item.seller_product_status == 1 ? 'fa-solid fa-check' : 'fa-solid fa-times'}`"></i>
                                                    {{ item.buyer_product_status == 1 && item.seller_product_status == 1 ? 'Aktif' : 'Gangguan' }}
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <span v-if="item.display == 1" class="badge bg-info"><i class="fa-solid fa-eye"></i> Tampil</span>
                                                <span v-else class="badge bg-secondary"><i class="fa-solid fa-eye-slash"></i> Sembunyi</span>
                                            </td>
                                            <td class="text-center">
                                                <div class="d-flex justify-content-center gap-1">
                                                    <button @click="openEditProduct(item)" class="btn btn-sm btn-light text-info border-0" title="Edit Nama Produk">
                                                        <i class="fa-solid fa-pencil"></i>
                                                    </button>
                                                    <button @click="showDetails(item)" class="btn btn-sm btn-light text-primary border-0" title="Detail">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Bottom control bar (Limit & Pagination) -->
                            <div class="d-flex flex-column flex-sm-row align-items-center justify-content-between gap-3 mt-4">
                                <div class="d-flex align-items-center gap-2">
                                    <span class="small text-muted text-nowrap">Tampilkan:</span>
                                    <select v-model="itemsPerPageProducts" @change="fetchProductsFromDB(false, false)" class="form-select form-select-sm w-auto">
                                        <option value="10">10 / halaman</option>
                                        <option value="20">20 / halaman</option>
                                        <option value="50">50 / halaman</option>
                                        <option value="100">100 / halaman</option>
                                        <option value="500">500 / halaman</option>
                                    </select>
                                </div>
                                <div class="d-flex align-items-center gap-3">
                                    <div class="small text-muted">
                                        Halaman {{ currentPageProducts }}
                                    </div>
                                    <nav v-if="hasNextProducts || currentPageProducts > 1">
                                        <ul class="pagination pagination-sm mb-0">
                                            <li class="page-item" :class="{ disabled: currentPageProducts === 1 }">
                                                <button class="page-link" @click="prevPageProducts"><i class="fa-solid fa-chevron-left"></i></button>
                                            </li>
                                            <li class="page-item" :class="{ disabled: !hasNextProducts }">
                                                <button class="page-link" @click="nextPageProducts"><i class="fa-solid fa-chevron-right"></i></button>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Transaksi -->
                <div v-if="activeTab === 'transactions'">
                    <div class="card-custom">
                        <div class="card-body-custom">
                            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
                                <h5 class="fw-bold mb-0"><i class="fa-solid fa-list-alt text-warning me-2"></i>Riwayat Transaksi</h5>
                                <div class="d-flex flex-column flex-md-row gap-2">
                                    <form @submit.prevent="fetchTransactions(false, false)" class="w-100" style="max-width: 320px;">
                                        <div class="input-group">
                                            <span class="input-group-text bg-white border-end-0 text-muted">
                                                <i class="fa-solid fa-magnifying-glass"></i>
                                            </span>
                                            <input v-model="searchTransaction" type="text" class="form-control border-start-0" placeholder="Cari Ref ID, SKU, No Tujuan...">
                                            <button class="btn btn-primary" type="submit">
                                                <i class="fa-solid fa-magnifying-glass"></i> Cari
                                            </button>
                                        </div>
                                    </form>
                                    <select v-model="itemsPerPageTransactions" @change="fetchTransactions(false, false)" class="form-select w-auto">
                                        <option value="10">10 / page</option>
                                        <option value="20">20 / page</option>
                                        <option value="50">50 / page</option>
                                        <option value="100">100 / page</option>
                                        <option value="500">500 / page</option>
                                    </select>
                                    <button @click="fetchTransactions" class="btn btn-light border">
                                        <i class="fa-solid fa-sync-alt"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="table-responsive border rounded-3">
                                <table class="table table-custom table-hover">
                                    <thead>
                                        <tr>
                                            <th @click="sortTrx('created_at')" style="cursor: pointer;">ID / Waktu <i :class="getSortIconTrx('created_at')"></i></th>
                                            <th @click="sortTrx('product_name')" style="cursor: pointer;">Layanan & SKU <i :class="getSortIconTrx('product_name')"></i></th>
                                            <th @click="sortTrx('customer_no')" style="cursor: pointer;">Target <i :class="getSortIconTrx('customer_no')"></i></th>
                                            <th @click="sortTrx('price')" style="cursor: pointer;">Harga <i :class="getSortIconTrx('price')"></i></th>
                                            <th @click="sortTrx('sn')" style="cursor: pointer;">SN / Keterangan <i :class="getSortIconTrx('sn')"></i></th>
                                            <th @click="sortTrx('status')" style="cursor: pointer;">Status <i :class="getSortIconTrx('status')"></i></th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-if="transactions.length === 0">
                                            <td colspan="7" class="text-center py-5 text-muted">
                                                <i class="fa-solid fa-receipt fs-1 mb-3 text-light"></i><br>
                                                Tidak ada transaksi ditemukan.
                                            </td>
                                        </tr>
                                        <tr v-for="trx in transactions" :key="trx.id">
                                            <td>
                                                <div class="fw-bold text-dark">#{{ trx.ref_id }}</div>
                                                <div class="small text-muted">{{ new Date(trx.created_at).toLocaleString('id-ID') }}</div>
                                            </td>
                                            <td>
                                                <div class="fw-bold text-dark text-truncate" style="max-width: 200px;">{{ trx.product_name || trx.buyer_sku_code }}</div>
                                                <div class="small text-muted"><i class="fa-solid fa-box me-1"></i> {{ trx.buyer_sku_code }}</div>
                                            </td>
                                            <td>
                                                <div class="fw-bold text-primary small">{{ trx.customer_no }}</div>
                                            </td>
                                            <td class="fw-bold text-dark">Rp {{ formatNumber(trx.selling_price) }}</td>
                                            <td class="small text-muted" style="max-width: 200px;">
                                                <div class="text-truncate" :title="trx.sn || trx.message">{{ trx.sn || trx.message || '-' }}</div>
                                            </td>
                                            <td>
                                                <span :class="`status-badge ${trx.status === 'Sukses' ? 'status-success' : (trx.status === 'Pending' ? 'status-warning' : 'status-danger')}`">
                                                    {{ trx.status }}
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <button @click="showDetails(trx)" class="btn btn-sm btn-light text-primary border-0" title="Detail">
                                                    <i class="fa-solid fa-eye"></i>
                                                </button>
                                                <button @click="printReceipt(trx.ref_id)" class="btn btn-sm btn-light text-success border-0 ms-1" title="Cetak Struk">
                                                    <i class="fa-solid fa-print"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination Transactions -->
                            <div v-if="hasNextTransactions || currentPageTransactions > 1" class="d-flex align-items-center justify-content-between mt-4">
                                <div class="small text-muted">
                                    Halaman {{ currentPageTransactions }}
                                </div>
                                <nav>
                                    <ul class="pagination pagination-sm mb-0">
                                        <li class="page-item" :class="{ disabled: currentPageTransactions === 1 }">
                                            <button class="page-link" @click="prevPageTransactions"><i class="fa-solid fa-chevron-left"></i></button>
                                        </li>
                                        <li class="page-item" :class="{ disabled: !hasNextTransactions }">
                                            <button class="page-link" @click="nextPageTransactions"><i class="fa-solid fa-chevron-right"></i></button>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Testing Transaksi -->
                <div v-if="activeTab === 'testing'">
                    <div class="card-custom">
                        <div class="card-body-custom">
                            <h5 class="fw-bold mb-4 border-bottom pb-2"><i class="fa-solid fa-vial text-info me-2"></i>Testing Transaksi API</h5>

                            <div class="row g-4">
                                <!-- Form -->
                                <div class="col-lg-6">
                                    <div class="p-4 bg-light rounded-3 border mb-4">
                                        <label class="form-label fw-bold small text-dark">Jenis Transaksi</label>
                                        <div class="d-flex gap-4">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" v-model="trx.type" value="prepaid" id="typePrepaid">
                                                <label class="form-check-label" for="typePrepaid">Prepaid (Topup)</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" v-model="trx.type" value="pasca" id="typePasca">
                                                <label class="form-check-label" for="typePasca">Postpaid (Tagihan)</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div v-if="trx.type === 'pasca'" class="p-4 bg-primary bg-opacity-10 rounded-3 border border-primary border-opacity-25 mb-4">
                                        <label class="form-label fw-bold small text-dark">Command Pascabayar</label>
                                        <div class="d-flex gap-4">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" v-model="trx.command" value="inq-pasca" id="cmdInq">
                                                <label class="form-check-label" for="cmdInq">Cek Tagihan (Inquiry)</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" v-model="trx.command" value="pay-pasca" id="cmdPay">
                                                <label class="form-check-label" for="cmdPay">Bayar Tagihan (Pay)</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label fw-medium text-secondary small">SKU Code (buyer_sku_code)</label>
                                        <input v-model="trx.sku" type="text" class="form-control" placeholder="Contoh: xld10, pln, pdam">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-medium text-secondary small">Nomor Tujuan / Pelanggan</label>
                                        <input v-model="trx.customer_no" type="text" class="form-control" placeholder="Contoh: 087800001230">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-medium text-secondary small">Ref ID (Unik)</label>
                                        <div class="input-group">
                                            <input v-model="trx.ref_id" type="text" class="form-control font-monospace bg-light">
                                            <button @click="trx.ref_id = 'test-' + Date.now()" class="btn btn-outline-secondary" title="Generate New"><i class="fa-solid fa-random"></i></button>
                                        </div>
                                    </div>
                                    <div class="mb-4 p-3 bg-warning bg-opacity-10 border border-warning border-opacity-25 rounded-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" v-model="trx.testing" id="testingMode">
                                            <label class="form-check-label text-warning fw-medium small" for="testingMode">
                                                Mode Testing (Development - Tidak memotong saldo)
                                            </label>
                                        </div>
                                    </div>

                                    <button @click="processTransaction" :disabled="loading.trx || dbError" class="btn btn-primary w-100 py-2 fw-medium">
                                        <i v-if="loading.trx" class="fa-solid fa-spinner fa-spin me-2"></i>
                                        <i v-else class="fa-solid fa-paper-plane me-2"></i> Proses Transaksi
                                    </button>
                                </div>

                                <!-- Result -->
                                <div class="col-lg-6">
                                    <div class="bg-dark rounded-3 p-4 text-light font-monospace small h-100 min-vh-50 position-relative overflow-auto">
                                        <span class="position-absolute top-0 end-0 m-2 badge bg-secondary">JSON Response</span>
                                        <div v-if="!trxResult" class="d-flex flex-column align-items-center justify-content-center h-100 text-muted">
                                            <i class="fa-solid fa-code fs-1 mb-3"></i>
                                            <span>Hasil response API akan muncul di sini</span>
                                        </div>
                                        <pre v-else class="mb-0 text-wrap">{{ JSON.stringify(trxResult, null, 2) }}</pre>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Keamanan Section -->
                <div v-if="activeTab === 'security'">
                    <div class="row g-4">
                        <div class="col-lg-6">
                            <div class="card-custom">
                                <div class="card-body-custom">
                                    <h5 class="fw-bold mb-4 border-bottom pb-2"><i class="fa-solid fa-shield-halved text-primary me-2"></i>Pengaturan Keamanan</h5>
                                    <div class="mb-3">
                                        <label class="form-label fw-medium text-secondary small">Username Admin</label>
                                        <input v-model="security.username" type="text" class="form-control" placeholder="Username baru">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-medium text-secondary small">Password Saat Ini</label>
                                        <input v-model="security.current_password" type="password" class="form-control" placeholder="Wajib diisi untuk konfirmasi">
                                    </div>
                                    <hr class="my-4">
                                    <div class="mb-3">
                                        <label class="form-label fw-medium text-secondary small">Password Baru</label>
                                        <input v-model="security.new_password" type="password" class="form-control" placeholder="Kosongkan jika tidak ingin mengubah password">
                                    </div>
                                    <div class="mb-4">
                                        <label class="form-label fw-medium text-secondary small">Konfirmasi Password Baru</label>
                                        <input v-model="security.confirm_password" type="password" class="form-control" placeholder="Ulangi password baru">
                                    </div>
                                    <button @click="updateSecurity" :disabled="loading.security || dbError" class="btn btn-primary w-100 py-2 fw-medium">
                                        <i v-if="loading.security" class="fa-solid fa-spinner fa-spin me-2"></i>
                                        <i v-else class="fa-solid fa-save me-2"></i> Perbarui Keamanan
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Membership Section -->
                <div v-if="activeTab === 'membership'">
                    <div class="row g-4">
                        <!-- Left Panel: Add Membership Tier -->
                        <div class="col-md-5">
                            <div class="card-custom">
                                <div class="card-body-custom">
                                    <h5 class="fw-bold mb-4 border-bottom pb-2">
                                        <i class="fa-solid fa-users text-primary me-2"></i>Tambah Tier Membership
                                    </h5>
                                    <form @submit.prevent="createMembership">
                                        <div class="mb-3">
                                            <label class="form-label small fw-bold text-secondary">Nama Membership</label>
                                            <input v-model="newMembershipName" type="text" class="form-control form-control-lg" placeholder="Contoh: Mitra, Agen, VIP" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary w-100 py-2.5 fw-semibold rounded-3 shadow-sm transition">
                                            <i class="fa-solid fa-plus me-2"></i> Buat Tier Baru
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- Right Panel: List Membership Tiers -->
                        <div class="col-md-7">
                            <div class="card-custom">
                                <div class="card-body-custom">
                                    <h5 class="fw-bold mb-3 border-bottom pb-2">
                                        <i class="fa-solid fa-address-book text-success me-2"></i>Daftar Tier Membership
                                    </h5>
                                    <div v-if="memberships.length === 0" class="text-center py-4 text-muted">
                                        <div class="mb-2"><i class="fa-solid fa-users-slash fs-3 text-light"></i></div>
                                        <span class="small">Belum ada tier membership. Silakan buat di sebelah kiri.</span>
                                    </div>
                                    <div v-else class="list-group rounded-3 shadow-sm">
                                        <div v-for="m in memberships" 
                                             :key="m.id" 
                                             class="list-group-item d-flex flex-column flex-sm-row align-items-sm-center justify-content-between py-3 px-4 border-0 border-bottom gap-3 hover-primary">
                                            <div class="d-flex align-items-center">
                                                <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 42px; height: 42px;">
                                                    <i class="fa-solid fa-id-card"></i>
                                                </div>
                                                <div>
                                                    <h6 class="fw-bold mb-0 text-dark">{{ m.name }}</h6>
                                                    <small class="text-muted text-uppercase small" style="font-size: 11px;">Tier Membership</small>
                                                </div>
                                            </div>
                                            <div class="d-flex align-items-center gap-2">
                                                <button @click.prevent="selectedMembershipName = m.name; fetchMembershipPrices(true)"
                                                        class="btn btn-primary btn-sm rounded-pill px-3 fw-semibold shadow-sm text-nowrap d-inline-flex align-items-center gap-1"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#membershipPricesModal">
                                                    <i class="fa-solid fa-tags"></i>
                                                    Atur Harga
                                                </button>
                                                <button @click.prevent="deleteMembership(m.name)" 
                                                        class="btn btn-sm btn-outline-danger rounded-circle d-inline-flex align-items-center justify-content-center" 
                                                        style="width: 32px; height: 32px;"
                                                        title="Hapus Membership">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Members Section -->
                <div v-if="activeTab === 'members'">
                    <div class="card-custom mb-4">
                        <div class="card-body-custom">
                            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-3 border-bottom">
                                <h5 class="fw-bold m-0 text-slate-800">
                                    <i class="fa-solid fa-id-card text-primary me-2"></i>Manajemen Member
                                </h5>
                                <button @click="openAddMemberModal" class="btn btn-primary rounded-pill px-4 btn-sm">
                                    <i class="fa-solid fa-plus me-1"></i> Tambah Member Manual
                                </button>
                            </div>

                            <!-- Search & Limit -->
                            <div class="row g-3 mb-4">
                                <div class="col-12 col-md-8">
                                    <form @submit.prevent="fetchMembers(true)">
                                        <div class="input-group shadow-xs rounded-pill overflow-hidden bg-white border">
                                            <span class="input-group-text bg-white border-0 text-muted ps-3"><i class="fa-solid fa-magnifying-glass"></i></span>
                                            <input v-model="searchMemberQuery" type="text" class="form-control border-0 ps-0 text-start" placeholder="Cari berdasarkan ID, Nama, No. HP, atau Email...">
                                            <button class="btn btn-primary px-4 text-nowrap" type="submit">Cari</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-12 col-md-4 d-flex justify-content-md-end">
                                    <select v-model="itemsPerPageMembers" @change="fetchMembers(true)" class="form-select rounded-pill shadow-xs w-auto">
                                        <option value="10">10 per halaman</option>
                                        <option value="20">20 per halaman</option>
                                        <option value="50">50 per halaman</option>
                                        <option value="100">100 per halaman</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Loading Spinner -->
                            <div v-if="loading.members" class="text-center py-5">
                                <div class="spinner-border text-primary" role="status"></div>
                                <div class="mt-2 text-muted small">Memuat data member...</div>
                            </div>

                            <!-- Table -->
                            <div v-else class="table-responsive">
                                <table class="table table-custom align-middle">
                                    <thead>
                                        <tr>
                                            <th>ID User</th>
                                            <th>Nama Member</th>
                                            <th>Membership</th>
                                            <th class="text-end">Saldo</th>
                                            <th class="text-center">Last Login</th>
                                            <th>No. Telepon</th>
                                            <th>Perangkat</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="m in members" :key="m.id_user">
                                            <td>
                                                <span class="badge bg-light text-dark font-mono border px-2 py-1.5">{{ m.id_user }}</span>
                                            </td>
                                            <td>
                                                <div class="fw-bold">{{ m.nama_user }}</div>
                                                <div class="text-muted small">{{ m.email_user || '-' }}</div>
                                            </td>
                                            <td>
                                                <span class="badge bg-indigo text-indigo-soft border px-2.5 py-1.5" style="color: var(--primary) !important;">{{ m.nama_membership || 'Umum' }}</span>
                                            </td>
                                            <td class="text-end fw-semibold text-primary">
                                                Rp{{ formatNumber(m.saldo_user || 0) }}
                                            </td>
                                            <td>{{ m.last_login || '-' }}</td>
                                            <td>{{ m.nomor_telepon || '-' }}</td>
                                            <td>{{ m.ua || '-' }}</td>
                                            <td class="text-center">
                                                <div class="d-flex justify-content-center gap-1">
                                                    <button @click="viewMemberDetail(m)" class="btn btn-outline-info btn-xs rounded-pill" title="Detail & Riwayat">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </button>
                                                    <button @click="openEditMemberModal(m)" class="btn btn-outline-primary btn-xs rounded-pill" title="Edit Data">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                    <button @click="deleteMember(m)" class="btn btn-outline-danger btn-xs rounded-pill" title="Hapus Member">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr v-if="members.length === 0">
                                            <td colspan="8" class="text-center text-muted py-5">
                                                <i class="fa-solid fa-id-badge fa-3x mb-3 text-light-gray d-block text-secondary"></i>
                                                Belum ada data member yang terdaftar atau ditemukan.
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination Footer -->
                            <div v-if="members.length > 0" class="d-flex flex-column flex-sm-row align-items-center justify-content-between mt-4 gap-3 bg-white p-3 rounded-3 border">
                                <div class="text-secondary small text-center text-sm-start fw-medium">
                                    Menampilkan {{ members.length }} member (Total: {{ totalMembers }})
                                </div>
                                <div class="d-flex align-items-center justify-content-center gap-1">
                                    <button class="btn btn-outline-secondary btn-sm rounded-pill px-3" :disabled="currentPageMembers === 1" @click="currentPageMembers--; fetchMembers()">
                                        <i class="fa-solid fa-angle-left me-1"></i> Sblm
                                    </button>
                                    <span class="mx-2 small fw-bold">Halaman {{ currentPageMembers }}</span>
                                    <button class="btn btn-outline-secondary btn-sm rounded-pill px-3" :disabled="!hasNextMembers" @click="currentPageMembers++; fetchMembers()">
                                        Skrg <i class="fa-solid fa-angle-right ms-1"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Laporan Section -->
                <div v-if="activeTab === 'reports'">
                    <!-- Top Sub-Nav Buttons (Matching user screenshot) -->
                    <div class="card-custom mb-4 p-0 overflow-hidden">
                        <div class="d-flex border-bottom bg-white px-2">
                            <button @click="reportSubTab = 'stats'; nextTick(() => renderReportCharts());"
                                    class="btn rounded-0 py-3 px-4 fw-bold text-uppercase transition border-bottom border-3"
                                    :class="reportSubTab === 'stats' ? 'border-primary text-primary bg-light' : 'border-transparent text-secondary'">
                                <i class="fa-solid fa-chart-line me-2"></i> STATISTIK
                            </button>
                            <button @click="reportSubTab = 'export'"
                                    class="btn rounded-0 py-3 px-4 fw-bold text-uppercase transition border-bottom border-3"
                                    :class="reportSubTab === 'export' ? 'border-primary text-primary bg-light' : 'border-transparent text-secondary'">
                                <i class="fa-solid fa-file-export me-2"></i> EXPORT
                            </button>
                        </div>
                    </div>

                    <!-- SUBTAB 1: STATISTIK -->
                    <div v-if="reportSubTab === 'stats'" class="d-flex flex-column gap-4">
                        <!-- Card 1: Total Transaksi Chart -->
                        <div class="card-custom">
                            <div class="card-body-custom">
                                <!-- Header -->
                                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-2 gap-2">
                                    <div>
                                        <h5 class="fw-bold text-dark mb-1">
                                            <i class="fa-solid fa-chart-area text-success me-2"></i> Total Transaksi
                                        </h5>
                                        <div class="text-success fw-bold small">
                                            Transaksi tanggal {{ formatIndoDate(reportData.start_date) }} - {{ formatIndoDate(reportData.end_date) }}
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center gap-2">
                                        <label class="small text-muted fw-semibold d-none d-sm-inline">Filter:</label>
                                        <select v-model="reportPreset" @change="onReportPresetChange" class="form-select form-select-sm fw-semibold border-1 bg-light rounded-3 px-3 py-2" style="min-width: 160px;">
                                            <option value="this_month">Bulan Ini</option>
                                            <option value="this_year">Tahun Ini</option>
                                            <option value="today">Hari Ini</option>
                                            <option value="last_30_days">30 Hari Terakhir</option>
                                            <option value="last_7_days">7 Hari Terakhir</option>
                                            <option value="custom">Custom Tanggal</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Custom Date Inputs if Preset === custom -->
                                <div v-if="reportPreset === 'custom'" class="row g-2 my-3 p-3 bg-light rounded-3 border align-items-end">
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold text-secondary mb-1">Dari Tanggal</label>
                                        <input v-model="reportStartDate" type="date" class="form-control form-control-sm">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold text-secondary mb-1">Sampai Tanggal</label>
                                        <input v-model="reportEndDate" type="date" class="form-control form-control-sm">
                                    </div>
                                    <div class="col-md-4">
                                        <button @click="fetchReportStats" class="btn btn-sm btn-primary w-100 fw-bold py-2">
                                            <i class="fa-solid fa-filter me-1"></i> Terapkan Filter
                                        </button>
                                    </div>
                                </div>

                                <!-- Loading Spinner -->
                                <div v-if="reportLoading" class="text-center py-5">
                                    <div class="spinner-border text-primary me-2" role="status"></div>
                                    <span class="text-muted fw-semibold">Memuat data grafik...</span>
                                </div>

                                <!-- Chart Canvas -->
                                <div v-show="!reportLoading" class="mt-3" style="height: 320px; position: relative;">
                                    <canvas id="totalTransactionChart"></canvas>
                                </div>

                                <!-- Summary Stats Below Chart -->
                                <div class="mt-4 pt-3 border-top">
                                    <div class="text-success fw-bold small mb-1">
                                        Total data tanggal {{ formatIndoDate(reportData.start_date) }} - {{ formatIndoDate(reportData.end_date) }}
                                    </div>
                                    <div class="fs-2 fw-bold text-success mb-3">
                                        {{ formatNumber(reportData.summary?.total_orders || 0) }} transaksi
                                    </div>
                                    <div class="row g-3">
                                        <div class="col-6 col-sm-4 col-md-2">
                                            <div class="p-2 rounded bg-light border text-center">
                                                <div class="text-muted small">Omset</div>
                                                <div class="fw-bold text-dark fs-6">Rp {{ formatNumber(reportData.summary?.total_revenue || 0) }}</div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-4 col-md-2">
                                            <div class="p-2 rounded bg-light border text-center">
                                                <div class="text-muted small">Profit</div>
                                                <div class="fw-bold text-success fs-6">Rp {{ formatNumber(reportData.summary?.total_profit || 0) }}</div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-4 col-md-2">
                                            <div class="p-2 rounded bg-light border text-center">
                                                <div class="text-muted small">Lunas / Selesai</div>
                                                <div class="fw-bold text-success fs-6">{{ formatNumber(reportData.summary?.total_completed || 0) }}</div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-4 col-md-2">
                                            <div class="p-2 rounded bg-light border text-center">
                                                <div class="text-muted small">Pending</div>
                                                <div class="fw-bold text-warning fs-6">{{ formatNumber(reportData.summary?.total_pending || 0) }}</div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-4 col-md-2">
                                            <div class="p-2 rounded bg-light border text-center">
                                                <div class="text-muted small">Gagal / Expired</div>
                                                <div class="fw-bold text-danger fs-6">{{ formatNumber(reportData.summary?.total_failed || 0) }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Row for 2 Pie Charts -->
                        <div class="row g-4">
                            <!-- Pie Chart 1: Data Pembayaran / Status -->
                            <div class="col-lg-6">
                                <div class="card-custom h-100">
                                    <div class="card-body-custom d-flex flex-column">
                                        <h6 class="fw-bold text-dark mb-1">Data Pembayaran / Status</h6>
                                        <div class="text-muted small mb-3">Persentase status transaksi</div>
                                        
                                        <div class="my-auto py-2" style="height: 220px; position: relative;">
                                            <canvas id="paymentStatusChart"></canvas>
                                        </div>

                                        <div class="mt-3 pt-3 border-top d-flex justify-content-center flex-wrap gap-3">
                                            <div class="d-flex align-items-center small gap-1">
                                                <span class="rounded-circle d-inline-block" style="width:12px; height:12px; background:#659b25;"></span>
                                                <span class="text-muted">Lunas:</span>
                                                <strong class="text-dark">{{ reportData.status_chart?.['Lunas / Selesai'] || 0 }}</strong>
                                            </div>
                                            <div class="d-flex align-items-center small gap-1">
                                                <span class="rounded-circle d-inline-block" style="width:12px; height:12px; background:#eab308;"></span>
                                                <span class="text-muted">Pending:</span>
                                                <strong class="text-dark">{{ reportData.status_chart?.['Pending'] || 0 }}</strong>
                                            </div>
                                            <div class="d-flex align-items-center small gap-1">
                                                <span class="rounded-circle d-inline-block" style="width:12px; height:12px; background:#dc2626;"></span>
                                                <span class="text-muted">Dibatalkan / Gagal:</span>
                                                <strong class="text-dark">{{ reportData.status_chart?.['Dibatalkan / Gagal'] || 0 }}</strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Pie Chart 2: Layanan Terlaris -->
                            <div class="col-lg-6">
                                <div class="card-custom h-100">
                                    <div class="card-body-custom d-flex flex-column">
                                        <h6 class="fw-bold text-dark mb-1">Top 5 Produk Terlaris</h6>
                                        <div class="text-muted small mb-3">Distribusi berdasarkan produk transaksi</div>
                                        
                                        <div class="my-auto py-2" style="height: 220px; position: relative;">
                                            <canvas id="serviceDistChart"></canvas>
                                        </div>

                                        <div class="mt-3 pt-3 border-top d-flex justify-content-center flex-wrap gap-2">
                                            <div v-for="(item, idx) in reportData.service_chart" :key="idx" class="d-flex align-items-center small gap-1 me-2 mb-1">
                                                <span class="rounded-circle d-inline-block" :style="{ width:'10px', height:'10px', background: ['#a0522d', '#2563eb', '#059669', '#d97706', '#9333ea'][idx % 5] }"></span>
                                                <span class="text-muted">{{ item.service }}:</span>
                                                <strong class="text-dark">{{ item.count }}</strong>
                                            </div>
                                            <div v-if="!reportData.service_chart || reportData.service_chart.length === 0" class="text-muted small">
                                                Belum ada data transaksi
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SUBTAB 2: EXPORT -->
                    <div v-if="reportSubTab === 'export'">
                        <div class="card-custom mb-4">
                            <div class="card-body-custom">
                                <h5 class="fw-bold text-dark mb-3">
                                    <i class="fa-solid fa-file-export text-primary me-2"></i> Export Data Transaksi
                                </h5>
                                <p class="text-muted small mb-4">
                                    Pilih rentang tanggal dan status transaksi untuk mengunduh laporan dalam format Excel/CSV atau JSON.
                                </p>

                                <div class="row g-3 align-items-end mb-4">
                                    <div class="col-md-3">
                                        <label class="form-label small fw-bold text-secondary">Preset Tanggal</label>
                                        <select v-model="reportPreset" @change="onReportPresetChange" class="form-select">
                                            <option value="this_month">Bulan Ini</option>
                                            <option value="this_year">Tahun Ini</option>
                                            <option value="today">Hari Ini</option>
                                            <option value="last_30_days">30 Hari Terakhir</option>
                                            <option value="last_7_days">7 Hari Terakhir</option>
                                            <option value="custom">Custom Tanggal</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small fw-bold text-secondary">Dari Tanggal</label>
                                        <input v-model="reportStartDate" type="date" class="form-control">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small fw-bold text-secondary">Sampai Tanggal</label>
                                        <input v-model="reportEndDate" type="date" class="form-control">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small fw-bold text-secondary">Status Transaksi</label>
                                        <select v-model="reportStatusFilter" class="form-select">
                                            <option value="">Semua Status</option>
                                            <option value="completed">Completed / Sukses</option>
                                            <option value="pending">Pending / Active</option>
                                            <option value="failed">Failed / Gagal / Expired</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="d-flex flex-wrap gap-3 pt-3 border-top">
                                    <button @click="triggerExport('csv')" class="btn btn-success py-2 px-4 fw-bold shadow-sm rounded-3">
                                        <i class="fa-solid fa-file-excel me-2"></i> Export Ke Excel / CSV
                                    </button>
                                    <button @click="triggerExport('json')" class="btn btn-outline-dark py-2 px-4 fw-bold rounded-3">
                                        <i class="fa-solid fa-file-code me-2"></i> Export Format JSON
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- [POSISI_KONTEN_TAB] TAMBAHKAN TAMPILAN / KONTEN TAB BARU DI SINI -->
                </div> <!-- /container-fluid -->
            </main>

            <!-- [POSISI_MODAL_BARU] TAMBAHKAN MODAL / POPUP BOOTSTRAP BARU DI SINI -->

            <!-- Modal Detail Data -->
            <div class="modal fade" id="detailsModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">

                        <div class="modal-header bg-light border-bottom px-4 py-3">
                            <div class="d-flex align-items-center">
                                <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fa-solid fa-circle-info"></i>
                                </div>
                                <div>
                                    <h5 class="modal-title fw-bold mb-0">Detail Informasi</h5>
                                    <p class="text-muted small mb-0" v-if="selectedItem">
                                        {{ selectedItem.ref_id
                                        ? 'Transaksi #' + selectedItem.ref_id
                                        : 'Produk: ' + selectedItem.product_name
                                        }}
                                    </p>
                                </div>
                            </div>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>

                        <div class="modal-body p-0" style="max-height: 70vh; overflow-y: auto;">
                            <div v-if="selectedItem">

                                <!-- Status -->
                                <div class="p-4 bg-white border-bottom d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between gap-3">
                                    <div>
                                        <div class="text-muted small fw-bold text-uppercase mb-1" style="font-size: 11px;">
                                            Status Saat Ini
                                        </div>

                                        <!-- Status utama -->
                                        <span v-if="selectedItem.status"
                                            :class="`status-badge fs-6 px-3 py-2 ${
                                    selectedItem.status === 'Sukses' 
                                        ? 'status-success' 
                                        : (selectedItem.status === 'Pending' 
                                            ? 'status-warning' 
                                            : 'status-danger')
                                }`">

                                            <i :class="selectedItem.status === 'Sukses' 
                                    ? 'fa-solid fa-check-circle' 
                                    : (selectedItem.status === 'Pending' 
                                        ? 'fa-solid fa-clock' 
                                        : 'fa-solid fa-circle-xmark')"></i>

                                            {{ selectedItem.status }}
                                        </span>

                                        <!-- Status fallback -->
                                        <span v-else-if="selectedItem.buyer_product_status !== undefined"
                                            :class="`status-badge fs-6 px-3 py-2 ${
                                    selectedItem.buyer_product_status == 1 && selectedItem.seller_product_status == 1 
                                        ? 'status-success' 
                                        : 'status-danger'
                                }`">

                                            {{ selectedItem.buyer_product_status == 1 && selectedItem.seller_product_status == 1
                                            ? 'Aktif'
                                            : 'Gangguan'
                                            }}
                                        </span>
                                    </div>

                                    <!-- Update Status (Manual) -->
                                    <div v-if="selectedItem.ref_id" class="d-flex flex-column gap-1 bg-light rounded-3 border px-3 py-2">
                                        <div class="text-muted small fw-bold text-uppercase mb-1" style="font-size: 11px;">
                                            Aksi Admin (Update Status Manual)
                                        </div>
                                        <div class="d-flex align-items-center gap-2">
                                            <select v-model="manualStatusToUpdate" class="form-select form-select-sm" style="width: 140px;">
                                                <option value="" disabled>-- Pilih Status --</option>
                                                <option value="Sukses">Sukses</option>
                                                <option value="Pending">Pending</option>
                                                <option value="Gagal">Batalkan</option>
                                            </select>
                                            <button @click="submitManualStatus(selectedItem.ref_id)" class="btn btn-sm btn-primary text-nowrap" :disabled="loading.updatingStatus">
                                                <i v-if="loading.updatingStatus" class="fa-solid fa-spinner fa-spin me-1"></i>
                                                <span v-else><i class="fa-solid fa-paper-plane me-1"></i> Update</span>
                                            </button>
                                        </div>
                                    </div>

                                    <div v-if="selectedItem.ref_id" class="d-flex align-items-center">
                                        <button @click="copyTrxSummary(selectedItem)"
                                            class="btn btn-outline-primary btn-sm rounded-pill px-3">
                                            <i class="fa-solid fa-share-nodes me-1"></i> Salin Ringkasan
                                        </button>
                                    </div>
                                </div>

                                <!-- Data -->
                                <div class="row g-0">
                                    <div v-for="(val, key) in selectedItem" :key="key"
                                        class="col-md-6 border-bottom border-end">

                                        <div class="p-3 h-100">
                                            <div class="text-muted small fw-bold text-uppercase mb-1"
                                                style="font-size: 10px;">
                                                {{ key.replace(/_/g, ' ') }}
                                            </div>

                                            <div class="d-flex justify-content-between">

                                                <div class="fw-medium" style="word-break: break-word;">

                                                    <!-- Null -->
                                                    <span v-if="val === null || val === ''"
                                                        class="text-muted fst-italic">
                                                        null
                                                    </span>

                                                    <!-- Object -->
                                                    <div v-else-if="typeof val === 'object'">
                                                        <pre class="bg-light p-2 rounded small mb-0">
                                                        {{ JSON.stringify(val, null, 2) }}
                                                        </pre>
                                                    </div>

                                                    <!-- Boolean -->
                                                    <div v-else-if="typeof val === 'boolean'">
                                                        <span :class="val ? 'text-success' : 'text-danger'">
                                                            {{ val ? 'TRUE' : 'FALSE' }}
                                                        </span>
                                                    </div>

                                                    <!-- Harga -->
                                                    <span v-else-if="['price','selling_price','sell_price','margin'].includes(key)"
                                                        class="text-primary fw-bold">
                                                        Rp {{ formatNumber(val) }}
                                                    </span>

                                                    <!-- Tanggal -->
                                                    <span v-else-if="['created_at','updated_at'].includes(key)">
                                                        {{ formatDate(val) }}
                                                    </span>

                                                    <!-- Default -->
                                                    <span v-else>
                                                        {{ val }}
                                                    </span>
                                                </div>

                                                <!-- Copy -->
                                                <button v-if="['ref_id','sn','buyer_sku_code','customer_no'].includes(key) && val"
                                                    @click="copyToClipboard(val)"
                                                    class="btn btn-sm text-muted">
                                                    <i class="fa-regular fa-copy"></i>
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="modal-footer bg-light">
                            <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Modal Edit Nama Produk -->
            <div class="modal fade" id="editProductModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
                        <div class="modal-header bg-light border-bottom px-4 py-3">
                            <div class="d-flex align-items-center">
                                <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fa-solid fa-pencil"></i>
                                </div>
                                <div>
                                    <h5 class="modal-title fw-bold mb-0">Edit Nama Produk</h5>
                                    <p class="text-muted small mb-0">Ubah nama visual produk</p>
                                </div>
                            </div>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body p-4">
                            <div class="mb-3">
                                <label class="form-label small fw-bold text-muted text-uppercase mb-1" style="font-size: 11px;">SKU Produk</label>
                                <input type="text" :value="editingProduct.buyer_sku_code" class="form-control bg-light font-monospace" readonly disabled>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold text-muted text-uppercase mb-1" style="font-size: 11px;">Nama Produk</label>
                                <input type="text" v-model="editingProduct.product_name" class="form-control" placeholder="Masukkan nama produk baru..." @keyup.enter="submitEditProductName">
                            </div>
                        </div>
                        <div class="modal-footer bg-light px-4 py-3 border-top">
                            <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                            <button type="button" class="btn btn-primary rounded-pill px-4" @click="submitEditProductName" :disabled="loading.updatingProduct">
                                <i v-if="loading.updatingProduct" class="fa-solid fa-spinner fa-spin me-1"></i> Simpan
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Atur Harga Membership (Mobile Friendly & Responsive) -->
            <div class="modal fade" id="membershipPricesModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-fullscreen-md-down modal-xl modal-dialog-scrollable">
                    <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
                        <div class="modal-header bg-light border-bottom px-4 py-3">
                            <div class="d-flex align-items-center">
                                <div class="bg-warning bg-opacity-10 text-warning rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fa-solid fa-tags"></i>
                                </div>
                                <div class="text-start">
                                    <h5 class="modal-title fw-bold mb-0">Atur Penyesuaian Harga</h5>
                                    <p class="text-muted small mb-0">Tier: <strong class="text-primary">{{ selectedMembershipName }}</strong></p>
                                </div>
                            </div>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body p-3 p-md-4 bg-light bg-opacity-30">
                            <!-- Filter & Pencarian -->
                            <div class="row g-2 mb-4 text-start">
                                <div class="col-12 col-md-4">
                                    <form @submit.prevent="fetchMembershipPrices(true)">
                                        <div class="input-group input-group-sm rounded-pill shadow-xs overflow-hidden bg-white border">
                                            <span class="input-group-text bg-white border-0 text-muted ps-3"><i class="fa-solid fa-magnifying-glass"></i></span>
                                            <input v-model="searchMembershipProduct" type="text" class="form-control border-0 ps-0 text-start" placeholder="Cari SKU, brand, nama...">
                                            <button class="btn btn-primary px-3 text-nowrap" type="submit">Cari</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-6 col-md-4">
                                    <select v-model="membershipProductType" @change="fetchMembershipPrices(true)" class="form-select form-select-sm rounded-pill shadow-xs">
                                        <option value="prepaid">⚡ Prabayar</option>
                                        <option value="postpaid">🧾 Pascabayaran</option>
                                    </select>
                                </div>
                                <div class="col-6 col-md-4">
                                    <select v-model="itemsPerPageMembershipProducts" @change="fetchMembershipPrices(true)" class="form-select form-select-sm rounded-pill shadow-xs">
                                        <option value="10">10 per halaman</option>
                                        <option value="20">20 per halaman</option>
                                        <option value="50">50 per halaman</option>
                                        <option value="100">100 per halaman</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Form Atur Margin -->
                            <div class="card border-0 shadow-xs mb-4 rounded-3" style="background: #ffffff; border-left: 5px solid var(--primary) !important;">
                                <div class="card-body p-3">
                                    <div class="row g-3 align-items-center justify-content-between">
                                        <div class="col-12 col-md-auto text-start">
                                            <span class="d-block text-secondary small fw-bold text-uppercase mb-1" style="font-size: 11px;">Status Pilihan</span>
                                            <span class="text-dark fw-semibold" style="font-size: 14px;">
                                                Terpilih: <span class="badge bg-primary rounded-pill px-2.5 py-1">{{ selectedMembershipProducts.length }}</span> produk dari {{ totalMembershipProducts }} produk terbaca
                                            </span>
                                        </div>
                                        <div class="col-12 col-md-auto">
                                            <div class="d-flex align-items-center gap-2 justify-content-start justify-content-md-end">
                                                <div class="input-group input-group-sm w-100" style="max-width: 250px;">
                                                    <span class="input-group-text bg-light fw-bold text-secondary">Nominal (+/-)</span>
                                                    <input v-model="membershipPriceAdjustment" type="number" class="form-control bg-white text-start" placeholder="Misal: 300, -500">
                                                </div>
                                                <button @click="saveMembershipPrice" :disabled="selectedMembershipProducts.length === 0" class="btn btn-sm btn-success px-3 fw-bold rounded-pill text-nowrap">
                                                    <i class="fa-solid fa-save me-1"></i> Terapkan
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- DESKTOP VIEW: Beautiful Table -->
                            <div class="d-none d-md-block">
                                <div class="table-responsive border rounded-3 bg-white shadow-xs">
                                    <table class="table table-custom table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th class="text-center" style="width: 50px;">
                                                    <input type="checkbox" :checked="selectAllMembership" @change="toggleSelectAllMembership" class="form-check-input">
                                                </th>
                                                <th class="text-start">SKU Buyer</th>
                                                <th class="text-start">Nama Produk</th>
                                                <th class="text-start">Kategori</th>
                                                <th class="text-start">Harga Base</th>
                                                <th class="text-end">Harga Jual</th>
                                                <th class="text-center">Penyesuaian</th>
                                                <th class="text-end text-primary">Harga Member</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-if="membershipProducts.length === 0">
                                                <td colspan="8" class="text-center py-5 text-muted">Produk tidak ditemukan</td>
                                            </tr>
                                            <tr v-for="p in membershipProducts" :key="p.buyer_sku_code">
                                                <td class="text-center">
                                                    <input type="checkbox" :value="p.buyer_sku_code" v-model="selectedMembershipProducts" class="form-check-input">
                                                </td>
                                                <td class="text-start"><code class="text-secondary small">{{ p.buyer_sku_code }}</code></td>
                                                <td class="text-start fw-medium text-dark">{{ p.product_name }}</td>
                                                <td class="text-start"><span class="badge bg-secondary bg-opacity-10 text-secondary">{{ p.category }}</span></td>
                                                <td class="text-start">Rp {{ formatNumber(p.price) }}</td>
                                                <td class="text-end fw-semibold">Rp {{ formatNumber(p.sell_price) }}</td>
                                                <td class="text-center">
                                                    <span v-if="p.price_adjustment > 0" class="badge bg-success bg-opacity-15 text-success fw-bold">+{{ formatNumber(p.price_adjustment) }}</span>
                                                    <span v-else-if="p.price_adjustment < 0" class="badge bg-danger bg-opacity-15 text-danger fw-bold">{{ formatNumber(p.price_adjustment) }}</span>
                                                    <span v-else class="text-muted small">-</span>
                                                </td>
                                                <td class="text-end fw-bold text-primary">
                                                    Rp {{ formatNumber(parseInt(p.sell_price) + parseInt(p.price_adjustment)) }}
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- MOBILE VIEW: Exquisite Touch Cards -->
                            <div class="d-md-none text-start">
                                <div v-if="membershipProducts.length === 0" class="text-center py-5 text-muted bg-white border rounded-3">
                                    Produk tidak ditemukan
                                </div>
                                <div v-else>
                                    <div class="d-flex align-items-center justify-content-between p-2.5 mb-3 bg-light rounded-3 border">
                                        <label class="form-check-label d-flex align-items-center cursor-pointer small fw-bold text-secondary mb-0">
                                            <input type="checkbox" :checked="selectAllMembership" @change="toggleSelectAllMembership" class="form-check-input me-2">
                                            Pilih Semua Halaman Ini
                                        </label>
                                        <span class="badge bg-secondary rounded-pill small">{{ selectedMembershipProducts.length }} Terpilih</span>
                                    </div>

                                    <!-- Product Cards Loop -->
                                    <div v-for="p in membershipProducts" :key="p.buyer_sku_code" 
                                         class="card border-0 mb-3 rounded-3 shadow-xs border-start border-4"
                                         :style="{ 'border-left-color': selectedMembershipProducts.includes(p.buyer_sku_code) ? 'var(--primary) !important' : '#cbd5e1 !important' }"
                                         style="background: #ffffff;">
                                        <label class="d-block p-3 m-0 cursor-pointer w-100">
                                            <div class="d-flex align-items-start gap-2">
                                                <input type="checkbox" :value="p.buyer_sku_code" v-model="selectedMembershipProducts" class="form-check-input mt-1 me-2">
                                                <div class="flex-grow-1">
                                                    <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                                                        <span class="badge bg-light text-secondary border font-monospace px-2 py-0.5" style="font-size: 11px;">{{ p.buyer_sku_code }}</span>
                                                        <span class="badge bg-secondary bg-opacity-10 text-secondary px-2 py-0.5" style="font-size: 11px;">{{ p.category }}</span>
                                                    </div>
                                                    <h6 class="fw-bold text-dark mb-1" style="font-size: 14.5px; line-height: 1.4;">{{ p.product_name }}</h6>
                                                    <div class="text-xs text-muted mb-3" style="font-size: 11.5px; font-weight: 500;">Brand: {{ p.brand }}</div>
                                                    
                                                    <div class="row g-2 pt-2 border-top border-light text-start">
                                                        <div class="col-6">
                                                            <span class="text-muted d-block text-xs mb-1" style="font-size: 11px;">Base / Jual</span>
                                                            <span class="text-dark fw-bold d-block small" style="font-size: 12px;">Rp{{ formatNumber(p.price) }} / Rp{{ formatNumber(p.sell_price) }}</span>
                                                        </div>
                                                        <div class="col-6 text-end">
                                                            <span class="text-muted d-block text-xs mb-1" style="font-size: 11px;">Penyesuaian</span>
                                                            <span v-if="p.price_adjustment > 0" class="badge bg-success bg-opacity-15 text-success fw-bold">+{{ formatNumber(p.price_adjustment) }}</span>
                                                            <span v-else-if="p.price_adjustment < 0" class="badge bg-danger bg-opacity-15 text-danger fw-bold">{{ formatNumber(p.price_adjustment) }}</span>
                                                            <span v-else class="text-muted small">-</span>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center mt-2.5 pt-2.5 border-top border-light">
                                                        <span class="text-primary fw-bold" style="font-size: 12.5px;">Harga Member:</span>
                                                        <span class="text-primary fw-extrabold" style="font-size: 16.5px;">
                                                            Rp{{ formatNumber(parseInt(p.sell_price) + parseInt(p.price_adjustment)) }}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <!-- Pagination Footer -->
                            <div class="d-flex flex-column flex-sm-row align-items-center justify-content-between mt-4 gap-3 bg-white p-3 rounded-3 border">
                                <div class="text-secondary small text-center text-sm-start fw-medium">
                                    Menampilkan {{ membershipProducts.length }} dari {{ totalMembershipProducts }} produk
                                </div>
                                <div class="d-flex align-items-center justify-content-center gap-1">
                                    <button class="btn btn-outline-secondary btn-sm rounded-pill px-3" :disabled="currentPageMembershipProducts === 1" @click="currentPageMembershipProducts--; fetchMembershipPrices()">
                                        <i class="fa-solid fa-angle-left me-1"></i> Sblm
                                    </button>
                                    <span class="mx-2 small fw-bold">Halaman {{ currentPageMembershipProducts }}</span>
                                    <button class="btn btn-outline-secondary btn-sm rounded-pill px-3" :disabled="!hasNextMembershipProducts" @click="currentPageMembershipProducts++; fetchMembershipPrices()">
                                        Skrg <i class="fa-solid fa-angle-right ms-1"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer bg-light px-4 py-3 border-top">
                            <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Tutup / Selesai</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Member Detail Modal -->
            <div class="modal fade" id="memberDetailModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-scrollable text-start">
                    <div class="modal-content border-0 shadow-lg rounded-4">
                        <div class="modal-header bg-dark text-white border-0 px-4 py-3">
                            <h5 class="modal-title fw-bold">
                                <i class="fa-solid fa-address-card me-2 text-info"></i>Detail & Riwayat Member
                            </h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body p-4 bg-light">
                            <div v-if="loading.memberDetail" class="text-center py-5">
                                <div class="spinner-border text-primary" role="status"></div>
                                <div class="mt-2 text-muted small">Memuat data detail member...</div>
                            </div>
                            <div v-else-if="selectedMember">
                                <!-- Grid Info Utama -->
                                <div class="bg-white p-4 rounded-3 border mb-4">
                                    <h6 class="fw-bold mb-3 border-bottom pb-2 text-primary">
                                        <i class="fa-solid fa-user me-2"></i>Profil Utama
                                    </h6>
                                    <div class="row g-3">
                                        <div class="col-sm-6 text-start">
                                            <div class="text-muted small">ID User</div>
                                            <div class="fw-bold text-dark fs-5 font-mono">{{ selectedMember.id_user }}</div>
                                        </div>
                                        <div class="col-sm-6 text-start">
                                            <div class="text-muted small">Nama Lengkap</div>
                                            <div class="fw-bold text-dark fs-5">{{ selectedMember.nama_user }}</div>
                                        </div>
                                        <div class="col-sm-6 text-start">
                                            <div class="text-muted small">Nomor Telepon</div>
                                            <div class="fw-semibold text-dark">{{ selectedMember.nomor_telepon || '-' }}</div>
                                        </div>
                                        <div class="col-sm-6 text-start">
                                            <div class="text-muted small">Email Address</div>
                                            <div class="fw-semibold text-dark">{{ selectedMember.email_user || '-' }}</div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Grid Keuangan & Membership -->
                                <div class="row g-3 mb-4">
                                    <div class="col-sm-6">
                                        <div class="bg-white p-4 rounded-3 border h-100">
                                            <h6 class="fw-bold mb-3 border-bottom pb-2 text-success">
                                                <i class="fa-solid fa-wallet me-2"></i>Keuangan & Status
                                            </h6>
                                            <div class="d-flex justify-content-between mb-2">
                                                <span class="text-muted small">Saldo Member:</span>
                                                <span class="fw-bold text-success">Rp{{ formatNumber(selectedMember.saldo_user || 0) }}</span>
                                            </div>
                                            <div class="d-flex justify-content-between mb-2">
                                                <span class="text-muted small">Poin Member:</span>
                                                <span class="fw-bold text-warning">{{ selectedMember.poin_member || 0 }} Poin</span>
                                            </div>
                                            <div class="d-flex justify-content-between mb-2">
                                                <span class="text-muted small">Tier Membership:</span>
                                                <span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25">{{ selectedMember.nama_membership || 'Umum' }}</span>
                                            </div>
                                            <div class="d-flex justify-content-between">
                                                <span class="text-muted small">Terakhir Login:</span>
                                                <span class="fw-semibold text-dark">{{ selectedMember.last_login || '-' }}</span>
                                            </div>
                                            <div class="d-flex justify-content-between">
                                                <span class="text-muted small">Perangkat:</span>
                                                <span class="fw-semibold text-dark">{{ selectedMember.ua || '-' }}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="bg-white p-4 rounded-3 border h-100">
                                            <h6 class="fw-bold mb-3 border-bottom pb-2 text-warning">
                                                <i class="fa-solid fa-credit-card me-2"></i>Paylater & Pinjaman
                                            </h6>
                                            <div class="d-flex justify-content-between mb-2">
                                                <span class="text-muted small">Paylater Aktif:</span>
                                                <span :class="selectedMember.paylater === 'ya' ? 'text-success fw-bold' : 'text-muted'">
                                                    {{ selectedMember.paylater === 'ya' ? 'Aktif' : 'Tidak' }}
                                                </span>
                                            </div>
                                            <div class="d-flex justify-content-between mb-2">
                                                <span class="text-muted small">Limit Paylater:</span>
                                                <span class="fw-bold text-dark">Rp{{ formatNumber(selectedMember.limit || 0) }}</span>
                                            </div>
                                            <div class="d-flex justify-content-between mb-2">
                                                <span class="text-muted small">Sisa Pinjaman:</span>
                                                <span class="fw-bold text-danger">Rp{{ formatNumber(selectedMember.sisa_pinjaman || 0) }}</span>
                                            </div>
                                            <div class="d-flex justify-content-between mb-2">
                                                <span class="text-muted small">Total Pinjaman:</span>
                                                <span class="fw-bold text-dark">Rp{{ formatNumber(selectedMember.total_pinjaman || 0) }}</span>
                                            </div>
                                            <div class="d-flex justify-content-between">
                                                <span class="text-muted small">Total Pembayaran:</span>
                                                <span class="fw-bold text-success">Rp{{ formatNumber(selectedMember.total_bayar || 0) }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Pembatasan Produk (SKU Dibatasi) -->
                                <div class="bg-white p-4 rounded-3 border mb-4">
                                    <h6 class="fw-bold mb-2 border-bottom pb-2 text-danger">
                                        <i class="fa-solid fa-ban me-2"></i>Pembatasan Produk (SKU Dibatasi)
                                    </h6>
                                    <div v-if="selectedMember.restricted_products" class="d-flex flex-wrap gap-1 mt-2">
                                        <span v-for="sku in selectedMember.restricted_products.split(',').map(s => s.trim())" :key="sku" class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-2.5 py-1.5 font-mono">
                                            <i class="fa-solid fa-circle-xmark me-1"></i>{{ sku }}
                                        </span>
                                    </div>
                                    <div v-else class="text-muted small py-1">
                                        <i class="fa-solid fa-check-circle text-success me-1"></i>Tidak ada pembatasan produk untuk member ini. Semua SKU dapat dibeli.
                                    </div>
                                </div>

                                <!-- Tabel Riwayat Transaksi Member -->
                                <div class="bg-white p-4 rounded-3 border">
                                    <h6 class="fw-bold mb-3 border-bottom pb-2 text-dark">
                                        <i class="fa-solid fa-history me-2"></i>50 Transaksi Terakhir
                                    </h6>
                                    <div class="table-responsive" style="max-height: 250px;">
                                        <table class="table table-sm align-middle table-hover small">
                                            <thead>
                                                <tr class="table-light">
                                                    <th>Ref ID</th>
                                                    <th>Produk</th>
                                                    <th>Tujuan</th>
                                                    <th class="text-end">Harga</th>
                                                    <th class="text-center">Status</th>
                                                    <th>Waktu</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr v-for="t in selectedMemberTransactions" :key="t.ref_id">
                                                    <td class="font-mono text-xs fw-bold text-start">{{ t.ref_id }}</td>
                                                    <td class="text-start">
                                                        <div>{{ t.product_name || t.buyer_sku_code }}</div>
                                                        <div class="text-muted font-mono text-xs">{{ t.buyer_sku_code }}</div>
                                                    </td>
                                                    <td class="font-mono text-xs text-start">{{ t.customer_no }}</td>
                                                    <td class="text-end fw-semibold">Rp{{ formatNumber(t.selling_price || 0) }}</td>
                                                    <td class="text-center">
                                                        <span :class="'badge ' + getStatusClass(t.status)">{{ t.status }}</span>
                                                    </td>
                                                    <td class="text-muted text-xs text-start">{{ t.created_at }}</td>
                                                </tr>
                                                <tr v-if="selectedMemberTransactions.length === 0">
                                                    <td colspan="6" class="text-center text-muted py-4">Belum ada riwayat transaksi.</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer bg-light px-4 py-3 border-top">
                            <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Tutup / Kembali</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Member Edit / Add Modal -->
            <div class="modal fade" id="memberEditModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg text-start">
                    <div class="modal-content border-0 shadow-lg rounded-4">
                        <form @submit.prevent="saveMember">
                            <div class="modal-header bg-primary text-white border-0 px-4 py-3">
                                <h5 class="modal-title fw-bold text-white">
                                    <i class="fa-solid fa-user-gear me-2"></i>{{ isEditMode ? 'Edit Data Member' : 'Tambah Member Baru' }}
                                </h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body p-4 bg-light">
                                <div class="row g-3">
                                    <!-- ID User (Only writable in Create mode) -->
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold text-secondary">ID User / Username <span class="text-danger">*</span></label>
                                        <input v-model="memberForm.id_user" type="text" class="form-control font-mono" :disabled="isEditMode" required placeholder="Contoh: uki123">
                                    </div>

                                    <!-- Nama User -->
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold text-secondary">Nama Lengkap <span class="text-danger">*</span></label>
                                        <input v-model="memberForm.nama_user" type="text" class="form-control" required placeholder="Nama lengkap user">
                                    </div>

                                    <!-- Nomor Telepon -->
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold text-secondary">Nomor Telepon</label>
                                        <input v-model="memberForm.nomor_telepon" type="text" class="form-control" placeholder="Contoh: 08123456789">
                                    </div>

                                    <!-- Email User -->
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold text-secondary">Email</label>
                                        <input v-model="memberForm.email_user" type="email" class="form-control" placeholder="Contoh: user@domain.com">
                                    </div>

                                    <!-- Saldo User -->
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold text-secondary">Saldo User (Rp)</label>
                                        <input v-model.number="memberForm.saldo_user" type="number" class="form-control" placeholder="Saldo member">
                                    </div>

                                    <!-- Poin Member -->
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold text-secondary">Poin Member</label>
                                        <input v-model.number="memberForm.poin_member" type="number" class="form-control" placeholder="Poin">
                                    </div>

                                    <!-- Membership -->
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold text-secondary">Tier Membership</label>
                                        <select v-model="memberForm.nama_membership" class="form-select">
                                            <option value="Umum">Umum</option>
                                            <option v-for="m in memberships" :key="m.name" :value="m.name">{{ m.name }}</option>
                                        </select>
                                    </div>

                                    <div class="col-12 mt-4 border-top pt-3">
                                        <h6 class="fw-bold text-warning mb-3"><i class="fa-solid fa-credit-card me-1 text-warning"></i>Paylater & Pinjaman</h6>
                                    </div>

                                    <!-- Paylater Status -->
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold text-secondary">Aktifkan Paylater</label>
                                        <select v-model="memberForm.paylater" class="form-select">
                                            <option value="tidak">Tidak</option>
                                            <option value="ya">Ya / Aktif</option>
                                        </select>
                                    </div>

                                    <!-- Limit Paylater -->
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold text-secondary">Limit Paylater (Rp)</label>
                                        <input v-model.number="memberForm.limit" type="number" class="form-control" :disabled="memberForm.paylater !== 'ya'" placeholder="Limit kredit">
                                    </div>

                                    <!-- Sisa Pinjaman -->
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold text-secondary">Sisa Pinjaman (Rp)</label>
                                        <input v-model.number="memberForm.sisa_pinjaman" type="number" class="form-control" :disabled="memberForm.paylater !== 'ya'" placeholder="Pinjaman saat ini">
                                    </div>

                                    <!-- Total Pinjaman -->
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold text-secondary">Total Akumulasi Pinjaman (Rp)</label>
                                        <input v-model.number="memberForm.total_pinjaman" type="number" class="form-control" :disabled="memberForm.paylater !== 'ya'" placeholder="Total pinjaman pernah dipinjam">
                                    </div>

                                    <!-- Total Bayar -->
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold text-secondary">Total Akumulasi Pembayaran (Rp)</label>
                                        <input v-model.number="memberForm.total_bayar" type="number" class="form-control" :disabled="memberForm.paylater !== 'ya'" placeholder="Total pinjaman pernah dibayar">
                                    </div>

                                    <div class="col-12 mt-4 border-top pt-3">
                                        <h6 class="fw-bold text-danger mb-3"><i class="fa-solid fa-ban me-1 text-danger"></i>Batasi Produk Tertentu (SKU Dibatasi)</h6>
                                    </div>

                                    <!-- Restricted Products -->
                                    <div class="col-12">
                                        <label class="form-label small fw-bold text-secondary">SKU Produk yang Dibatasi</label>
                                        <textarea v-model="memberForm.restricted_products" class="form-control font-mono" rows="2" placeholder="Masukkan kode SKU dipisahkan tanda koma (,), contoh: d5, d100, dST"></textarea>
                                        <div class="form-text text-muted small">
                                            User ini tidak akan bisa membeli produk yang memiliki SKU di atas. Pisahkan dengan tanda koma (,).
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer bg-light px-4 py-3 border-top">
                                <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary rounded-pill px-4" :disabled="loading.savingMember">
                                    <span v-if="loading.savingMember" class="spinner-border spinner-border-sm me-1" role="status"></span>
                                    <i v-else class="fa-solid fa-floppy-disk me-1"></i> Simpan Data
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script>
            const {
                createApp,
                ref,
                computed,
                onMounted
            } = Vue;

            createApp({
                setup() {
                    const activeTab = ref('dashboard');
                    const sidebarOpen = ref(false);
                    const config = ref({
                        okeconnect_member_id: '',
                        okeconnect_pin: '',
                        webhook_secret: '',
                        margin_global: 0,
                        ppob_secret: '',
                        token_bo: '',
                        telegram_bot_token_ppob: '',
                        telegram_chat_id: ''
                    });

                    const priceList = ref([]);
                    const priceType = ref('prepaid');
                    const searchProduct = ref('');
                    const productStatusFilter = ref('');
                    const productSortBy = ref('brand');
                    const productSortDir = ref('ASC');
                    const itemsPerPageProducts = ref(10);

                    const selectedProducts = ref([]);
                    const marginUpdate = ref({
                        type: 'selected',
                        category: '',
                        amount: ''
                    });
                    const displayUpdate = ref({
                        type: 'selected',
                        category: '',
                        display: 1
                    });

                    const transactions = ref([]);
                    const searchTransaction = ref('');
                    const transactionSortBy = ref('created_at');
                    const transactionSortDir = ref('DESC');
                    const itemsPerPageTransactions = ref(10);

                    const currentPageProducts = ref(1);
                    const currentPageTransactions = ref(1);
                    const hasNextProducts = ref(false);
                    const hasNextTransactions = ref(false);

                    const selectedItem = ref(null);

                    const dbError = ref(null);

                    // Membership state
                    const memberships = ref([]);
                    const newMembershipName = ref('');
                    const selectedMembershipName = ref('');
                    const membershipProducts = ref([]);
                    const searchMembershipProduct = ref('');
                    const currentPageMembershipProducts = ref(1);
                    const hasNextMembershipProducts = ref(false);
                    const totalMembershipProducts = ref(0);
                    const itemsPerPageMembershipProducts = ref(10);
                    const membershipProductType = ref('prepaid');
                    const selectedMembershipProducts = ref([]);
                    const membershipPriceAdjustment = ref('');
                    const selectAllMembership = ref(false);

                    const balance = ref(0);
                    const balanceError = ref('');

                    const stats = ref({
                        total_revenue: 0,
                        monthly_revenue: 0,
                        daily_revenue: 0,
                        monthly_orders: 0
                    });

                    const trx = ref({
                        type: 'prepaid',
                        command: 'inq-pasca',
                        sku: '',
                        customer_no: '',
                        ref_id: 'test-' + Date.now(),
                        testing: true
                    });

                    const trxResult = ref(null);

                    const security = ref({
                        username: '',
                        current_password: '',
                        new_password: '',
                        confirm_password: ''
                    });

                    const manualStatusToUpdate = ref('');

                    const editingProduct = ref({
                        buyer_sku_code: '',
                        product_name: ''
                    });

                    // Members state
                    const members = ref([]);
                    const searchMemberQuery = ref('');
                    const itemsPerPageMembers = ref(10);
                    const currentPageMembers = ref(1);
                    const totalMembers = ref(0);
                    const hasNextMembers = ref(false);
                    const selectedMember = ref(null);
                    const selectedMemberTransactions = ref([]);
                    const isEditMode = ref(false);
                    const memberForm = ref({
                        id_user: '',
                        nama_user: '',
                        nomor_telepon: '',
                        email_user: '',
                        saldo_user: 0,
                        poin_member: 0,
                        nama_membership: 'Umum',
                        paylater: 'tidak',
                        limit: 0,
                        sisa_pinjaman: 0,
                        total_pinjaman: 0,
                        total_bayar: 0,
                        restricted_products: ''
                    });

                    const loading = ref({
                        config: false,
                        prices: false,
                        trx: false,
                        margin: false,
                        security: false,
                        updatingStatus: false,
                        updatingProduct: false,
                        members: false,
                        memberDetail: false,
                        savingMember: false
                    });
                    const notification = ref({
                        show: false,
                        message: '',
                        type: 'success'
                    });

                    const showNotif = (msg, type = 'success') => {
                        notification.value = {
                            show: true,
                            message: msg,
                            type
                        };
                        setTimeout(() => notification.value.show = false, 3000);
                    };

                    const formatNumber = (num) => {
                        return new Intl.NumberFormat('id-ID').format(num || 0);
                    };

                    const uniqueCategories = computed(() => {
                        const cats = new Set(priceList.value.map(p => p.category));
                        return Array.from(cats).filter(Boolean).sort();
                    });

                    const filteredProducts = computed(() => {
                        return priceList.value;
                    });

                    const paginatedProducts = computed(() => {
                        return priceList.value;
                    });

                    const totalPagesProducts = computed(() => 1); // Not used with cursor pagination

                    const selectAll = computed(() => {
                        return paginatedProducts.value.length > 0 && selectedProducts.value.length === paginatedProducts.value.length;
                    });

                    const toggleSelectAll = (e) => {
                        if (e.target.checked) {
                            selectedProducts.value = paginatedProducts.value.map(p => p.buyer_sku_code);
                        } else {
                            selectedProducts.value = [];
                        }
                    };

                    const filteredTransactions = computed(() => {
                        return transactions.value;
                    });

                    const paginatedTransactions = computed(() => {
                        return transactions.value;
                    });

                    const totalPagesTransactions = computed(() => 1); // Not used with cursor pagination

                    const fetchConfig = async () => {
                        try {
                            const res = await fetch('?action=get_config');
                            const data = await res.json();
                            if (data.error) {
                                dbError.value = data.error;
                            } else {
                                config.value = data;
                                security.value.username = data.admin_username || '';
                                fetchProductsFromDB();
                                fetchTransactions();
                                fetchStats();
                                fetchBalance();
                            }
                        } catch (e) {
                            console.error('Failed to load config');
                        }
                    };

                    const fetchBalance = async () => {
                        try {
                            const res = await fetch('?action=get_balance');
                            const data = await res.json();
                            if (data.error) {
                                balanceError.value = data.error;
                            } else {
                                balance.value = data.balance;
                                balanceError.value = '';
                            }
                        } catch (e) {
                            console.error('Failed to load balance');
                        }
                    };

                    const fetchStats = async () => {
                        try {
                            const res = await fetch('?action=get_stats');
                            const data = await res.json();
                            if (!data.error) {
                                stats.value = data;
                            }
                        } catch (e) {
                            console.error('Failed to load stats');
                        }
                    };

                    const saveConfig = async () => {
                        loading.value.config = true;
                        try {
                            const res = await fetch('?action=save_config', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(config.value)
                            });
                            const data = await res.json();
                            showNotif(data.message, 'success');
                            fetchProductsFromDB(); // Refresh prices to show new margin
                        } catch (e) {
                            showNotif('Gagal menyimpan konfigurasi', 'error');
                        }
                        loading.value.config = false;
                    };

                    const fetchProductsFromDB = async (isNext = false, isPrev = false) => {
                        try {
                            let url = `?action=get_products&type=${priceType.value}`;
                            if (searchProduct.value) {
                                url += `&search=${encodeURIComponent(searchProduct.value)}`;
                            }
                            if (productStatusFilter.value) {
                                url += `&status=${encodeURIComponent(productStatusFilter.value)}`;
                            }
                            url += `&sort_by=${encodeURIComponent(productSortBy.value)}&sort_dir=${encodeURIComponent(productSortDir.value)}`;
                            url += `&limit=${itemsPerPageProducts.value}`;

                            if (isNext) {
                                currentPageProducts.value++;
                            } else if (isPrev) {
                                currentPageProducts.value--;
                            } else {
                                currentPageProducts.value = 1;
                            }
                            url += `&page=${currentPageProducts.value}`;

                            const res = await fetch(url);
                            const data = await res.json();
                            if (data.error) {
                                showNotif(data.error, 'error');
                                return;
                            }
                            priceList.value = data.data || [];
                            hasNextProducts.value = data.hasNext || false;
                            selectedProducts.value = []; // Reset selection
                        } catch (e) {
                            console.error('Gagal memuat produk dari DB');
                        }
                    };

                    const sortBy = (col) => {
                        if (productSortBy.value === col) {
                            productSortDir.value = productSortDir.value === 'ASC' ? 'DESC' : 'ASC';
                        } else {
                            productSortBy.value = col;
                            productSortDir.value = 'ASC';
                        }
                        fetchProductsFromDB(false, false);
                    };

                    const getSortIcon = (col) => {
                        if (productSortBy.value !== col) return 'fa-solid fa-sort text-muted opacity-50 ms-1';
                        return productSortDir.value === 'ASC' ? 'fa-solid fa-sort-up text-primary ms-1' : 'fa-solid fa-sort-down text-primary ms-1';
                    };

                    const sortTrx = (col) => {
                        if (transactionSortBy.value === col) {
                            transactionSortDir.value = transactionSortDir.value === 'ASC' ? 'DESC' : 'ASC';
                        } else {
                            transactionSortBy.value = col;
                            transactionSortDir.value = 'DESC'; // Default to DESC for transactions
                        }
                        fetchTransactions(false, false);
                    };

                    const getSortIconTrx = (col) => {
                        if (transactionSortBy.value !== col) return 'fa-solid fa-sort text-muted opacity-50 ms-1';
                        return transactionSortDir.value === 'ASC' ? 'fa-solid fa-sort-up text-primary ms-1' : 'fa-solid fa-sort-down text-primary ms-1';
                    };

                    const nextPageProducts = () => {
                        if (hasNextProducts.value) {
                            fetchProductsFromDB(true, false);
                        }
                    };

                    const prevPageProducts = () => {
                        if (currentPageProducts.value > 1) {
                            fetchProductsFromDB(false, true);
                        }
                    };

                    const updateMargin = async () => {
                        if (!marginUpdate.value.amount) {
                            showNotif('Masukkan jumlah margin', 'error');
                            return;
                        }

                        loading.value.margin = true;
                        try {
                            const payload = {
                                margin: marginUpdate.value.amount,
                                type: marginUpdate.value.type,
                                product_type: priceType.value
                            };

                            if (marginUpdate.value.type === 'selected') {
                                payload.skus = selectedProducts.value;
                            } else if (marginUpdate.value.type === 'category') {
                                payload.category = marginUpdate.value.category;
                            }

                            const res = await fetch('?action=update_margin', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(payload)
                            });
                            const data = await res.json();

                            if (data.error) throw new Error(data.error);

                            showNotif(data.message, 'success');
                            marginUpdate.value.amount = '';
                            selectedProducts.value = [];
                            fetchProductsFromDB();
                        } catch (e) {
                            showNotif(e.message || 'Gagal update margin', 'error');
                        }
                        loading.value.margin = false;
                    };
                    const updateDisplay = async () => {
                        loading.value.margin = true;
                        try {
                            const payload = {
                                display: Number(displayUpdate.value.display),
                                type: displayUpdate.value.type,
                                product_type: priceType.value
                            };

                            if (displayUpdate.value.type === 'selected') {
                                payload.skus = selectedProducts.value;
                            } else if (displayUpdate.value.type === 'category') {
                                payload.category = displayUpdate.value.category;
                            }

                            const res = await fetch('?action=update_display', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(payload)
                            });
                            const data = await res.json();

                            if (data.error) throw new Error(data.error);

                            showNotif(data.message, 'success');
                            selectedProducts.value = [];
                            fetchProductsFromDB();
                        } catch (e) {
                            showNotif(e.message || 'Gagal update display', 'error');
                        }
                        loading.value.margin = false;
                    };


                    const fetchTransactions = async (isNext = false, isPrev = false) => {
                        try {
                            let url = `?action=get_transactions`;
                            if (searchTransaction.value) {
                                url += `&search=${encodeURIComponent(searchTransaction.value)}`;
                            }
                            url += `&sort_by=${encodeURIComponent(transactionSortBy.value)}&sort_dir=${encodeURIComponent(transactionSortDir.value)}`;
                            url += `&limit=${itemsPerPageTransactions.value}`;

                            if (isNext) {
                                currentPageTransactions.value++;
                            } else if (isPrev) {
                                currentPageTransactions.value--;
                            } else {
                                currentPageTransactions.value = 1;
                            }
                            url += `&page=${currentPageTransactions.value}`;

                            const res = await fetch(url);
                            const data = await res.json();
                            if (data.error) {
                                console.error(data.error);
                                return;
                            }
                            transactions.value = data.data || [];
                            hasNextTransactions.value = data.hasNext || false;
                        } catch (e) {
                            console.error('Gagal memuat transaksi');
                        }
                    };

                    const nextPageTransactions = () => {
                        if (hasNextTransactions.value) {
                            fetchTransactions(true, false);
                        }
                    };

                    const prevPageTransactions = () => {
                        if (currentPageTransactions.value > 1) {
                            fetchTransactions(false, true);
                        }
                    };

                    const syncProducts = async () => {
                        loading.value.prices = true;
                        try {
                            const res = await fetch(`?action=sync_products&type=${priceType.value}`);
                            const data = await res.json();
                            if (data.error) throw new Error(data.error);
                            showNotif(data.message || 'Sinkronisasi berhasil!', 'success');
                            fetchProductsFromDB(); // Reload from DB after sync
                        } catch (e) {
                            showNotif(e.message || 'Gagal sinkronisasi daftar harga', 'error');
                        }
                        loading.value.prices = false;
                    };

                    const processTransaction = async () => {
                        if (!trx.value.sku || !trx.value.customer_no) {
                            showNotif('SKU dan Nomor Tujuan wajib diisi', 'error');
                            return;
                        }

                        loading.value.trx = true;
                        trxResult.value = null;

                        const payload = {
                            buyer_sku_code: trx.value.sku,
                            customer_no: trx.value.customer_no,
                            ref_id: trx.value.ref_id,
                            testing: trx.value.testing
                        };

                        if (trx.value.type === 'pasca') {
                            payload.commands = trx.value.command;
                        }

                        try {
                            const res = await fetch('?action=transaction', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(payload)
                            });
                            const data = await res.json();
                            trxResult.value = data;
                            fetchTransactions(); // Refresh transactions list
                            fetchStats();
                        } catch (e) {
                            trxResult.value = {
                                error: 'Terjadi kesalahan koneksi ke server lokal'
                            };
                        }
                        loading.value.trx = false;
                    };

                    const updateSecurity = async () => {
                        if (!security.value.username || !security.value.current_password) {
                            showNotif('Username dan Password Saat Ini wajib diisi', 'error');
                            return;
                        }

                        if (security.value.new_password && security.value.new_password !== security.value.confirm_password) {
                            showNotif('Konfirmasi password baru tidak cocok', 'error');
                            return;
                        }

                        loading.value.security = true;
                        try {
                            const res = await fetch('?action=update_security', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    username: security.value.username,
                                    current_password: security.value.current_password,
                                    new_password: security.value.new_password
                                })
                            });
                            const data = await res.json();
                            if (data.error) throw new Error(data.error);

                            showNotif(data.message, 'success');
                            security.value.current_password = '';
                            security.value.new_password = '';
                            security.value.confirm_password = '';
                        } catch (e) {
                            showNotif(e.message || 'Gagal memperbarui keamanan', 'error');
                        }
                        loading.value.security = false;
                    };

                    const {
                        nextTick
                    } = Vue;

                    const showDetails = async (item) => {
                        selectedItem.value = item;
                        manualStatusToUpdate.value = item.ref_id ? (item.status || '') : '';

                        await nextTick(); // ðŸ”¥ WAJIB

                        const modalEl = document.getElementById('detailsModal');
                        const modal = new bootstrap.Modal(modalEl);
                        modal.show();
                    };

                    const submitManualStatus = async (refId) => {
                        if (!manualStatusToUpdate.value) {
                            showNotif('Silakan pilih status terlebih dahulu', 'error');
                            return;
                        }

                        loading.value.updatingStatus = true;
                        try {
                            const statusVal = manualStatusToUpdate.value;
                            const res = await fetch(`hook.php?refid=${encodeURIComponent(refId)}&status=${encodeURIComponent(statusVal)}`);
                            const data = await res.json();
                            
                            if (data.status === 'success') {
                                showNotif('Status berhasil diperbarui via hook.php!', 'success');
                                if (selectedItem.value && selectedItem.value.ref_id === refId) {
                                    selectedItem.value.status = statusVal;
                                }
                                fetchTransactions();
                                fetchStats();
                            } else {
                                showNotif(data.message || 'Gagal memperbarui status', 'error');
                            }
                        } catch (e) {
                            showNotif('Koneksi gagal atau terjadi error di hook.php', 'error');
                        } finally {
                            loading.value.updatingStatus = false;
                        }
                    };

                    const openEditProduct = async (item) => {
                        editingProduct.value = {
                            buyer_sku_code: item.buyer_sku_code,
                            product_name: item.product_name
                        };
                        await nextTick();
                        const modalEl = document.getElementById('editProductModal');
                        const modal = new bootstrap.Modal(modalEl);
                        modal.show();
                    };

                    const submitEditProductName = async () => {
                        if (!editingProduct.value.product_name.trim()) {
                            showNotif('Nama produk tidak boleh kosong', 'error');
                            return;
                        }

                        loading.value.updatingProduct = true;
                        try {
                            const res = await fetch('?action=edit_product_name', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    buyer_sku_code: editingProduct.value.buyer_sku_code,
                                    product_name: editingProduct.value.product_name
                                })
                            });
                            const data = await res.json();
                            if (data.success) {
                                showNotif(data.message || 'Nama produk berhasil diperbarui', 'success');
                                
                                // Close modal
                                const modalEl = document.getElementById('editProductModal');
                                const modal = bootstrap.Modal.getInstance(modalEl);
                                if (modal) modal.hide();

                                // Refresh products list
                                fetchProductsFromDB();
                            } else {
                                showNotif(data.error || 'Gagal mengubah nama produk', 'error');
                            }
                        } catch (e) {
                            showNotif('Terjadi kesalahan koneksi', 'error');
                        } finally {
                            loading.value.updatingProduct = false;
                        }
                    };

                    const printReceipt = (ref_id) => {
                        window.open(`script/struk.html?ref_id=${ref_id}`, '_blank');
                    };

                    const formatDate = (date) => {
                        if (!date) return '-';
                        return new Date(date).toLocaleString('id-ID');
                    };

                    const fetchMemberships = async () => {
                        try {
                            const response = await fetch('admin.php?action=get_memberships');
                            const data = await response.json();
                            memberships.value = data;
                            if (data.length > 0 && !selectedMembershipName.value) {
                                selectedMembershipName.value = data[0].name;
                                await fetchMembershipPrices(true);
                            }
                        } catch (error) {
                            showNotif('Gagal memuat daftar membership', 'danger');
                        }
                    };

                    const createMembership = async () => {
                        if (!newMembershipName.value.trim()) return;
                        try {
                            const response = await fetch('admin.php?action=create_membership', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ name: newMembershipName.value.trim() })
                            });
                            const res = await response.json();
                            if (res.success) {
                                showNotif(res.message, 'success');
                                newMembershipName.value = '';
                                await fetchMemberships();
                            } else {
                                showNotif(res.message, 'danger');
                            }
                        } catch (error) {
                            showNotif('Gagal membuat membership', 'danger');
                        }
                    };

                    const deleteMembership = async (name) => {
                        if (!confirm(`Apakah Anda yakin ingin menghapus membership "${name}"? Semua penyesuaian harga terkait juga akan dihapus.`)) return;
                        try {
                            const response = await fetch('admin.php?action=delete_membership', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ name })
                            });
                            const res = await response.json();
                            if (res.success) {
                                showNotif(res.message, 'success');
                                if (selectedMembershipName.value === name) {
                                    selectedMembershipName.value = '';
                                }
                                await fetchMemberships();
                                if (selectedMembershipName.value) {
                                    await fetchMembershipPrices(true);
                                } else {
                                    membershipProducts.value = [];
                                }
                            } else {
                                showNotif(res.message, 'danger');
                            }
                        } catch (error) {
                            showNotif('Gagal menghapus membership', 'danger');
                        }
                    };

                    const fetchMembershipPrices = async (resetPage = false) => {
                        if (!selectedMembershipName.value) return;
                        if (resetPage) {
                            currentPageMembershipProducts.value = 1;
                        }
                        try {
                            const url = `admin.php?action=get_membership_prices&membership_name=${encodeURIComponent(selectedMembershipName.value)}&type=${membershipProductType.value}&search=${encodeURIComponent(searchMembershipProduct.value)}&page=${currentPageMembershipProducts.value}&limit=${itemsPerPageMembershipProducts.value}`;
                            const response = await fetch(url);
                            const res = await response.json();
                            membershipProducts.value = res.data || [];
                            hasNextMembershipProducts.value = res.hasNext || false;
                            totalMembershipProducts.value = res.total || 0;
                            selectedMembershipProducts.value = [];
                            selectAllMembership.value = false;
                        } catch (error) {
                            showNotif('Gagal memuat harga membership', 'danger');
                        }
                    };

                    const saveMembershipPrice = async () => {
                        if (!selectedMembershipName.value) {
                            showNotif('Silakan pilih atau buat membership terlebih dahulu', 'danger');
                            return;
                        }
                        if (selectedMembershipProducts.value.length === 0) {
                            showNotif('Silakan pilih produk terlebih dahulu', 'danger');
                            return;
                        }
                        if (membershipPriceAdjustment.value === '') {
                            showNotif('Silakan isi jumlah penyesuaian harga', 'danger');
                            return;
                        }
                        try {
                            const response = await fetch('admin.php?action=save_membership_price', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                    membership_name: selectedMembershipName.value,
                                    skus: selectedMembershipProducts.value,
                                    price_adjustment: parseInt(membershipPriceAdjustment.value, 10)
                                })
                            });
                            const res = await response.json();
                            if (res.success) {
                                showNotif(res.message, 'success');
                                membershipPriceAdjustment.value = '';
                                await fetchMembershipPrices();
                            } else {
                                showNotif(res.message, 'danger');
                            }
                        } catch (error) {
                            showNotif('Gagal menyimpan harga membership', 'danger');
                        }
                    };

                    const toggleSelectAllMembership = () => {
                        selectAllMembership.value = !selectAllMembership.value;
                        if (selectAllMembership.value) {
                            selectedMembershipProducts.value = membershipProducts.value.map(p => p.buyer_sku_code);
                        } else {
                            selectedMembershipProducts.value = [];
                        }
                    };

                    const fetchMembers = async (resetPage = false) => {
                        if (resetPage) {
                            currentPageMembers.value = 1;
                        }
                        loading.value.members = true;
                        try {
                            const url = `admin.php?action=get_members&search=${encodeURIComponent(searchMemberQuery.value)}&page=${currentPageMembers.value}&limit=${itemsPerPageMembers.value}`;
                            const response = await fetch(url);
                            const res = await response.json();
                            members.value = res.data || [];
                            totalMembers.value = res.total || 0;
                            hasNextMembers.value = res.hasNext || false;
                        } catch (error) {
                            showNotif('Gagal memuat data member', 'danger');
                        } finally {
                            loading.value.members = false;
                        }
                    };

                    const viewMemberDetail = async (member) => {
                        selectedMember.value = member;
                        selectedMemberTransactions.value = [];
                        loading.value.memberDetail = true;
                        
                        // Show modal
                        const modal = new bootstrap.Modal(document.getElementById('memberDetailModal'));
                        modal.show();

                        try {
                            const url = `admin.php?action=get_member_detail&id_user=${encodeURIComponent(member.id_user)}`;
                            const response = await fetch(url);
                            const res = await response.json();
                            if (res.error) {
                                showNotif(res.error, 'danger');
                            } else {
                                selectedMember.value = res.member;
                                selectedMemberTransactions.value = res.transactions || [];
                            }
                        } catch (error) {
                            showNotif('Gagal memuat detail member', 'danger');
                        } finally {
                            loading.value.memberDetail = false;
                        }
                    };

                    const openAddMemberModal = () => {
                        isEditMode.value = false;
                        memberForm.value = {
                            id_user: '',
                            nama_user: '',
                            nomor_telepon: '',
                            email_user: '',
                            saldo_user: 0,
                            poin_member: 0,
                            nama_membership: 'Umum',
                            paylater: 'tidak',
                            limit: 0,
                            sisa_pinjaman: 0,
                            total_pinjaman: 0,
                            total_bayar: 0,
                            restricted_products: ''
                        };
                        const modal = new bootstrap.Modal(document.getElementById('memberEditModal'));
                        modal.show();
                    };

                    const openEditMemberModal = (member) => {
                        isEditMode.value = true;
                        memberForm.value = {
                            id_user: member.id_user,
                            nama_user: member.nama_user,
                            nomor_telepon: member.nomor_telepon || '',
                            email_user: member.email_user || '',
                            saldo_user: parseInt(member.saldo_user || 0, 10),
                            poin_member: parseInt(member.poin_member || 0, 10),
                            nama_membership: member.nama_membership || 'Umum',
                            paylater: member.paylater || 'tidak',
                            limit: parseInt(member.limit || 0, 10),
                            sisa_pinjaman: parseInt(member.sisa_pinjaman || 0, 10),
                            total_pinjaman: parseInt(member.total_pinjaman || 0, 10),
                            total_bayar: parseInt(member.total_bayar || 0, 10),
                            restricted_products: member.restricted_products || ''
                        };
                        const modal = new bootstrap.Modal(document.getElementById('memberEditModal'));
                        modal.show();
                    };

                    const saveMember = async () => {
                        loading.value.savingMember = true;
                        try {
                            const response = await fetch('admin.php?action=save_member', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify(memberForm.value)
                            });
                            const res = await response.json();
                            if (res.success) {
                                showNotif(res.message, 'success');
                                // Hide modal
                                const modalElement = document.getElementById('memberEditModal');
                                const modal = bootstrap.Modal.getInstance(modalElement);
                                if (modal) modal.hide();
                                
                                await fetchMembers();
                            } else {
                                showNotif(res.message, 'danger');
                            }
                        } catch (error) {
                            showNotif('Gagal menyimpan data member', 'danger');
                        } finally {
                            loading.value.savingMember = false;
                        }
                    };

                    const deleteMember = async (member) => {
                        if (!confirm(`Apakah Anda yakin ingin menghapus member "${member.nama_user}"?`)) {
                            return;
                        }
                        try {
                            const response = await fetch('admin.php?action=delete_member', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ id_user: member.id_user })
                            });
                            const res = await response.json();
                            if (res.success) {
                                showNotif(res.message, 'success');
                                await fetchMembers();
                            } else {
                                showNotif(res.message, 'danger');
                            }
                        } catch (error) {
                            showNotif('Gagal menghapus member', 'danger');
                        }
                    };

                    onMounted(() => {
                        fetchConfig();
                        fetchMemberships();
                        fetchMembers();
                    });

                    const copyToClipboard = (text) => {
                        navigator.clipboard.writeText(text).then(() => {
                            showNotif('Berhasil disalin ke clipboard', 'success');
                        });
                    };

                    const copyTrxSummary = (item) => {
                        const summary = `Transaksi PPOB\nID: #${item.ref_id}\nLayanan: ${item.product_name || item.buyer_sku_code}\nTarget: ${item.customer_no}\nStatus: ${item.status}\nSN: ${item.sn || '-'}\nUpdate: ${new Date(item.updated_at || item.created_at).toLocaleString('id-ID')}`;
                        copyToClipboard(summary);
                    };

                    const getStatusClass = (status) => {
                        const s = String(status || '').toLowerCase();
                        if (s === 'sukses' || s === 'success' || s === 'berhasil') {
                            return 'status-badge status-success';
                        } else if (s === 'pending') {
                            return 'status-badge status-warning';
                        } else {
                            return 'status-badge status-danger';
                        }
                    };

                    // Reports State & Methods
                    const reportSubTab = ref('stats');
                    const reportPreset = ref('this_month');
                    const reportStartDate = ref('');
                    const reportEndDate = ref('');
                    const reportStatusFilter = ref('');
                    const reportLoading = ref(false);
                    const reportData = ref({
                        start_date: '',
                        end_date: '',
                        summary: { total_orders: 0, total_revenue: 0, total_profit: 0, total_completed: 0, total_pending: 0, total_failed: 0 },
                        daily_chart: [],
                        status_chart: { 'Lunas / Selesai': 0, 'Pending': 0, 'Dibatalkan / Gagal': 0 },
                        service_chart: []
                    });

                    let totalTransactionChartInstance = null;
                    let paymentStatusChartInstance = null;
                    let serviceDistChartInstance = null;

                    const formatIndoDate = (dateStr) => {
                        if (!dateStr) return '-';
                        const parts = dateStr.split('-');
                        if (parts.length !== 3) return dateStr;
                        const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                        const mIdx = parseInt(parts[1], 10) - 1;
                        return `${parseInt(parts[2], 10)} ${months[mIdx] || parts[1]} ${parts[0]}`;
                    };

                    const onReportPresetChange = () => {
                        if (reportPreset.value !== 'custom') {
                            fetchReportStats();
                        }
                    };

                    const fetchReportStats = async () => {
                        reportLoading.value = true;
                        try {
                            let url = `admin.php?action=get_report_stats&preset=${reportPreset.value}`;
                            if (reportPreset.value === 'custom') {
                                url += `&start_date=${reportStartDate.value}&end_date=${reportEndDate.value}`;
                            }
                            const response = await fetch(url);
                            const res = await response.json();
                            if (res.success) {
                                reportData.value = res;
                                if (reportPreset.value !== 'custom') {
                                    reportStartDate.value = res.start_date;
                                    reportEndDate.value = res.end_date;
                                }
                                nextTick(() => {
                                    renderReportCharts();
                                });
                            }
                        } catch (e) {
                            console.error('Gagal memuat statistik laporan', e);
                        } finally {
                            reportLoading.value = false;
                        }
                    };

                    const renderReportCharts = () => {
                        if (typeof Chart === 'undefined') return;

                        // 1. Line Chart Total Transaksi
                        const ctx1 = document.getElementById('totalTransactionChart');
                        if (ctx1) {
                            if (totalTransactionChartInstance) totalTransactionChartInstance.destroy();

                            const labels = (reportData.value.daily_chart || []).map(item => item.label);
                            const counts = (reportData.value.daily_chart || []).map(item => item.count);
                            const revenues = (reportData.value.daily_chart || []).map(item => item.revenue);

                            totalTransactionChartInstance = new Chart(ctx1, {
                                type: 'line',
                                data: {
                                    labels: labels,
                                    datasets: [
                                        {
                                            label: 'Jumlah Transaksi',
                                            data: counts,
                                            borderColor: '#16a34a',
                                            backgroundColor: 'rgba(22, 163, 74, 0.1)',
                                            fill: true,
                                            tension: 0.3,
                                            yAxisID: 'y'
                                        },
                                        {
                                            label: 'Omset (Rp)',
                                            data: revenues,
                                            borderColor: '#2563eb',
                                            backgroundColor: 'rgba(37, 99, 235, 0.05)',
                                            fill: false,
                                            tension: 0.3,
                                            yAxisID: 'y1'
                                        }
                                    ]
                                },
                                options: {
                                    responsive: true,
                                    maintainAspectRatio: false,
                                    interaction: { mode: 'index', intersect: false },
                                    scales: {
                                        y: {
                                            type: 'linear',
                                            display: true,
                                            position: 'left',
                                            title: { display: true, text: 'Jumlah' },
                                            beginAtZero: true
                                        },
                                        y1: {
                                            type: 'linear',
                                            display: true,
                                            position: 'right',
                                            title: { display: true, text: 'Omset (Rp)' },
                                            beginAtZero: true,
                                            grid: { drawOnChartArea: false }
                                        }
                                    }
                                }
                            });
                        }

                        // 2. Pie Chart Status Pembayaran
                        const ctx2 = document.getElementById('paymentStatusChart');
                        if (ctx2) {
                            if (paymentStatusChartInstance) paymentStatusChartInstance.destroy();

                            const statusMap = reportData.value.status_chart || {};
                            paymentStatusChartInstance = new Chart(ctx2, {
                                type: 'doughnut',
                                data: {
                                    labels: ['Lunas / Selesai', 'Pending', 'Dibatalkan / Gagal'],
                                    datasets: [{
                                        data: [
                                            statusMap['Lunas / Selesai'] || 0,
                                            statusMap['Pending'] || 0,
                                            statusMap['Dibatalkan / Gagal'] || 0
                                        ],
                                        backgroundColor: ['#659b25', '#eab308', '#dc2626']
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    maintainAspectRatio: false,
                                    plugins: { legend: { position: 'bottom' } }
                                }
                            });
                        }

                        // 3. Pie Chart Top Produk
                        const ctx3 = document.getElementById('serviceDistChart');
                        if (ctx3) {
                            if (serviceDistChartInstance) serviceDistChartInstance.destroy();

                            const services = (reportData.value.service_chart || []).map(item => item.service);
                            const serviceCounts = (reportData.value.service_chart || []).map(item => item.count);

                            serviceDistChartInstance = new Chart(ctx3, {
                                type: 'pie',
                                data: {
                                    labels: services.length > 0 ? services : ['Belum ada data'],
                                    datasets: [{
                                        data: serviceCounts.length > 0 ? serviceCounts : [1],
                                        backgroundColor: ['#a0522d', '#2563eb', '#059669', '#d97706', '#9333ea']
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    maintainAspectRatio: false,
                                    plugins: { legend: { position: 'bottom' } }
                                }
                            });
                        }
                    };

                    const triggerExport = (format) => {
                        let url = `admin.php?action=export_transactions&preset=${reportPreset.value}&format=${format}&status=${reportStatusFilter.value}`;
                        if (reportPreset.value === 'custom') {
                            url += `&start_date=${reportStartDate.value}&end_date=${reportEndDate.value}`;
                        }
                        window.open(url, '_blank');
                    };

                    // =========================================================================
                    // [POSISI_VUE_STATE_METHOD] TAMBAHKAN STATE / REF & METHOD VUE BARU DI SINI
                    // =========================================================================

                    return {
                        activeTab,
                        sidebarOpen,
                        config,
                        priceList,
                        priceType,
                        searchProduct,
                        productStatusFilter,
                        productSortBy,
                        productSortDir,
                        itemsPerPageProducts,
                        sortBy,
                        getSortIcon,
                        transactions,
                        searchTransaction,
                        transactionSortBy,
                        transactionSortDir,
                        itemsPerPageTransactions,
                        sortTrx,
                        getSortIconTrx,
                        trx,
                        trxResult,
                        loading,
                        notification,
                        dbError,
                        stats,
                        filteredProducts,
                        filteredTransactions,
                        paginatedProducts,
                        paginatedTransactions,
                        currentPageProducts,
                        currentPageTransactions,
                        totalPagesProducts,
                        totalPagesTransactions,
                        selectedProducts,
                        marginUpdate,
                        displayUpdate,
                        uniqueCategories,
                        selectAll,
                        selectedItem,
                        balance,
                        balanceError,
                        security,
                        saveConfig,
                        syncProducts,
                        fetchProductsFromDB,
                        fetchTransactions,
                        processTransaction,
                        formatNumber,
                        updateMargin,
                        updateDisplay,
                        toggleSelectAll,
                        showDetails,
                        printReceipt,
                        copyToClipboard,
                        copyTrxSummary,
                        formatDate,
                        hasNextProducts,
                        nextPageProducts,
                        prevPageProducts,
                        hasNextTransactions,
                        nextPageTransactions,
                        prevPageTransactions,
                        updateSecurity,
                        manualStatusToUpdate,
                        submitManualStatus,
                        editingProduct,
                        openEditProduct,
                        submitEditProductName,

                        // Membership exports
                        memberships,
                        newMembershipName,
                        selectedMembershipName,
                        membershipProducts,
                        searchMembershipProduct,
                        currentPageMembershipProducts,
                        hasNextMembershipProducts,
                        totalMembershipProducts,
                        itemsPerPageMembershipProducts,
                        membershipProductType,
                        selectedMembershipProducts,
                        membershipPriceAdjustment,
                        selectAllMembership,
                        createMembership,
                        deleteMembership,
                        fetchMembershipPrices,
                        saveMembershipPrice,
                        toggleSelectAllMembership,

                        // Member exports
                        members,
                        searchMemberQuery,
                        itemsPerPageMembers,
                        currentPageMembers,
                        totalMembers,
                        hasNextMembers,
                        selectedMember,
                        selectedMemberTransactions,
                        isEditMode,
                        memberForm,
                        fetchMembers,
                        viewMemberDetail,
                        openAddMemberModal,
                        openEditMemberModal,
                        saveMember,
                        deleteMember,
                        getStatusClass,

                        // Laporan exports
                        reportSubTab,
                        reportPreset,
                        reportStartDate,
                        reportEndDate,
                        reportStatusFilter,
                        reportLoading,
                        reportData,
                        formatIndoDate,
                        onReportPresetChange,
                        fetchReportStats,
                        renderReportCharts,
                        triggerExport

                        // =========================================================================
                        // [POSISI_VUE_RETURN] TAMBAHKAN VARIABLE / FUNCTION KELUARAN VUE DI SINI
                        // =========================================================================
                    };
                }
            }).mount('#app');
        </script>
    <?php endif; ?>
    <script>
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
                var url = 'https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lat + '&lon=' + lng + '&zoom=18&addressdetails=1';
                fetch(url, {
                    headers: { 'Accept-Language': 'id', 'User-Agent': 'Mozilla/5.0' }
                })
                .then(res => res.json())
                .then(data => {
                    if (data && data.address) {
                        var addr = data.address;
                        var subdistrict = addr.suburb || addr.village || addr.neighbourhood || addr.city_district || addr.municipality || addr.district || '';
                        var city = addr.city || addr.regency || addr.municipality || addr.county || '';
                        var state = addr.state || addr.region || '';
                        var country = addr.country || 'Indonesia';
                        var gps_el = document.getElementById('gps_location');
                        if (gps_el) gps_el.value = lat + ',' + lng + '|' + subdistrict + '|' + city + '|' + state + '|' + country;
                    } else {
                        var gps_el = document.getElementById('gps_location');
                        if (gps_el) gps_el.value = lat + ',' + lng + '||||';
                    }
                })
                .catch(err => {
                    var gps_el = document.getElementById('gps_location');
                    if (gps_el) gps_el.value = lat + ',' + lng + '||||';
                });
            }, function(err) {
                console.error('GPS Error:', err);
            }, {
                enableHighAccuracy: true,
                timeout: 8000,
                maximumAge: 0
            });
        }
    </script>
</body>

</html>