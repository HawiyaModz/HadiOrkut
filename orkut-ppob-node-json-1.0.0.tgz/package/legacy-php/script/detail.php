<?php
require_once __DIR__ . '/../db.php';

$ref_id = $_GET['ref_id'] ?? '';
$data = null;

if (!empty($ref_id)) {
    $stmt = $pdo->prepare("
        SELECT t.*, p.product_name, p.category, p.brand, p.type 
        FROM transactions t 
        LEFT JOIN products p ON t.buyer_sku_code = p.buyer_sku_code 
        WHERE t.ref_id = ?
    ");
    $stmt->execute([$ref_id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (!$data) {
    if (isset($_GET['api']) && $_GET['api'] == 'status') {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Not found']);
        exit;
    }
    die("<div style='padding: 40px; font-family: sans-serif; text-align: center; color: #333;'><h2>Transaksi tidak ditemukan atau ref_id tidak valid.</h2><a href='admin.php' style='text-decoration:none; padding:10px 20px; background:#4f46e5; color:#fff; border-radius:5px;'>Kembali</a></div>");
}

if (isset($_GET['api']) && $_GET['api'] == 'status') {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => $data['status'],
        'sn' => $data['sn'] ?? '',
        'message' => $data['message'] ?? '',
        'updated_at' => $data['updated_at'] ?? $data['created_at']
    ]);
    exit;
}

$url_gambar_barang = 'https://images.bukaolshop.com/hosting/161728/2543dbc67436690722.png'; // Default PPOB Icon
$nomor_pembayaran = $data['ref_id'];
$tanggal_buat = date('d M Y H:i', strtotime($data['created_at']));
$id_user = $data['id_user'] ?? '1';
$url_website_baru = 'admin.php'; // or index.php
$nama_user = $data['nama_user'] ?? $data['customer_no'] ?? 'User';

// Define unified status string for JS logic mapping
$status_bayar_map = [
    'Sukses' => 'lunas',
    'Success' => 'lunas',
    'Pending' => 'pending',
    'Gagal' => 'di batalkan',
    'Failed' => 'di batalkan'
];
$status_bayar = $status_bayar_map[$data['status']] ?? 'pending';

$status_pengiriman_map = [
    'Sukses' => 'selesai',
    'Success' => 'selesai',
    'Pending' => 'diproses',
    'Gagal' => 'di batalkan',
    'Failed' => 'di batalkan'
];
$status_pengiriman = $status_pengiriman_map[$data['status']] ?? 'diproses';

$alasan_batal = in_array($data['status'], ['Gagal', 'Failed']) ? ($data['message'] ?? 'Transaksi Gagal') : '';
$sn = $data['sn'] ?? '';
if ($sn === 'null' || empty($sn)) {
    $sn = '';
}

$harga_final = !is_null($data['price_user']) 
    ? (int)$data['price_user'] 
    : (int)$data['selling_price'];

$json_transaksi = [
    'data_transaksi' => [
        [
            'ekspedisi' => 'PRODUK DIGITAL',
            'ongkos_kirim' => 0,
            'data_produk' => [
                [
                    'nama_barang' => (!empty($data['product_name']) ? $data['product_name'] : $data['buyer_sku_code']),
                    'url_gambar_barang' => $url_gambar_barang,
                    'jumlah_barang' => 1,
                    'total_harga' => $harga_final,
                    'catatan' => $data['customer_no'],
                    'nomor_resi' => $sn,
                    'alasan_batal_ppob' => $alasan_batal,
                    'data_ppob' => [
                        'Layanan' => (!empty($data['product_name']) ? $data['product_name'] : $data['buyer_sku_code']),
                        'No_Tujuan' => $data['customer_no']
                    ]
                ]
            ]
        ]
    ],
    'status_bayar' => $status_bayar,
    'status_pengiriman' => $status_pengiriman,
    'nomor_pembayaran' => $nomor_pembayaran,
    'url_website' => '',
    'url_konfirmasi_terima_barang' => null,
    'is_reseller' => false,
    'total_belanja' => $harga_final,
    'total_ongkir' => 0,
    'total_biaya_admin' => (int)($data['admin_fee'] ?? 0),
    'kode_unik' => 0,
    'total_membership' => 0,
    'total_potongan' => 0,
    'total_transaksi' => $harga_final + (int)($data['admin_fee'] ?? 0),
    'bank_penerima' => 'Saldo Akun',
    'alamat_penerima' => null,
    'alamat_delivery' => null,
    'tanggal_buat' => $data['created_at'],
    'terakhir_update' => (!empty($data['updated_at']) ? $data['updated_at'] : $data['created_at']),
    'auto_batal_dalam_detik' => 0
];

$json_detail_transaksi = json_encode($json_transaksi);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <title>Detail Transaksi - <?php echo htmlspecialchars($nomor_pembayaran); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <style>
@import url('https://fonts.googleapis.com/css2?family=Lexend+Deca:wght@100..900&display=swap');
:root {
  --utama:#527BFF;
}
* {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
}
/* Loader CSS */
#loader-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100vh;
  background-color: aliceblue;
  z-index: 9999;
  display: flex;
  justify-content: center;
  align-items: center;
  transition: opacity 0.5s ease;
}
.spinner {
  width: 50px;
  height: 50px;
  border: 5px solid rgba(82, 123, 255, 0.2);
  border-top-color: var(--utama);
  border-radius: 50%;
  animation: spin 1s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
.fade-out {
  opacity: 0;
  visibility: hidden;
}
::-webkit-scrollbar {
  display: none;
}
html {
    scrollbar-width: none;
}
body{
  font-family: "Lexend Deca", sans-serif;
  background: aliceblue;
}
button,h1,h2,h3,h4,h5,h6,p,input{
            font-family: "Lexend Deca", sans-serif;
        }
.box-nerokode{
  border-radius: 15px;
  background: white;
  position: relative;
  margin-top: 5px;
  overflow: hidden;
  box-shadow: rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.06) 0px 1px 2px 0px;
  padding: 0px;
border: 1px solid #f1f1f1;
}

#status-img{
  width: 17px;
  border-radius: 100px;
  position: relative;
  z-index: 10;
}

.alert-success{
  border: none !important;
  background: aliceblue !important;
  font-size: 13px !important;
  margin-top:10px !important;
}

.alert-success i{
  display: none !important;
}


.data-resi p{
  font-size: 13px;
  font-weight: 500;
  color: gray;
  margin-bottom: 4px !important;
}

.cetak-struk{
  background:var(--utama);
  color:white;
  padding:14px;
  border-radius:10px;
  font-size:14px;
  text-align:center;
  font-weight:bold;
  border:none;
  width:100%;
}

.cetak-struk i {
   margin-right:5px;
}

a{text-decoration:none;}

.edit-struk{
  font-size:22px;
  border-radius:10px;
  padding-left:15px;
  padding-right:15px;
  padding-top:7px;
  padding-bottom:7px;
  color:white;
  background:orangered;
  border:none;
}

.content {
  display: none;
}

.snnya {
  display: flex;
  justify-content: center;
  align-items: center;
  height: auto;
  background-color: #fff;
  border-radius: 10px;
  padding: 14px;
  border: 2px solid #f1f1f1;
  margin-top: 15px;
  margin-bottom: 15px;
}

.sn-resi {
  font-size: 19px;
  font-weight: bold;
  text-align: center;
  word-wrap: break-word;
  white-space: pre-wrap;
  color: var(--utama);
  text-transform: uppercase;
}
.data-ppob{
  margin-bottom: 5px !important;
  display: flex;
  align-items: center;
}
.data-ppob h5{
  font-size: 13px;
  font-weight: bold;
  color: var(--utama);
  margin: 0;
  text-transform: uppercase;
}
h5{
  font-size: 13px;
  font-weight: 600;
  width: 100%;
  margin-top: 5px !important;
}
.nero-status-bg{
  padding: 14px;
  padding-top: 18px;
  padding-bottom: 18px;
  display: flex;
  align-items: center;
  gap: 15px;
  position: relative;
}
.stat{
  display: flex;
  align-items: center;
  gap: 5px;
   background: white;
   padding: 3px 5px;
   border-radius: 100px;
   border: none;
   width: auto;
}
.stat span{
  font-size: 11px;
  text-transform: uppercase;
}

.nero-status-bg h4{
  font-size: 15px;
  font-weight: bold;
  margin: 0;
}
.nero-status-bg span{
  font-size: 10px;
  font-weight: bold;
  text-transform: uppercase;
 
}
.nero-status-bg h6{
  font-size: 12px;
  margin-top: 3px;
  margin-bottom: 5px;
  opacity: .7;
}
.bg-red {
    background-color: #ff000093;
}
.bg-green {
    background-color: #ddffdd;
}
.bg-gray {
    background-color: #f1f1f1;
}
.bgs-red {
    background-color: #ff000093;
}
.bgs-green {
    background-color: #ddffdd;
}
.bgs-gray {
    background-color: #f1f1f1;
}
.icon-produk{
  width: 35px;
  height: 35px;
  border-radius: 100px;
}
.total-pembayaran{
  border-top: 3px dotted #f1f1f1;
  padding-top: 10px;
  margin-top: 10px;
  margin-bottom:0px !important;
  color: var(--utama);
}
.tag-name{
  font-size: 15px;
  font-weight: 600;
  margin-top: 15px;
  margin-bottom: 0px;
}
.copy-btn{
  color: black;
  margin-left: 10px;
  background: transparent;
  border: none;
  padding: 0px;
}
.alasan-gagal{
  background: var(--utama);
  color: white;
  border-radius: 10px;
  padding: 10px;
  font-size: 13px;
}
header{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100px;
  background: var(--utama);
  z-index: -1;
}
  </style>
</head>

<body>
<div id="loader-overlay">
  <div class="spinner"></div>
</div>
<header></header>
<div class="stat d-none">
  <div id="pending_bg">
      <i class="bi bi-clock-history text-white" style="font-size:18pt" id="pending"></i>
  </div>
  <div id="proses_bg">
      <i class="bi bi-arrow-repeat text-white" style="font-size:18pt" id="proses"></i>
  </div>
  <div id="selesai_bg">
      <i class="bi bi-check2-circle text-white" style="font-size:18pt" id="selesai"></i>
  </div>
</div>


<div class="mt-2 mb-4 d-none" id="auto_batal"></div>


<span class="d-none" id="status_bayar" style="font-size:13pt">Lunas</span>


<div class="container mt-4 pt-3">
<div class="box-nerokode">

<div class="nero-status-bg">
    <img src="<?php echo htmlspecialchars($url_gambar_barang); ?>" alt="" class="icon-produk">
    <div>
      <h4 class="produk-nama"></h4>
      <div class="d-flex align-items-center">
        <h6 id="nomor">#<?php echo htmlspecialchars($nomor_pembayaran); ?></h6>
        <button onclick="copyNomor()" class="copy-btn"><i class="fa-solid fa-clone"></i></button>
      </div>
    </div>
</div>


<div class="p-3" style="padding-top: 0px !important;">
  <div class="d-flex align-items-center"  style="border-bottom: 4px dotted #f1f1f1;padding-bottom: 10px;margin-top: 15px;">
    <p class="tag-name" style="width: 100%;margin: 0;">Transaksi</p>
    <div style="width: 100%;"></div>
  <button class="stat nero-status-bgs" style="width: 100%;text-align: center;justify-content: center;">
    <span id="status_kirim">Proses</span>
    <img id="status-img" />
  </button>
</div>

<div class="alasan-trx" style="color: red;font-size: 13px;margin-top: 5px;margin-bottom: 5px;"></div>

<div class="d-flex align-items-center" style="margin-top: 10px;margin-bottom: 0px;">
    <h5>Waktu</h5>
    <h5 class="text-end"><?php echo htmlspecialchars($tanggal_buat); ?></h5>
</div>
<div id="keranjang_transaksi" style="margin-top: -20px;"></div>

<p class="tag-name" style="margin-bottom: 10px;border-bottom: 4px dotted #f1f1f1;padding-bottom: 10px;">Detail Pembayaran</p>
<div id="metode_bayar"></div>
<div id="detail_transaksi" style="position: relative;overflow: hidden;"></div>

<div class="d-none">
<div id="pengiriman"></div>
<div id="update_status"></div>
</div></div>

</div></div>
<br>
<div class="container">
  <div id="cetak-struk"></div>
</div>
<br>

<div class="bh">
  <a href="<?php echo htmlspecialchars($url_website_baru); ?>"></a>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
<script type="text/javascript">
  const myID = "<?php echo htmlspecialchars($id_user); ?>";
  var json_transaksi= <?php echo $json_detail_transaksi; ?>;

  $(document).ready(function(){
    if(json_transaksi && json_transaksi.hasOwnProperty('data_transaksi') && json_transaksi.data_transaksi.length>0){
      json_transaksi.data_transaksi.forEach((data_keranjang) => {
        setKeranjang(data_keranjang);
      });
      setStatusTransaksi();
      $('#status_bayar').text(json_transaksi.status_bayar);
      $('#status_kirim').text(json_transaksi.status_pengiriman);
      setCetakStruk();
      setDetailTransaksi();
      setMetodePembayaran();
      setAlamatPengiriman();
      setStatusUpdate();
      setAutoBatalTeks();
    }
    
    startPolling();

    // Sembunyikan loader dengan animasi fade
    setTimeout(() => {
        let loader = document.getElementById('loader-overlay');
        if (loader) {
            loader.classList.add('fade-out');
            setTimeout(() => {
                loader.style.display = 'none';
            }, 500); // Sesuaikan dengan transisi di CSS (0.5s)
        }
    }, 300); // Penundaan tambahan biarkan konten me-render sedikit (opsional)
  });

function setKeranjang(data_keranjang) {
    let ongkos_kirim = data_keranjang.ongkos_kirim == 0 ? "" : formatRupiah(data_keranjang.ongkos_kirim);
    let url_copy_resi = json_transaksi.url_website + 'copy?teks=' + data_keranjang.data_produk[0].nomor_resi;
    let resiDiTiapDetailProduk = true
    if ((data_keranjang.data_produk.length == 1 && data_keranjang.ekspedisi == "PRODUK DIGITAL") || data_keranjang.ekspedisi != "PRODUK DIGITAL") {
        resiDiTiapDetailProduk = false;
    }
    let html_keranjang = `
    <div class="" style="margin-top:20px">
      <div class="produkd">
        <div class="card-header d-none">
          <span><i class="bi bi-truck mr-2"></i>` + data_keranjang.ekspedisi + `</span>
          <span class="ml-auto">` + ongkos_kirim + `</span>
        </div>`;
    html_keranjang += `<div>`;
    html_keranjang += `<div class="">`;
    data_keranjang.data_produk.forEach((data_produk, index) => {
        let apakahTerakhir = index != data_keranjang.data_produk.length - 1;
        html_keranjang += setDataProduk(data_produk, apakahTerakhir, resiDiTiapDetailProduk);
    });
    html_keranjang += `</div></div>`;
    if (json_transaksi.status_pengiriman == "selesai" || json_transaksi.status_pengiriman == "diterima") {
        if (!resiDiTiapDetailProduk || data_keranjang.ekspedisi != "PRODUK DIGITAL") {
            if (data_keranjang.data_produk[0].nomor_resi) {
                html_keranjang += `
<div class="data-resi">
    <p class="mb-0">SN (Serial Number)</p>
     <div class="snnya">
      <a href="javascript:void(0);" onclick="navigator.clipboard.writeText('`+data_keranjang.data_produk[0].nomor_resi+`');Swal.fire('Disalin!', 'SN berhasil disalin', 'success');" style="width:100%; text-decoration:none;">
      <div class="w-100 sn-resi" style="font-size:18px;font-weight:bold;text-align:center;">` + data_keranjang.data_produk[0].nomor_resi + `</div>
      </a>
       <div>
     </div>
   </div>
   </div>`;
            }
        }
    }
html_keranjang += `</div></div>`;
$('#keranjang_transaksi').append(html_keranjang);
}

function setDataProduk(data_produk, apakahTerakhir, resiDiTiapDetailProduk) {
let html_produk = `<div class="produk-detail">`;
html_produk += `
    <div class="">
        <div class="d-none">
            <img src="` + data_produk.url_gambar_barang + `" class="rounded-circle" style="width:100%">
        </div>
        <div class="d-none">
            <p>Produk</p>
            <p>` + data_produk.nama_barang + `</p>
        </div>
        `+setDetailPembelianProduk(data_produk,resiDiTiapDetailProduk)+`
    </div>
`;
// Menampilkan alasan pembatalan jika ada
if (data_produk.alasan_batal_ppob) {
    html_produk += `
        <div class="alasan-gagal mt-4" role="alert">
          <p style="font-size:12px;color:white;margin-bottom:5px;margin-top:0px;">Gagal Karena : </p>
            <span class="ukuran_teks_detail">
                <i class="fa-solid fa-circle-info" style="color:white;"></i> 
                ${data_produk.nomor_resi}
            </span>
        </div>
    `;

    // === TAMPILKAN KE DIV .alasan-trx ===
    const alasanDiv = document.querySelector(".alasan-trx");
    if (alasanDiv) {
        alasanDiv.innerHTML = `
            <div class="alert alert-danger" style="font-size:13px;">
                <b>Gagal Karena:</b> ${data_produk.alasan_batal_ppob}
            </div>
        `;
    }
}

// Menampilkan informasi cashback jika ada
if (data_produk.jumlah_cashback && data_produk.status_cashback) {
    let teks_cashback = `Selamat Cashback senilai ` + formatRupiah(data_produk.jumlah_cashback) + ` telah ditambahkan ke saldo mu kk,<?php echo htmlspecialchars($nama_user); ?>.`;
    let warna_alert = "alert-success";

    // Cek status cashback apakah sudah diterima atau belum
    if (data_produk.status_cashback == "belum_terima") {
        teks_cashback = `Selamat Kamu mendapatkan cashback senilai ` + formatRupiah(data_produk.jumlah_cashback);
        warna_alert = "alert-info";
    }
    html_produk += `
        <div class="alert ` + warna_alert + ` mt-4" role="alert">
            <div class="d-flex">
                <span class="ukuran_teks_detail">` + teks_cashback + `</span>
            </div>
        </div>
    `;
}
html_produk += `</div>`;
if (apakahTerakhir) {
    html_produk += `<hr>`;
}
html_produk += `</div>`; 
document.querySelector('.produk-nama').textContent = data_produk.nama_barang;
return html_produk;
}


function setDetailPembelianProduk(data_produk,resiDiTiapDetailProduk) {
        let teks_detail="";

//Jumlah produk yang dibeli
teks_detail+=`<div class="d-none">
              <span class="ukuran_teks_detail font-weight-light">Jumlah</span>
              <span class="ukuran_teks_detail font-weight-bold ml-auto">`+data_produk.jumlah_barang+`</span>
              </div>`;

//Total harga produk
teks_detail+=`<div class="d-none">
              <span class="ukuran_teks_detail font-weight-light">Harga</span>
              <span class="ukuran_teks_detail font-weight-bold ml-auto">`+formatRupiah(data_produk.total_harga)+`</span>
              </div>`;

//Warna,Ukuran, dan Varian Produk
// cek apakah nama_varian terdapat data, jika ada, maka produk dibeli dengan varian
if(data_produk.nama_varian){
teks_detail+=`<div class="d-flex">
              <span class="ukuran_teks_detail font-weight-light">Varian</span>
              <span class="ukuran_teks_detail font-weight-bold ml-auto">`+data_produk.nama_varian+`</span>
              </div>`;
if(data_produk.opsi_varian){
let opsi_varian = data_produk.opsi_varian.join();
teks_detail+=`<div class="d-flex">
              <span class="ukuran_teks_detail font-weight-light">Opsi Varian</span>
              <span class="ukuran_teks_detail font-weight-bold ml-auto">`+opsi_varian+`</span>
              </div>`;
}
}else {
if(data_produk.warna){
teks_detail+=`<div class="d-flex">
              <span class="ukuran_teks_detail font-weight-light">Warna</span>
              <span class="ukuran_teks_detail font-weight-bold ml-auto">`+data_produk.warna+`</span>
              </div>`;
}
if(data_produk.ukuran){
teks_detail+=`<div class="d-flex">
              <span class="ukuran_teks_detail font-weight-light">Ukuran</span>
              <span class="ukuran_teks_detail font-weight-bold ml-auto">`+data_produk.ukuran+`</span>
              </div>`;
}
}
if(data_produk.data_ppob){
$.each(data_produk.data_ppob, function(key, value) {
let key_replace=key.replace(/_/g, ' ');
teks_detail+=`<div class="data-ppob">
              <h5>`+key_replace+`</h5>
              <h5 class="text-end">`+value+`</h5>
              </div>`;
});
}

//Catatan pemesanan
if(data_produk.catatan && data_produk.catatan!=""){
teks_detail+=`<div class="d-flex align-items-center">
              <h5>Tujuan</h5>
              <h5 class="text-end">`+data_produk.catatan+`</h5>
              </div>`;
}
              if(resiDiTiapDetailProduk && data_produk.nomor_resi && data_produk.nomor_resi!=""){
                teks_detail+=`
                <div class="kode-sn">
                  <span class="">SN/Resi</span>
                  <div class="d-flex align-items-center" style:"width:100%">
                  <h5 class="w-100" style:"word-break: break-all" style="width:85%">`+data_produk.nomor_resi+`</h5>
                  <a href="javascript:void(0);" onclick="navigator.clipboard.writeText('`+data_produk.nomor_resi+`');Swal.fire('Disalin!', 'SN berhasil disalin', 'success');" class="text-right" style="width:15%">
                    <i class="bi bi-copy text-primary"></i>
                  </div>
                   </div>
                `;
                teks_detail+=`<div class="d-flex">
                  </a></div>`;
              }
              return teks_detail;
            }

            function setStatusTransaksi() {
              if(json_transaksi.status_bayar=="lunas"){
                if(json_transaksi.status_pengiriman=="selesai" || json_transaksi.status_pengiriman=="di batalkan" | json_transaksi.status_pengiriman=="diterima"){
                  $("#selesai").css("font-size", "22pt");
                  $("#selesai_bg").css("width","60px");
                  $("#selesai_bg").css("height","60px");
                  $("#selesai_bg").css("background","#72ac61")
                }else{
                  $("#proses").css("font-size", "22pt");
                  $("#proses_bg").css("width","60px");
                  $("#proses_bg").css("height","60px");
                }
              }else if (json_transaksi.status_bayar=="di konfirmasi" &&
                (json_transaksi.status_pengiriman=="diproses" || json_transaksi.status_pengiriman=="dikirim")
              ) {
                    // kemungkinan transaksi COD Delivery, transaksi menjadi di proses
                    $("#proses").css("font-size", "22pt");
                    $("#proses_bg").css("width","60px");
                    $("#proses_bg").css("height","60px");
              }else if (json_transaksi.status_bayar!="di batalkan") {
                $("#pending").css("font-size", "22pt");
                $("#pending_bg").css("width","60px");
                $("#pending_bg").css("height","60px");
                //$("#pending_bg").css("background","rgb(172 111 97 / 73%)");
              }

              //jika "url_konfirmasi_terima_barang" tidak null, munculkan tombol konfirmasi terima barang
              if (json_transaksi.url_konfirmasi_terima_barang){
                $('#cetak-struk').html(`<div class="card mt-3">
                  <div class="card-body"><a href="`+json_transaksi.url_konfirmasi_terima_barang+`" class="btn btn-primary btn-block">Konfirmasi Terima Barang</a></div></div>`);
              }

            }

            function setCetakStruk() {
              if(json_transaksi.status_bayar=="lunas" && json_transaksi.status_pengiriman=="selesai"){
                //url cetak struk yaitu url_website/akun?page=cetak_struk&nomor_pembayaran=xxxxxxx
                let url_cetak_struk=json_transaksi.url_website+'akun?page=cetak_struk&nomor_pembayaran='+json_transaksi.nomor_pembayaran;

                //edit cetak struk hanya bisa digunakan didalam halaman kostum detail transaksi.
                let url_cetak_struk_membership=json_transaksi.url_website+'akun?page=cetak_struk_membership&nomor_pembayaran='+json_transaksi.nomor_pembayaran;

                //cek apakah is_reseller bernilai true, jika true maka munculkan tombol edit struk.
                let html_cetak_struk_membership=json_transaksi.is_reseller?`<a href="`+url_cetak_struk_membership+`" class="edit-struk" style="border-left-width:0px"><i class="bi bi-pencil"></i></a>`:"";
                let cetak_struk="";
                cetak_struk+=`
                      <div class="d-flex align-items-center gap-1">
                        <button onclick="redirectToCetakStruk()" class="w-100 cetak-struk"><i class="fa-solid fa-print"></i>Cetak Struk</button>
                        `+html_cetak_struk_membership+`
                      </div>`;
                $('#cetak-struk').html(cetak_struk);
              }
            }

            function redirectToCetakStruk() {
              let url_cetak_struk= 'https://domainmu.com/orkut/script/struk.php?ref_id=' +json_transaksi.nomor_pembayaran;
              window.open(url_cetak_struk, '_blank');
            }

            function setDetailTransaksi() {
              let detail_transaksi="";
              //total belanja (total dari harga produk)
              detail_transaksi+=`<div class="d-flex align-items-center"><h5>Harga</h5>
              <h5 class="text-end">`+formatRupiah(json_transaksi.total_belanja)+`</h5></div>`;

              //total ongkir, jika ongkir lebih dari Rp0 baru di munculkan
              if(json_transaksi.total_ongkir>0){
                detail_transaksi+=`<div class="d-flex mt-2"><span class="font-weight-light">Total Ongkir</span>
                <span class="font-weight-bold ml-auto">`+formatRupiah(json_transaksi.total_ongkir)+`</span></div>`;
              }

              //biaya admin, jika biaya admin lebih dari Rp0 baru di munculkan
              if(json_transaksi.total_biaya_admin>0){
                detail_transaksi+=`<div class="d-flex align-items-center"><h5>Biaya Admin</h5>
                <h5 class="text-end">`+formatRupiah(json_transaksi.total_biaya_admin)+`</h5></div>`;
              }
              if(json_transaksi.kode_unik>0){
                detail_transaksi+=`<div class="d-flex align-items-center"><span class="font-weight-light">Kode Unik</span>
                <span class="font-weight-bold ml-auto">`+formatRupiah(json_transaksi.kode_unik)+`</span></div>`;
              }
              if (json_transaksi.total_membership != 0) {
    let text_color = json_transaksi.total_membership < 0 ? "text-danger" : (json_transaksi.total_membership > 0 ? "text-success" : "");
    detail_transaksi += `
        <div class="d-flex align-items-center">
          <div>
            <h5>Harga Membership</h5>
          </div>
          <div class="w-100 text-end">
            <h5 class="${text_color}">
                ${formatRupiah(json_transaksi.total_membership)}
            </h5>
          </div>
        </div>
    `;
}
              if(json_transaksi.total_potongan!=0){
                detail_transaksi+=`<div class="d-flex mt-2"><span class="font-weight-light">Diskon</span>
                <span class="font-weight-bold">`+formatRupiah(json_transaksi.total_potongan)+`</span></div>`;
              }


              detail_transaksi+=`<div class="d-flex total-pembayaran"><h5 class="font-weight-light">Total Pembayaran</h5>
              <h5 class="text-end">`+formatRupiah(json_transaksi.total_transaksi)+`</h5></div>`;

              $('#detail_transaksi').html(detail_transaksi)
            }


            function setMetodePembayaran() {
              let metode_bayar="";
              metode_bayar+=`<div class="d-flex metode-bayar"><h5>Metode Bayar</h5>
              <h5 class="text-end text-uppercase">`+json_transaksi.bank_penerima+`</h5></div>`;
              metode_bayar+=`<div class="d-flex status-bayar"><h5>Status Trx</h5>
              <h5 class="text-end text-uppercase">`+json_transaksi.status_bayar+`</h5></div>`;

            //   if(json_transaksi.status_bayar=="pending"){
            //     if(json_transaksi.override_payment_transaksi){
            //       metode_bayar+=`
            //       <div class="mt-4">
            //       <a href="`+json_transaksi.url_payment+`" class="btn btn-primary mr-2 btn-block">Bayar</a>

            //       </div>`;
            //     }else{
            //       metode_bayar+=`
            //       <div class="d-flex mt-4 gap-1">
            //       <a href="javascript:void(0)" class="btn btn-primary mr-2" style="width:30%">Bayar</a>
            //       <a href="javascript:void(0)" class="btn btn-primary" style="width:70%">Konfirmasi Pembayaran</a>
            //       </div>`;
            //     }
            //   }
              $('#metode_bayar').html(metode_bayar);
            }

            function setAlamatPengiriman() {
              if(json_transaksi.alamat_penerima && json_transaksi.alamat_penerima!=null && typeof json_transaksi.alamat_penerima === 'object'){
                let data_alamat=json_transaksi.alamat_penerima;
                let alamat_penerima="";

                alamat_penerima+=`<div class="d-flex   mt-2 text-right"><span class="font-weight-light">Alamat Lengkap</span>
                <span class="font-weight-bold ml-auto" style="width:40%">`+data_alamat.alamat_lengkap+`</span></div>`;

                alamat_penerima+=`<div class="d-flex mt-2 text-right"><span class="font-weight-light">Kecamatan</span>
                <span class="font-weight-bold ml-auto">`+data_alamat.kecamatan+`</span></div>`;

                alamat_penerima+=`<div class="d-flex   mt-2 text-right"><span class="font-weight-light">Kota</span>
                <span class="font-weight-bold ml-auto">`+data_alamat.kota+", "+data_alamat.provinsi+" (POS "+data_alamat.kode_pos+`)</span></div>`;

                alamat_penerima+=`<div class="d-flex   mt-2 text-right"><span class="font-weight-light">Nomor Telpon</span>
                <span class="font-weight-bold ml-auto">`+data_alamat.nomor_telepon+`</span></div>`;

                alamat_penerima+=`<div class="d-flex   mt-2 text-right"><span class="font-weight-light">Status Pengiriman</span>
                <span class="font-weight-bold ml-auto text-capitalize">`+json_transaksi.status_pengiriman+`</span></div>`;
                $('#pengiriman').html(alamat_penerima);
              }else if(json_transaksi.alamat_delivery && json_transaksi.alamat_delivery!=null && typeof json_transaksi.alamat_delivery === 'object'){
                  let data_alamat=json_transaksi.alamat_delivery;
                  let alamat_delivery="";
                  alamat_delivery+=`<div class="d-flex   mt-2 text-right"><span class="font-weight-light">Alamat Lengkap</span>
                  <span class="font-weight-bold ml-auto ukuran_teks_detail text-success" style="width:60%">`+data_alamat.nama_jalan+`</span></div>`;
                  alamat_delivery+=`<div class="d-flex   mt-2 text-right"><span class="font-weight-light">Nama Penerima</span>
                  <span class="font-weight-bold ml-auto" style="width:60%">`+data_alamat.nama_penerima+`</span></div>`;
                  alamat_delivery+=`<div class="d-flex   mt-2 text-right"><span class="font-weight-light">Nomor Hp</span>
                  <span class="font-weight-bold ml-auto" style="width:40%">`+data_alamat.nomor_hp+`</span></div>`;

                  alamat_delivery+=`<a href="`+data_alamat.url_lokasi_delivery+`" class="btn btn-primary mt-4 mb-2">Lihat Lokasi Delivery</a>`;

                  $('#pengiriman').html(alamat_delivery);
              }else if(json_transaksi.data_transaksi.length==1 && json_transaksi.data_transaksi[0].data_produk[0].catatan){
                $('#pengiriman').html(`<div class="mt-2 text-center h4 text-primary">`+json_transaksi.data_transaksi[0].data_produk[0].catatan+`</div>`);
              }else{
                $('#pengiriman').html(`<div class="mt-2 d-none">Belum ada lokasi pengiriman</div>`);
              }


            }

function setStatusUpdate() {
    let status_update="";
    let tanggal_buat= new Date(json_transaksi.tanggal_buat).toLocaleString('id-ID',{ dateStyle: 'full', timeStyle: 'short'});
    let tanggal_update= new Date(json_transaksi.terakhir_update).toLocaleString('id-ID',{ dateStyle: 'full', timeStyle: 'short'});
    status_update+=`<div class="d-flex   mt-2 text-right ukuran_teks_detail">
    <span >Dibuat pada</span>
    <span class=" ml-auto" style="width:40%">`+tanggal_buat+`</span></div>`;
              status_update+=`<div class="d-flex   mt-2 text-right ukuran_teks_detail">
    <span>Terakhir diupdate pada</span>
    <span class="ml-auto" style="width:40%">`+tanggal_update+`</span></div>`;
    $('#update_status').html(status_update);
}

function setAutoBatalTeks(){
        let totalSeconds=json_transaksi.auto_batal_dalam_detik;
        let timer = setInterval(() => {
                if (totalSeconds > 0) {
                  totalSeconds--;
        let auto_batal_teks=`
                  <div class="alert alert-warning" role="alert">
                  Pembayaran harus dilakukan dalam<br>
                  <b>`+formatTime(totalSeconds)+`</b></div>`;
                  $('#auto_batal').html(auto_batal_teks);
                } else {
                  clearInterval(timer); 
                }
              }, 1000);
            }

function formatRupiah(angka){
        if (angka === undefined) {
        return "Gagal muat";
}
    angka=angka.toString();
    let is_minus=angka.charAt(0)=='-'?true:false;
    if(is_minus){
    angka=angka.substring(1);
}
var number_string = angka.toString().replace(/[^,\d]/g, '').toString(),
    split   		= number_string.split(','),
    sisa     		= split[0].length % 3,
    rupiah     		= split[0].substr(0, sisa),
    ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);
    if(ribuan){
    separator = sisa ? '.' : '';
    rupiah += separator + ribuan.join('.');
}
    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
let minus_sign=is_minus?"-":"";
        return minus_sign+'Rp' + rupiah;
}

function formatTime(totalSeconds) {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
          return `${pad(hours)} jam, ${pad(minutes)} menit, ${pad(seconds)} detik`;
}

function pad(num) {
        return num.toString().padStart(2, '0');
}

function startPolling() {
    let currentRawStatus = "<?php echo $data['status'] ?? 'Pending'; ?>";
    let refId = "<?php echo $nomor_pembayaran; ?>";
    
    let status_bayar_map = {
        'Sukses': 'lunas',
        'Success': 'lunas',
        'Pending': 'pending',
        'Gagal': 'di batalkan',
        'Failed': 'di batalkan'
    };
    
    let status_kirim_map = {
        'Sukses': 'selesai',
        'Success': 'selesai',
        'Pending': 'diproses',
        'Gagal': 'di batalkan',
        'Failed': 'di batalkan'
    };

    setInterval(() => {
        // Fetch ke file yang sama dengan parameter query string
        fetch('?api=status&ref_id=' + encodeURIComponent(refId))
            .then(async res => {
                const text = await res.text();
                try {
                    return JSON.parse(text);
                } catch (e) {
                    throw new Error("Format respons tidak valid (bukan JSON): " + text.substring(0, 50));
                }
            })
            .then(data => {
                if (data && data.status && data.status !== currentRawStatus) {
                    currentRawStatus = data.status;
                    
                    let new_bayar = status_bayar_map[data.status] || 'pending';
                    let new_kirim = status_kirim_map[data.status] || 'diproses';
                    
                    json_transaksi.status_bayar = new_bayar;
                    json_transaksi.status_pengiriman = new_kirim;
                    
                    // Update Text
                    $('#status_bayar').text(new_bayar);
                    $('#status_kirim').text(new_kirim);
                    
                    // Update layout components
                    setStatusTransaksi();
                    setCetakStruk();
                    setMetodePembayaran();
                    
                    // Update SN if available
                    if (data.sn && data.sn !== 'null' && data.sn !== '') {
                        if (json_transaksi.data_transaksi[0].data_produk[0]) {
                            json_transaksi.data_transaksi[0].data_produk[0].nomor_resi = data.sn;
                        }
                    }
                    
                    // Update message if Failed
                    if ((data.status === 'Gagal' || data.status === 'Failed') && data.message) {
                        const alasanDiv = document.querySelector(".alasan-trx");
                        if (alasanDiv) {
                            alasanDiv.innerHTML = `
                                <div class="alert alert-danger" style="font-size:13px;">
                                    <b>Gagal Karena:</b> ${data.message}
                                </div>
                            `;
                        }
                    }
                    
                    // Smooth reload if we can't update SN gracefully, but for now DOM update is enough.
                    if (data.status === 'Sukses' || data.status === 'Success') {
                        $('#keranjang_transaksi').empty();
                        if (json_transaksi.data_transaksi && json_transaksi.data_transaksi.length > 0) {
                            json_transaksi.data_transaksi.forEach((data_keranjang) => {
                                setKeranjang(data_keranjang);
                            });
                        }
                    }
                }
            })
            .catch(err => console.error("Polling error:", err));
    }, 1000);
}

</script>
<script>
function updateStatusImage() {
    const status = document.getElementById('status_kirim').textContent.trim().toLowerCase();
    const statusImg = document.getElementById('status-img');
    const statusText = document.getElementById('status_kirim');
    const statusBg = document.querySelector('.nero-status-bg');
    const statusBgs = document.querySelector('.nero-status-bgs');
    // Reset background color class
    statusBg.classList.remove('bg-red', 'bg-green', 'bg-gray');
    statusBgs.classList.remove('bgs-red', 'bgs-green', 'bgs-gray');

    if (status === 'di batalkan') {
        statusImg.src = 'https://cdn-icons-png.flaticon.com/128/399/399274.png';
        statusText.style.color = 'red';
        statusBg.classList.add('bg-red');
        statusBgs.classList.add('bgs-red');
    } else if (status === 'selesai') {
        statusImg.src = 'https://media.tenor.com/Hw7f-4l0zgEAAAAM/check-green.gif';
        statusText.style.color = 'green';
        statusBg.classList.add('bg-green');
        statusBgs.classList.add('bgs-green');
    } else {
        statusImg.src = 'https://cdn-icons-gif.flaticon.com/6454/6454209.gif';
        statusText.style.color = 'gray';
        statusBg.classList.add('bg-gray');
        statusBgs.classList.add('bgs-gray');
    }
}
function copyNomor() {
  const text = document.getElementById('nomor').innerText;
  const cleanText = text.replace(/^#/, '');
  navigator.clipboard.writeText(cleanText)
    .then(() => {
      Swal.fire({
        icon: 'success',
        title: 'Disalin!',
        text: 'ID Transaksi : ' + cleanText,
        timer: 2000,
        showConfirmButton: false
      });
    })
    .catch(() => {
      Swal.fire({
        icon: 'error',
        title: 'Oops!',
        text: 'Gagal menyalin nomor.',
      });
    });
}

const statusElement = document.getElementById('status_kirim');
const observer = new MutationObserver(updateStatusImage);
observer.observe(statusElement, { childList: true, subtree: true });
updateStatusImage();

</script>
</body>
</html>
