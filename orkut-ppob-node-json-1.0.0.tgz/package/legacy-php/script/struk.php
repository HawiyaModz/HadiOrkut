<?php
require_once __DIR__ . '/../db.php';

$ref_id = $_GET['ref_id'] ?? '';
$nama_user = $_GET['nama_user'] ?? 'Toko Saya';
$foto_profil = $_GET['foto_profil'] ?? 'https://images.bukaolshop.com/hosting/161728/2543dbc67436690722.png';

$trx_json = "null";

if (!empty($ref_id)) {
    $stmt = $pdo->prepare("
        SELECT t.*, p.product_name, p.category, p.brand, p.type 
        FROM transactions t 
        LEFT JOIN products p ON t.buyer_sku_code = p.buyer_sku_code 
        WHERE t.ref_id = ?
    ");
    $stmt->execute([$ref_id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($data) {
        $trx_json = json_encode($data);
    }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <title>Cetak Struk</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <style media="screen">
    html,
    body {
      -webkit-text-size-adjust: none !important;
      text-size-adjust: none !important;
    }

    @font-face {
      font-family: MyFont;
      src: url("https://db.onlinewebfonts.com/t/7ca25c954994f8f701af4cfacdbbeec3.ttf")format("truetype")
    }

    * {
      -webkit-font-smoothing: antialiased;
      -webkit-text-size-adjust: none;
      line-height: 1.3;
      font-family: MyFont, monospace;
      font-size: 13pt;

    }

    .text-space {
      letter-spacing: 1.5px;
    }

    .text_harga_total {
      width: 40%;
      text-align: right;
      word-wrap: break-word;
      word-break: break-word;
    }

    .catatan_class {
      border: 2px dashed #000;
      border-radius: 5px;
      padding: 10px;
      margin-top: 2px;
    }

    .token_pln {
      font-size: 35px !important;
    }

    .row_total,
    .row_total * {
      font-size: 25px !important;
      font-weight: bold;
    }

    .break-word {
      word-wrap: break-word;
      /* untuk browser lama */
      overflow-wrap: break-word;
      /* standar modern */
      word-break: break-all;
      /* jika sangat panjang tanpa spasi */
    }

     /* Loading */
    .loading-overlay {
      position: fixed;
      inset: 0;
      background: rgba(255,255,255,0.8);
      backdrop-filter: blur(5px);
      z-index: 9999;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  </style>
</head>

<body>
  <!-- Loading Overlay -->
  <div id="load" class="loading-overlay" style="display:none;">
     <div class="spinner-border text-primary" role="status"></div>
  </div>

  <div class="container mt-2 p-4">
    <!-- header struk -->
    <div class="row">
      <!-- icon aplikasi -->
      <div class="col-12">
        <div class="d-flex justify-content-center">
          <img class="img-fluid" style="height:70px" id="icon_aplikasi" src="<?= htmlspecialchars($foto_profil) ?>">
        </div>
      </div>
      <!-- nama aplikasi -->
      <div class="col-12">
        <div class="text-center text-space fs-4 m-3" id="nama_toko"><?= htmlspecialchars($nama_user) ?></div>
      </div>
    </div>
    <!-- garis putus-putus -->
    <div style="border-top:2px dashed black"></div>

    <!-- data transaksi -->
    <div class="row">
      <div class="col-12">
        <div class="d-flex mt-2">
          <div class="flex-fill pe-2">Order ID</div>
          <div class="text-end" id="nomor_pembayaran"></div>
        </div>
        <div class="d-flex">
          <div class="flex-fill pe-2">Date/Time</div>
          <div class="text-end" id="terakhir_update"></div>
        </div>
        <div class="d-flex">
          <div class="flex-fill pe-2">Status</div>
          <div class="text-end" id="status_transaksi"></div>
        </div>
      </div>
    </div>

    <!-- garis putus-putus -->
    <div style="border-top:2px dashed black" class="mt-2"></div>

    <!-- daftar produk -->
    <div class="row mt-2 mb-2">
      <div class="col-12" id="list_produk">
      </div>
    </div>

    <!-- garis putus-putus -->
    <div style="border-top:2px dashed black"></div>

    <!-- total perhitungan transaksi -->
    <div class="row mt-2 mb-2">
      <div class="col-12">

        <div id="total_footer">

        </div>

        <!-- garis putus-putus -->
        <div class="d-flex justify-content-end mb-2">
          <div style="border-top:2px dashed black;width:75%;"></div>
        </div>


        <div class="d-flex justify-content-end row_total">
          <div class="pb-2">Total</div>
          <div class="pb-2 ps-2">:</div>
          <div class="pb-2 text_harga_total" id="total_transaksi"></div>
        </div>
      </div>
    </div>

    <!-- qr code invoice -->
    <div class="row">
      <div class="col-12 text-center" id="qr_invoice">
      </div>
    </div>

    <!-- ucapan terimakasih -->
    <div class="row m-3">
      <div class="col-12 text-center">
        Terimakasih telah berbelanja di <span id="nama_toko_footer"><?= htmlspecialchars($nama_user) ?></span>
      </div>
    </div>
  </div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" charset="utf-8"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript">

  $("#load").fadeIn();
  let GLOBAL_PELANGGAN = "-";
  let GLOBAL_HARGA_JUAL = 0;

  $(document).ready(async function () {
    try {
      const trx = <?= $trx_json ?>;

      if (trx) {
        let desc_detail = {};
        try {
          if (trx.desc_detail) {
            // Check if it's a string that needs parsing
            if (typeof trx.desc_detail === 'string') {
              desc_detail = JSON.parse(trx.desc_detail);
            } else {
              desc_detail = trx.desc_detail;
            }
          }
        } catch (e) {
          console.error("Error parsing desc_detail:", e);
        }

        GLOBAL_PELANGGAN = trx.buyer_user || trx.nama_user || trx.customer_name || trx.customer_no || "-";
        GLOBAL_HARGA_JUAL = (trx.price_user && parseFloat(trx.price_user) !== 0) ? trx.price_user : (trx.selling_price || trx.price || 0);

        $('#nomor_pembayaran').text("#" + trx.ref_id);
        $('#terakhir_update').text(trx.created_at);
        $('#status_transaksi').text(trx.status || trx.message || "-");

        let tipe_struk = "standart";
        if (trx.command === "pay-pasca" || trx.command === "inquiry-pasca" || trx.command === "pay" || trx.command === "inquiry") {
          tipe_struk = "pascabayar";
        } else if (trx.product_name && trx.product_name.toLowerCase().includes("pln")) {
          tipe_struk = "pln";
        } else if (trx.product_name && (trx.product_name.toLowerCase().includes("pulsa") || trx.product_name.toLowerCase().includes("data"))) {
          tipe_struk = "pulsa";
        } else if (trx.product_name && trx.product_name.toLowerCase().includes("voucher")) {
          tipe_struk = "voucher";
        }

        let data_ppob = {};
        if (tipe_struk === "pascabayar") {
            // Handle both formats: { desc: { ... } } or { ... }
            let source = desc_detail.desc || desc_detail;
            
            if (source && typeof source === 'object') {
                for (let key in source) {
                    // Sembunyikan key 'admin'
                    if (key.toLowerCase() === 'admin') continue;
                    
                    if (typeof source[key] !== 'object') {
                        data_ppob[key] = source[key];
                    } else if (Array.isArray(source[key])) {
                        // Handle arrays like 'detail'
                        source[key].forEach((item, index) => {
                            if (typeof item === 'object') {
                                for (let subKey in item) {
                                    if (subKey.toLowerCase() === 'admin') continue;
                                    // Gunakan index jika ada lebih dari 1 item
                                    let displayKey = source[key].length > 1 ? `${subKey}_${index + 1}` : subKey;
                                    data_ppob[displayKey] = item[subKey];
                                }
                            } else {
                                data_ppob[`${key}_${index + 1}`] = item;
                            }
                        });
                    } else if (source[key] !== null) {
                        // Nested object
                        for (let subKey in source[key]) {
                            if (subKey.toLowerCase() === 'admin') continue;
                            data_ppob[subKey] = source[key][subKey];
                        }
                    }
                }
            }
        } else if (tipe_struk === "pln" && desc_detail.customer_name) {
            data_ppob = {
                nama_pelanggan: desc_detail.customer_name,
                tarif_daya: desc_detail.segment_power
            };
        }

        let token_pln = "";

        if (tipe_struk === "pln") {
            if (trx.sn && trx.sn.includes("/")) {
                token_pln = trx.sn.split("/")[0];
            } else {
                token_pln = desc_detail.token || trx.sn || "";
            }
        }

        // bersihkan trx.sn dari karakter yang tidak perlu untuk ditampilkan di struk (kecuali untuk token pln yang sudah di-handle khusus di atas)
        let dSn = (trx.sn || "")
                  .replace(/[`'"]/g, "")
                  .replace(/\s+/g, " ")
                  .trim();

        const data_produk = {
          nama_barang: trx.product_name || trx.buyer_sku_code,
          catatan: trx.customer_no,
          nomor_resi: dSn,
          data_ppob: data_ppob,
          token_pln: token_pln
        };

        if (tipe_struk == "pln") {
          getTemplatePLN(data_produk);
        } else if (tipe_struk == "pulsa") {
          getTemplatePulsa(data_produk);
        } else if (tipe_struk == "voucher") {
          getTemplateVoucher(data_produk);
        } else if (tipe_struk == "pascabayar") {
          getTemplatePascabayar(data_produk);
        } else {
          getTemplateStandart(data_produk);
        }

        $('#total_footer').append(getTotalStruk("Sub Total", GLOBAL_HARGA_JUAL));
        
        let admin_fee = 0;
        if (tipe_struk === "pascabayar" && desc_detail.admin) {
            admin_fee = parseInt(desc_detail.admin);
            $('#total_footer').append(getTotalStruk("Admin", admin_fee));
        }

        const totalTransaksi = Number(GLOBAL_HARGA_JUAL) + admin_fee;

        $('#total_transaksi').text(formatRupiah(totalTransaksi));

      } else {
        alert("Data transaksi tidak ditemukan");
      }
    } catch (e) {
      console.error(e);
      alert("Terjadi kesalahan saat mengambil data");
    }
  });

  // wrapTextEvery 30 char
  function wrapTextEvery(str, n = 30) {
    if (!str) return "-";

    return str
      // Pisah berdasarkan spasi, tetapi simpan spasinya juga
      .split(/(\s+)/)
      .map(block => {

        // Jika hanya spasi → kembalikan apa adanya
        if (block.trim() === "") {
          return block;
        }

        // Jika block mengandung spasi → langsung return (tidak wrap)
        if (block.includes(" ")) {
          return block;
        }

        // Jika block TANPA spasi tapi panjangnya kecil → tidak wrap
        if (block.length <= n) {
          return block;
        }

        // Jika panjang dan tanpa spasi → wrap per n karakter
        return block.match(new RegExp(`.{1,${n}}`, "g")).join("<br>");
      })
      .join("");
  }



  function getTemplatePLN(data_produk) {

    let string_data_ppob = "";

    function labelize(text) {
      return text.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
    }

    if (data_produk.data_ppob && Object.keys(data_produk.data_ppob).length > 0) {
      for (let key in data_produk.data_ppob) {
        string_data_ppob += `
          <tr>
            <td>${labelize(key)}</td>
            <td id="str_key_ppob_${key}"></td>
          </tr>
        `;
      }
    } else {
      string_data_ppob = `
        <tr>
          <td>No. Resi</td>
          <td>: ${data_produk.nomor_resi}</td>
        </tr>
      `;
    }


    let token_pln = "";
    if (data_produk.token_pln) {
      token_pln = `
        <span class="mt-4 text-center">Token</span>
        <span class="catatan_class text-break text-center fw-bold text-space mb-4 fs-2 token_pln">${data_produk.token_pln}</span>`;
    }
    let html_produk = `

    <table style="width:100%; font-family: Arial, sans-serif; font-size:14px; border-collapse:collapse;">
      <tr>
        <td colspan="2" style="font-weight:bold; font-size:16px; text-align:center; padding-bottom:10px;">DETAIL TRANSAKSI</td>
      </tr>
      <tr><td style="width:100px;">ID PLN</td><td>: ${data_produk.catatan}</td></tr>
      <tr><td>Produk</td><td>: ${data_produk.nama_barang}</td></tr>
      <tr><td>Harga</td><td>: ${formatRupiah(GLOBAL_HARGA_JUAL)}</td></tr>
      <tr><td>Buyer</td><td>: ${GLOBAL_PELANGGAN}</td></tr>
      ${string_data_ppob}
      <div class="d-flex flex-column mb-2 ">
        ${token_pln}
      </div>

    </table>`;
    $('#list_produk').append(html_produk);
    // Potong tiap 25 karakter untuk semua data_ppob
    if (data_produk.data_ppob && data_produk.data_ppob instanceof Object) {
      for (let key in data_produk.data_ppob) {
        const value = data_produk.data_ppob[key] || "-";
        const wrapped = wrapTextEvery(value.toString(), 25);

        const el = document.getElementById(`str_key_ppob_${key}`);
        if (el) {
          el.innerHTML = ": " + wrapped;
        }
      }
    }


  }

  function getTemplatePulsa(data_produk) {
    let html_produk = `
    <table style="width:100%; font-family: Arial, sans-serif; font-size:14px; border-collapse:collapse;">
      <tr>
        <td colspan="2" style="font-weight:bold; font-size:16px; text-align:center; padding-bottom:10px;">DETAIL TRANSAKSI</td>
      </tr>
      <tr><td style="width:100px;">No. HP</td><td>: ${data_produk.catatan}</td></tr>
      <tr><td>Produk</td><td>: ${data_produk.nama_barang}</td></tr>
      <tr><td>Harga</td><td>: ${formatRupiah(GLOBAL_HARGA_JUAL)}</td></tr>
      <tr><td>Buyer</td><td>: ${GLOBAL_PELANGGAN}</td></tr>
      <tr><td>SN / Ref</td><td id="sn_ref"></td></tr>
    </table>`;
    $('#list_produk').append(html_produk);

    let sn = data_produk.nomor_resi || "-";
    sn = wrapTextEvery(sn, 25); // bisa ubah 30 jadi 40 atau lainnya
    document.getElementById("sn_ref").innerHTML = ": " + sn;
  }

  function getTemplatePascabayar(data_produk) {
    let string_data_ppob = "";

    function labelize(text) {
      return text.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
    }

    if (data_produk.data_ppob && data_produk.data_ppob instanceof Object) {
      for (let key in data_produk.data_ppob) {
        string_data_ppob += `
          <tr>
            <td>${labelize(key)}</td>
            <td id="str_key_ppob_${key}"></td>
          </tr>
        `;
      }
    }

    let html_produk = `
    <table style="width:100%; font-family: Arial, sans-serif; font-size:14px; border-collapse:collapse;">
      <tr>
        <td colspan="2" style="font-weight:bold; font-size:16px; text-align:center; padding-bottom:10px;">DETAIL TRANSAKSI</td>
      </tr>
      <tr><td style="width:100px;">ID PEL.</td><td>: ${data_produk.catatan}</td></tr>
      <tr><td>Produk</td><td>: ${data_produk.nama_barang}</td></tr>
      <tr><td>Harga</td><td>: ${formatRupiah(GLOBAL_HARGA_JUAL)}</td></tr>
      <tr><td>Buyer</td><td>: ${GLOBAL_PELANGGAN}</td></tr>
      <tr><td>SN/Ref</td><td id="sn_ref"></td></tr>
      ${string_data_ppob}

    </table>`;
    $('#list_produk').append(html_produk);

    let sn = data_produk.nomor_resi || "-";
    sn = wrapTextEvery(sn, 25); // bisa ubah 30 jadi 40 atau lainnya
    document.getElementById("sn_ref").innerHTML = ": " + sn;

    // Potong tiap 25 karakter untuk semua data_ppob
    if (data_produk.data_ppob && data_produk.data_ppob instanceof Object) {
      for (let key in data_produk.data_ppob) {
        const value = data_produk.data_ppob[key] || "-";
        const wrapped = wrapTextEvery(value.toString(), 25);

        const el = document.getElementById(`str_key_ppob_${key}`);
        if (el) {
          el.innerHTML = ": " + wrapped;
        }
      }
    }
  }

  function getTemplateVoucher(data_produk) {
    let html_produk = `

    <table style="width:100%; font-family: Arial, sans-serif; font-size:14px; border-collapse:collapse;">
      <tr>
        <td colspan="2" style="font-weight:bold; font-size:16px; text-align:center; padding-bottom:10px;">DETAIL TRANSAKSI</td>
      </tr>
      <tr><td style="width:100px;">No. Tujuan</td><td>: ${data_produk.catatan}</td></tr>
      <tr><td>Produk</td><td>: ${data_produk.nama_barang}</td></tr>
      <tr><td>Harga</td><td>: ${formatRupiah(GLOBAL_HARGA_JUAL)}</td></tr>
      <tr><td>Buyer</td><td>: ${GLOBAL_PELANGGAN}</td></tr>
      <tr><td>SN / Ref</td><td id="sn_ref"></td></tr>
    </table>`;
    $('#list_produk').append(html_produk);

    let sn = data_produk.nomor_resi || "-";
    sn = wrapTextEvery(sn, 25); // bisa ubah 30 jadi 40 atau lainnya
    document.getElementById("sn_ref").innerHTML = ": " + sn;

  }

  function getTemplateStandart(data_produk) {
    let string_data_ppob = "";

    function labelize(text) {
      return text.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
    }

    if (data_produk.data_ppob && data_produk.data_ppob instanceof Object) {
      for (let key in data_produk.data_ppob) {
        string_data_ppob += `
          <tr>
            <td>${labelize(key)}</td>
            <td id="str_key_ppob_${key}"></td>
          </tr>
        `;
      }
    }

    let html_produk = `
    <table style="width:100%; font-family: Arial, sans-serif; font-size:14px; border-collapse:collapse;">
      <tr>
        <td colspan="2" style="font-weight:bold; font-size:16px; text-align:center; padding-bottom:10px;">DETAIL TRANSAKSI</td>
      </tr>
      <tr><td style="width:100px;">No. Tujuan</td><td>: ${data_produk.catatan}</td></tr>
      <tr><td>Produk</td><td>: ${data_produk.nama_barang}</td></tr>
      <tr><td>Harga</td><td>: ${formatRupiah(GLOBAL_HARGA_JUAL)}</td></tr>
      <tr><td>Buyer</td><td>: ${GLOBAL_PELANGGAN}</td></tr>
      <tr><td>SN/Ref</td><td id="sn_ref"></td></tr>
      ${string_data_ppob}

    </table>`;
    $('#list_produk').append(html_produk);

    let sn = data_produk.nomor_resi || "-";
    sn = wrapTextEvery(sn, 25); // bisa ubah 30 jadi 40 atau lainnya
    document.getElementById("sn_ref").innerHTML = ": " + sn;

    // Potong tiap 25 karakter untuk semua data_ppob
    if (data_produk.data_ppob && data_produk.data_ppob instanceof Object) {
      for (let key in data_produk.data_ppob) {
        const value = data_produk.data_ppob[key] || "-";
        const wrapped = wrapTextEvery(value.toString(), 25);

        const el = document.getElementById(`str_key_ppob_${key}`);
        if (el) {
          el.innerHTML = ": " + wrapped;
        }
      }
    }

  }

  function getTotalStruk(judul, nilai) {
    if (nilai != 0) {
      return `<div class="d-flex justify-content-end">
          <div class="pb-2">${judul}</div>
          <div class="pb-2 ps-2">:</div>
          <div class="pb-2 text_harga_total">${formatRupiah(nilai)}</div>
        </div>`;
    }
  }

  function formatRupiah(angka) {
    if (angka === undefined) { return "Gagal muat"; } angka = angka.toString(); let is_minus = angka.charAt(0) == '-' ? true : false; if (is_minus) { angka = angka.substring(1); } var number_string = angka.toString().replace(/[^,\d]/g, '').toString(), split = number_string.split(','), sisa = split[0].length % 3, rupiah = split[0].substr(0, sisa), ribuan = split[0].substr(sisa).match(/\d{3}/gi); if (ribuan) { separator = sisa ? '.' : ''; rupiah += separator + ribuan.join('.'); } rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah; let minus_sign = is_minus ? "-" : ""; return minus_sign + 'Rp' + rupiah;
  }

  function formatPascabayarKey(key_ppob) {
    return key_ppob
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }

  // jeda cetak struk 1 detik setelah halaman terbuka untuk memastikan data sudah ter-render semua
  setTimeout(() => {
    // apakah nomor_pembayaran sudah terisi? jika belum, berarti data belum ter-render semua, maka jangan cetak dulu
    if (document.getElementById("nomor_pembayaran").innerText.trim() !== "") {
      $("#load").fadeOut();
      // redirect ke https://urlwebsiteolshop.olshopku.com/print_halaman?aksi=print
      url = "https://store-upay.my.id/print_halaman?aksi=print";
      window.location.href = url;
    } else {
      console.warn("Data belum ter-render semua, menunda cetak struk...");
    }
  }, 2000);
</script>

</html>
