<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: *');
header('Access-Control-Allow-Headers: *');
require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Fungsi untuk mendapatkan konfigurasi dari DB
function getConfig()
{
    global $pdo;
    $config = ['okeconnect_member_id' => '', 'okeconnect_pin' => '', 'okeconnect_password' => '', 'ppob_secret' => '', 'token_bo' => '', 'telegram_bot_token_ppob' => '', 'telegram_chat_id' => ''];
    if (!$pdo) return $config;

    $stmt = $pdo->query("SELECT key_name, key_value FROM settings");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $config[$row['key_name']] = $row['key_value'];
    }
    return $config;
}

$config = getConfig();

// Verifikasi Signature dari Website PPOB
function verify_signature($config)
{
    if (empty($config['ppob_secret'])) {
        // Jika secret belum diatur, tolak semua request untuk keamanan
        http_response_code(401);
        echo json_encode(['error' => 'PPOB Secret Key belum dikonfigurasi di Admin.']);
        exit;
    }

    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $signature_header = $headers['X-Signature'] ?? $headers['x-signature'] ?? $_SERVER['HTTP_X_SIGNATURE'] ?? $_GET['sign'] ?? $_POST['sign'] ?? 'Assffgf';
    $token =  $headers['X-Token'] ?? $headers['x-token'] ?? $_SERVER['HTTP_X_TOKEN'] ?? $_GET['token'] ?? $_POST['token'] ?? 'asadef';
    $action = $_GET['action'] ?? '';

    if (empty($signature_header)) {
        http_response_code(401);
        echo json_encode(['error' => 'Missing Signature. Harap sertakan header X-Signature atau parameter sign.']);
        exit;
    }

    global $pdo;
    /** @var PDO $pdo */
    $stmt = $pdo->prepare("SELECT * FROM token_signature WHERE token = ? AND action = ? AND signature = ?");
    $stmt->execute([$token, $_GET['action'] ?? '', $signature_header]);
    if ($stmt->fetch(PDO::FETCH_ASSOC)) {
        http_response_code(401);
        echo json_encode(['error' => 'Token tidak berlaku']);
        exit;
    }
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {

        // ambil semua query
        $params = $_GET;

        // hapus yang tidak ikut di-sign
        unset($params['sign'], $params['token']);

        // WAJIB SORT
        ksort($params);

        // build query string
        $queryString = http_build_query($params);

        // payload GET
        $payload = $queryString . "|" . $action . "|" . $token;
    } else {
        $raw = file_get_contents('php://input');
        $payload = $raw . "|" . $action . "|" . $token;
    }

    // Generate expected signature
    $expected_signature = hash('sha256', $payload . $config['ppob_secret']);

    if (!hash_equals($expected_signature, $signature_header)) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid signature.']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO token_signature (token, action, signature) VALUES (?, ?, ?)");
    $stmt->execute([$token, $_GET['action'] ?? '', $signature_header]);

    $pdo->exec("DELETE FROM token_signature WHERE created_at < NOW() - INTERVAL 7 DAY");
}

function getDevice($ua){

    if (preg_match('/Android\s+\d+;\s+(.+?)\s+Build/i', $ua, $m)) {
        return trim($m[1]);
    }

    return "UNKNOWN";
}

// Ambil aksi dari parameter URL
$action = $_GET['action'] ?? '';

// ATUR PEMBATASAN UNTUK VERIFIKASI SIGNATURE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action !== 'Member') {
    verify_signature($config);
}

// Fungsi helper untuk request cURL ke Digiflazz
function digiflazz_request($endpoint, $payload)
{
    $ch = curl_init('https://api.digiflazz.com/v1/' . $endpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

$token_bo = $config['token_bo'] ?? '';

function updateSaldoMember($id_user, $tipe, $jumlah, $catatan, $token_bo, $pin_user = "111111", $oid = null)
{
    $header = array("Authorization: Bearer " . $token_bo);

    $post_body = array(
        "id_user" => $id_user,
        "tipe" => $tipe, // tambah / kurang
        "jumlah" => $jumlah,
        "catatan_saldo" => $catatan,
        "token" => $token_bo,
        "pin" => $pin_user,
    );

    // DIRECT KE API BUKAOLSHOP
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://bukaolshop.net/api/v1/member/saldo");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_body);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $hasil = curl_exec($ch);
        curl_close($ch);

        return json_decode($hasil, true);
}

// === NEW CODE: TELEGRAM HELPER FUNCTION (TOPUP) ===
function sendTelegramNotif($pdo, $product_name, $harga, $trx, $newStatus, $source = [])
{
    global $config;

    $botToken = trim($config['telegram_bot_token_ppob'] ?? '');
    $chatId   = trim($config['telegram_chat_id'] ?? '');

    if (!$botToken || !$chatId) {
        error_log("Telegram config kosong");
        return false;
    }

    // source bisa array atau string
    if (is_string($source)) {

        $decode = json_decode($source, true);

        if (json_last_error() === JSON_ERROR_NONE) {
            $data = $decode;
        } else {
            $data = [
                'message' => $source
            ];
        }

    } else {

        $data = $source;

    }

    $refId    = $data['ref_id'] ?? $trx;
    $customer = $data['customer_no'] ?? '-';
    $produk   = $product_name ?: '-';
    $status   = $data['status'] ?? $newStatus;
    $msg      = $data['message'] ?? '-';
    $nama_user = $data['nama_user'] ?? '-';
    $id_user = $data['id_user'] ?? '-';

    $price = is_numeric($harga)
        ? number_format($harga, 0, ',', '.')
        : '-';

    $emoji = match(strtolower($status)) {
        'sukses', 'success' => '✅',
        'pending'           => '⏳',
        'gagal', 'failed'   => '❌',
        default             => 'ℹ️'
    };

    // limit pesan
    $msg = substr(strip_tags($msg), 0, 2000);

    $message =
"$emoji <b>📦TRANSAKSI DARI {$nama_user} - {$id_user}</b>

<b>🆔 Ref ID:</b>
<code>{$refId}</code>

<b>📦 Produk:</b>
{$produk}
<b>👤 Customer:</b> <code>{$customer}</code>
<b>💰 Harga:</b> Rp {$price}
<b>📊 Status:</b> {$status}

<b>💬 Pesan:</b>
{$msg}

#ppob #transaksi";

    $payload = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];

    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";

    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 10
    ]);

    $response = curl_exec($ch);
    $err      = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    // debug log
    file_put_contents(
        __DIR__ . '/telegram_log.txt',
        date('Y-m-d H:i:s') .
        "\nHTTP: {$httpCode}" .
        "\nERROR: {$err}" .
        "\nRESPONSE: {$response}" .
        "\n====================\n",
        FILE_APPEND
    );

    if ($err || $httpCode != 200) {
        return false;
    }

    return true;
}

// Ambil aksi dari parameter URL sudah dipindah ke atas

if ($action === 'products') {
    $type = $_GET['type'] ?? '';
    $category = $_GET['category'] ?? '';
    $name = $_GET['name'] ?? '';
    $brand = $_GET['brand'] ?? '';
    $membership = $_GET['membership'] ?? '';

    if (empty($membership)) {
        $headers = function_exists('getallheaders') ? getallheaders() : [];
        $membership = $headers['X-Membership'] ?? $headers['x-membership'] ?? '';
    }

    if (!$pdo) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }

    $params = [];
    if (!empty($membership)) {
        $query = "SELECT p.buyer_sku_code, p.product_name, p.category, p.brand, p.type, p.seller_name, 
                         (p.sell_price + COALESCE(mp.price_adjustment, 0)) as price, 
                         p.buyer_product_status, p.seller_product_status, p.unlimited_stock, p.stock, 
                         p.multi, p.start_cut_off, p.end_cut_off, p.description, p.product_type, p.margin, p.admin 
                  FROM products p 
                  LEFT JOIN membership_prices mp ON p.buyer_sku_code = mp.buyer_sku_code AND mp.membership_name = ?
                  WHERE p.display = 1";
        $params[] = $membership;
    } else {
        $query = "SELECT p.buyer_sku_code, p.product_name, p.category, p.brand, p.type, p.seller_name, 
                         p.sell_price as price, 
                         p.buyer_product_status, p.seller_product_status, p.unlimited_stock, p.stock, 
                         p.multi, p.start_cut_off, p.end_cut_off, p.description, p.product_type, p.margin, p.admin 
                  FROM products p 
                  WHERE p.display = 1";
    }

    if ($type !== '') {
        $query .= " AND p.product_type = ?";
        $params[] = $type;
    }
    if ($category !== '') {
        $query .= " AND p.category = ?";
        $params[] = $category;
    }
    if ($name !== '') {
        $query .= " AND p.product_name LIKE ?";
        $params[] = "%$name%";
    }

    if ($brand !== '') {
        $query .= " AND p.brand = ?";
        $params[] = $brand;
    }

    $query .= " ORDER BY p.brand ASC, p.sell_price ASC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['data' => $products]);
    exit;
}

if ($action === 'transaction') {

    $input = json_decode(file_get_contents('php://input'), true);

    if (empty($config['okeconnect_member_id']) || empty($config['okeconnect_pin']) || empty($config['okeconnect_password'])) {
        echo json_encode(['error' => 'Konfigurasi OkeConnect belum diatur di Admin.']);
        exit;
    }

    $buyer_sku_code = $input['buyer_sku_code'] ?? '';
    $customer_no    = $input['customer_no'] ?? '';
    $cmd            = $input['cmd'] ?? '';
    $id_user        = $input['id_user'] ?? '';
    $nama_user      = $input['nama_user'] ?? '';
    $pin_user       = $input['pin_user'] ?? '';
    $amount         = (int)($input['amount'] ?? 0);

    $userIp         = $_SERVER['REMOTE_ADDR'] ?? '-';

    // cek apakah device saat ini sama dengan device terakhir yang login
    $uaRaw = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ua = getDevice($uaRaw);

    file_put_contents(
        "debug_device.log",
        date("Y-m-d H:i:s") .
        "\nRAW UA: " . $uaRaw .
        "\nPARSE UA: " . $ua .
        "\nID USER: " . $id_user .
        "\n----------------------\n",
        FILE_APPEND
    );

    // =========================
    // CEK DEVICE USER
    // =========================

    if (!empty($id_user)) {

        $stmtDevice = $pdo->prepare("
            SELECT ua 
            FROM Member 
            WHERE id_user = ?
            LIMIT 1
        ");
        $stmtDevice->execute([$id_user]);

        $memberDevice = $stmtDevice->fetch(PDO::FETCH_ASSOC);

        if (!$memberDevice) {
            echo json_encode([
                "status" => false,
                "code" => "USER_NOT_FOUND",
                "message" => "User tidak ditemukan"
            ]);
            exit;
        }


        $deviceDB = $memberDevice['ua'] ?? '';

        file_put_contents(
            "debug_device.log",
            date("Y-m-d H:i:s") .
            "\nDEVICE DB: " . $deviceDB .
            "\nDEVICE NOW: " . $ua .
            "\nCOMPARE: " . ($deviceDB === $ua ? "SAMA" : "BEDA") .
            "\n----------------------\n",
            FILE_APPEND
        );


        // kalau database masih kosong, simpan device pertama
        if (empty($deviceDB) || $deviceDB == '-') {

            $updateDevice = $pdo->prepare("
                UPDATE Member 
                SET ua = ?
                WHERE id_user = ?
            ");

            $updateDevice->execute([
                $ua,
                $id_user
            ]);

        } else {


            // kalau device berbeda, blokir
            if ($deviceDB !== $ua) {

                echo json_encode([
                    "status" => false,
                    "code" => "NOT_ALLOWED",
                    "message" => "Silahkan Hubungi Admin",
                    // "device_login" => $ua,
                    // "device_terdaftar" => $deviceDB
                ]);
                exit;
            }

        }
    }


    $ref_id = $input['ref_id'] ?? ('TRX_' . time() . rand(100, 999));

    if (empty($ref_id) || empty($buyer_sku_code) || empty($customer_no)) {
        echo json_encode(['error' => 'Parameter ref_id, buyer_sku_code, dan customer_no wajib diisi.']);
        exit;
    }

    if ($amount > 0) {
        if ($amount < 10000 || $amount > 1000000) {
            echo json_encode(['error' => 'Nominal transaksi bebas harus antara Rp 10.000 dan Rp 1.000.000.']);
            exit;
        }
    }

    // Ambil produk
    /** @var PDO $pdo */
    $stmt = $pdo->prepare("SELECT product_type, price, sell_price, margin, product_name FROM products WHERE buyer_sku_code = ?");
    $stmt->execute([$buyer_sku_code]);
    $p = $stmt->fetch(PDO::FETCH_ASSOC);

    $product_type = $p['product_type'] ?? 'prepaid';
    $harga        = ($amount > 0) ? ($amount + (int)($p['sell_price'] ?? 0)) : ($p['sell_price'] ?? 0);
    $product_name = $p['product_name'] ?? $buyer_sku_code;

    // Check if member has restricted products
    if (!empty($id_user)) {
        $stmt_mem = $pdo->prepare("SELECT restricted_products, nama_membership FROM Member WHERE id_user = ?");
        $stmt_mem->execute([$id_user]);
        $member = $stmt_mem->fetch(PDO::FETCH_ASSOC);

        if ($member) {
            $restricted = $member['restricted_products'] ?? '';
            if (!empty($restricted)) {
                $restricted_skus = array_map('trim', explode(',', strtolower($restricted)));
                if (in_array(strtolower($buyer_sku_code), $restricted_skus)) {
                    echo json_encode(['error' => 'Maaf, Anda tidak dapat membeli produk ini (produk dibatasi).']);
                    exit;
                }
            }
            if (!empty($member['nama_membership'])) {
                $membership = $member['nama_membership'];
            }
        }
    }

    // Apply membership adjustment
    $membership_input = $input['membership'] ?? '';
    if (empty($membership_input)) {
        $headers = function_exists('getallheaders') ? getallheaders() : [];
        $membership_input = $headers['X-Membership'] ?? $headers['x-membership'] ?? '';
    }
    // Prefer database membership if set, otherwise use input
    $active_membership = !empty($membership) ? $membership : $membership_input;
    if (!empty($active_membership)) {
        $stmt_adj = $pdo->prepare("SELECT price_adjustment FROM membership_prices WHERE membership_name = ? AND buyer_sku_code = ?");
        $stmt_adj->execute([$active_membership, $buyer_sku_code]);
        $adjustment = $stmt_adj->fetchColumn();
        if ($adjustment !== false) {
            $harga += (int)$adjustment;
        }
    }

    $db_command = 'topup';
    $perluPotongSaldo = false;
    $is_check = false;

    // =========================
    // Tentukan command + potong saldo
    // =========================
    if ($cmd === 'status') {
        $db_command = 'status';
        $is_check = true;
    } else if ($cmd === 'inquiry') {
        $db_command = 'inquiry';
    } else if ($cmd === 'pay-pasca') {
        $db_command = 'pay-pasca';
        $perluPotongSaldo = true;

        $inquiry_ref_id = $ref_id;
        $ref_id = 'PAY_' . time() . rand(100, 999);

        $stmt = $pdo->prepare("
            SELECT selling_price, admin_fee
            FROM transactions
            WHERE ref_id = ?
            AND command = 'inquiry'
            LIMIT 1
        ");

        $stmt->execute([$inquiry_ref_id]);
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$transaction) {
            echo json_encode([
                'status' => false,
                'message' => 'Data inquiry tidak ditemukan.'
            ]);
            exit;
        }

        $amount_inquiry = (int)($transaction['selling_price'] ?? 0);
        $margin_produk  = (int)($p['margin'] ?? 0);

        $harga = $amount_inquiry + $margin_produk;

        if ($harga < 0) {
            $harga = 0;
        }
    } else {
        $db_command = 'topup';
        $perluPotongSaldo = true;
    }

    // =========================
    // POTONG SALDO (HANYA JIKA PERLU)
    // =========================

    if ($perluPotongSaldo) {

        $hasil = updateSaldoMember($id_user, "kurang", $harga, "Pembelian " . $product_name, $token_bo, $pin_user);

        if (!is_array($hasil)) {
            echo json_encode([
                'status' => false,
                'message' => 'Response saldo tidak valid'
            ]);
            exit;
        }

        if (($hasil['code'] ?? 0) != 200) {
            echo json_encode([
                'status' => 'failed',
                'message' => 'Saldo tidak cukup / gagal potong saldo',
                'data' => $hasil
            ]);
            exit;
        }
    }

    // =========================
    // SIMPAN TRANSAKSI
    // =========================
    if ($db_command !== 'status') {
        $stmt = $pdo->prepare("
            INSERT INTO transactions 
            (ref_id, buyer_sku_code, customer_no, command, status, message, id_user, nama_user, ip)
            VALUES (?, ?, ?, ?, 'Pending', 'Memproses transaksi...', ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
                command = VALUES(command),
                status = 'Pending',
                updated_at = CURRENT_TIMESTAMP
        ");
        $stmt->execute([$ref_id, $buyer_sku_code, $customer_no, $db_command, $id_user, $nama_user, $userIp]);

        if (!empty($id_user)) {
            $stmt_member_upsert = $pdo->prepare("
                INSERT INTO Member (id_user, nama_user, nama_membership, jumlah_transaksi)
                VALUES (?, ?, ?, 1)
                ON DUPLICATE KEY UPDATE
                    nama_user = VALUES(nama_user),
                    jumlah_transaksi = jumlah_transaksi + 1,
                    last_login = CURRENT_TIMESTAMP
            ");
            $stmt_member_upsert->execute([$id_user, $nama_user, !empty($active_membership) ? $active_membership : 'Umum']);
        }
    }

    // =========================
    // HIT API OKECONNECT
    // =========================
    $memberID = urlencode($config['okeconnect_member_id']);
    $pin = urlencode($config['okeconnect_pin']);
    $password = urlencode($config['okeconnect_password']);
    
    if ($is_check) {
        $url = "https://h2h.okeconnect.com/trx?pin=$pin&product=$buyer_sku_code&dest=$customer_no&refID=$ref_id&memberID=$memberID&password=$password&check=1";
    } else {
        $url = "https://h2h.okeconnect.com/trx?product=$buyer_sku_code&dest=$customer_no&refID=$ref_id&memberID=$memberID&pin=$pin&password=$password";
    }

    if ($amount > 0) {
        $url .= "&qty=" . $amount;
    }

    if (!empty($input['testing'])) {
        // Mock response
        $resText = "T#123 R#$ref_id Testing $buyer_sku_code.$customer_no akan diproses. Saldo";
    } else {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $resText = curl_exec($ch);
        curl_close($ch);
    }

    $status = 'Pending';
    if (stripos($resText, 'SUKSES') !== false || stripos($resText, 'Sukses') !== false) {
        $status = 'Sukses';
    } else if (stripos($resText, 'GAGAL') !== false || stripos($resText, 'Gagal') !== false) {
        $status = 'Gagal';
    } else if (stripos($resText, 'diproses') !== false) {
        $status = 'Pending';
    } else if (stripos($resText, 'Format') !== false || stripos($resText, 'salah') !== false || stripos($resText, 'belum terdaftar') !== false) {
        $status = 'Gagal'; // API Error
    }

    $res = [
        'data' => [
            'ref_id' => $ref_id,
            'buyer_sku_code' => $buyer_sku_code,
            'customer_no' => $customer_no,
            'status' => $status,
            'message' => $resText,
            'price' =>($amount > 0) ? ($amount + (int)($p['price'] ?? 0)) : ($p['price'] ?? 0),
            'selling_price' => $harga
        ]
    ];

    // =========================
    // UPDATE HASIL
    // =========================
    if (isset($res['data'])) {

        $d = $res['data'];
        $harga_db = $d['selling_price'] ?? $harga;
        
        $modal = $d['selling_price'] ?? $p['price'] ?? 0;
        $total_harga = $modal + ($p['margin'] ?? 0);

        // Jika gagal dan sebelumnya potong saldo -> kembalikan
        if ($status === 'Gagal' && $perluPotongSaldo) {

            sleep(6);

            $refSaldo = updateSaldoMember($id_user, "tambah", $modal, "Refund " . $product_name, $token_bo);

            if (($refSaldo['code'] ?? 0) != 200) {
                sendTelegramNotif($pdo, $product_name, $modal, $ref_id, 'Gagal Refund Saldo', json_encode($refSaldo));
            } else {
                sendTelegramNotif($pdo, $product_name, $modal, $ref_id, 'Berhasil Refund Saldo', json_encode($refSaldo));
            }
        }

        // extract SN if success
        $sn = '';
        if ($status === 'Sukses') {
            $snMatch = [];
            if (preg_match('/SN:\s*(.*?)\s*Saldo/i', $resText, $snMatch)) {
                $sn = $snMatch[1];
            }
        } else if ($status === 'Gagal') {
            if (preg_match('/KET:\s*(.*?)\s*Saldo/i', $resText, $snMatch)) {
                $sn = $snMatch[1];
            } else if (preg_match('/GAGAL.\s*(.*?)\s*Saldo/i', $resText, $snMatch)) {
                $sn = $snMatch[1];
            }
        }

        // message tanpa bagian informasi saldo. hapus bagian "Saldo xxx" jika ada
        $resText = preg_replace('/Saldo\s*[\d\.,]+/i', '', $resText);

        $rc = ''; // Initialize $rc of transaction result

        $update_sql = "UPDATE transactions SET
            status = ?,
            message = ?,
            rc = ?,
            sn = ?";

        $update_params = [
            $status,
            $resText,
            $rc,
            $sn
        ];

        if (stripos($sn, 'TAG:') !== false) {
            $parsed_customer_name = '';
            $parsed_tag = 0;
            $parsed_admin = 0;
            $parsed_ttag = 0;

            if (preg_match('/^(.*?)\/TAG:/i', $sn, $m)) {
                $parsed_customer_name = trim($m[1]);
            }
            if (preg_match('/TAG:(\d+)/i', $sn, $m)) {
                $parsed_tag = (int)$m[1];
            }
            if (preg_match('/ADMIN:(\d+)/i', $sn, $m)) {
                $parsed_admin = (int)$m[1];
            }
            if (preg_match('/TTAG:(\d+)/i', $sn, $m)) {
                $parsed_ttag = (int)$m[1];
            } else {
                $parsed_ttag = $parsed_tag + $parsed_admin;
            }

            if ($db_command === 'pay-pasca' || ($p['product_type'] ?? '') === 'pasca') {
                $update_sql .= ", selling_price = ?, customer_name = ?, admin_fee = ?, price = ?";
                $update_params[] = $parsed_ttag + (int)($p['margin'] ?? 0);
                $update_params[] = $parsed_customer_name;
                $update_params[] = $parsed_admin;
                $update_params[] = $parsed_ttag;
            } else {
                $update_sql .= ", selling_price = ?, customer_name = ?, admin_fee = ?, price = ?";
                $update_params[] = $parsed_ttag;
                $update_params[] = $parsed_customer_name;
                $update_params[] = $parsed_admin;
                $update_params[] = $parsed_ttag;
            }
        } else {
            $update_sql .= ", price = ?, selling_price = ?";
            $update_params[] = ($amount > 0) ? ($amount + (int)($p['price'] ?? 0)) : ($p['price'] ?? 0);
            $update_params[] = $harga;
        }

        $update_sql .= " WHERE ref_id = ?";
        $update_params[] = $ref_id;

        $stmt = $pdo->prepare($update_sql);
        $stmt->execute($update_params);

        sendTelegramNotif(
            $pdo,
            $product_name,
            $harga,
            $ref_id,
            $status,
            [
                'ref_id' => $ref_id,
                'customer_no' => $customer_no,
                'status' => $status,
                'message' => $resText,
                'nama_user' => $nama_user,
                'id_user' => $id_user
            ]
        );
    }

    echo json_encode($res);
    exit;
}

if ($action === 'history') {
    $id_user = $_GET['id_user'] ?? '';
    $start_date = $_GET['start_date'] ?? '';
    $end_date = $_GET['end_date'] ?? '';

    if (empty($id_user)) {
        echo json_encode(['error' => 'Parameter id_user wajib diisi.']);
        exit;
    }

    if (!$pdo) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }

    $query = "SELECT t.*, p.product_name FROM transactions t LEFT JOIN products p ON t.buyer_sku_code = p.buyer_sku_code WHERE t.id_user = ?";
    $params = [$id_user];

    if (!empty($start_date)) {
        $query .= " AND t.created_at >= ?";
        $params[] = $start_date;
    }

    if (!empty($end_date)) {
        $query .= " AND t.created_at <= ?";
        $params[] = $end_date;
    }

    $query .= " ORDER BY t.created_at DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['data' => $transactions, 'success' => true]);
    exit;
}

if ($action === 'update_transaction') {
    $input = json_decode(file_get_contents('php://input'), true);
    $ref_id = $input['ref_id'] ?? '';
    $buyer_user = $input['buyer_user'] ?? '';
    $price_user = $input['price_user'] ?? 0;

    if (empty($ref_id)) {
        echo json_encode(['error' => 'Parameter ref_id wajib diisi.']);
        exit;
    }

    if (!$pdo) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }

    $stmt = $pdo->prepare("UPDATE transactions SET buyer_user = ?, price_user = ? WHERE ref_id = ?");
    $result = $stmt->execute([$buyer_user, $price_user, $ref_id]);

    if ($result) {
        echo json_encode(['code' => 200, 'message' => 'Transaksi berhasil diperbarui.']);
    } else {
        echo json_encode(['code' => 500, 'message' => 'Gagal memperbarui transaksi.']);
    }
    exit;
}

if ($action === 'delete_transaction') {
    $ref_id = $_GET['ref_id'] ?? '';

    if (empty($ref_id)) {
        echo json_encode(['error' => 'Parameter ref_id wajib diisi.']);
        exit;
    }

    if (!$pdo) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM transactions WHERE ref_id = ?");
    $result = $stmt->execute([$ref_id]);

    if ($result) {
        echo json_encode(['code' => 200, 'message' => 'Transaksi berhasil dihapus.']);
    } else {
        echo json_encode(['code' => 500, 'message' => 'Gagal menghapus transaksi.']);
    }
    exit;
}

if ($action === 'trx') {
    $ref_id = $_GET['ref_id'] ?? '';

    if (empty($ref_id)) {
        echo json_encode(['error' => 'Parameter ref_id wajib diisi.']);
        exit;
    }

    if (!$pdo) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT t.*, p.product_name FROM transactions t LEFT JOIN products p ON t.buyer_sku_code = p.buyer_sku_code WHERE t.ref_id = ? ORDER BY t.created_at DESC");
    $stmt->execute([$ref_id]);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['data' => $transactions]);
    exit;
} 

if ($action === 'cron') {

    // 🔥 AMBIL DATA LAMA
    $existing = [];

    $q = $pdo->query("
        SELECT buyer_sku_code, sell_price, margin
        FROM products
    ");

    while ($r = $q->fetch(PDO::FETCH_ASSOC)) {
        $existing[$r['buyer_sku_code']] = $r;
    }

    $changed = [];
    $count = 0;

    // =========================
    // GET OKECONNECT DATA
    // =========================

    $ch = curl_init('https://okeconnect.com/harga/json?id=905ccd028329b0a');

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 60
    ]);

    $response = curl_exec($ch);

    curl_close($ch);

    $res_data = json_decode($response, true);

    if (!is_array($res_data)) {

        echo json_encode([
            'success' => false,
            'message' => 'Format data API Okeconnect tidak valid'
        ]);

        exit;
    }

    // ==================================================
    // AMBIL SEMUA KATEGORI UNIK
    // ==================================================

    $categories = [];

    foreach ($res_data as $item) {

        if (empty($item['kategori'])) {
            continue;
        }

        $slug = strtolower(trim($item['kategori']));
        $slug = preg_replace('/\s+/', '_', $slug);

        $categories[$slug] = true;
    }

    // ==================================================
    // CURL MULTI KE SAMAKI
    // ==================================================

    $desc_map = [];

    $multiHandle = curl_multi_init();

    $handles = [];

    foreach (array_keys($categories) as $slug) {

        $url = "https://orkutku.my.id/cek/v3/desc.php?category=" . urlencode($slug);

        $ch = curl_init();

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        ]);

        curl_multi_add_handle($multiHandle, $ch);

        $handles[$slug] = $ch;
    }

    $running = null;

    do {

        $status = curl_multi_exec($multiHandle, $running);

        if ($running) {
            curl_multi_select($multiHandle, 1);
        }

    } while ($running && $status == CURLM_OK);

    // ==================================================
    // PROSES HASIL SAMAKI
    // ==================================================

    foreach ($handles as $slug => $ch) {

        $response = curl_multi_getcontent($ch);

        $samaki = json_decode($response, true);

        if (
            isset($samaki['vouchers']['results']) &&
            is_array($samaki['vouchers']['results'])
        ) {

            foreach ($samaki['vouchers']['results'] as $row) {

                if (
                    !empty($row['code']) &&
                    isset($row['description'])
                ) {

                    $desc_map[strtoupper(trim($row['code']))]
                        = $row['description'];
                }
            }
        }

        curl_multi_remove_handle($multiHandle, $ch);

        curl_close($ch);
    }

    curl_multi_close($multiHandle);

    // ==================================================
    // SINKRONISASI PRODUK
    // ==================================================

    $api_skus = [];

    $stmt = $pdo->prepare("
        INSERT INTO products
        (
            buyer_sku_code,
            product_name,
            category,
            brand,
            type,
            seller_name,
            price,
            sell_price,
            buyer_product_status,
            seller_product_status,
            unlimited_stock,
            stock,
            multi,
            start_cut_off,
            end_cut_off,
            description,
            product_type,
            margin
        )
        VALUES
        (
            ?, ?, ?, ?,
            'Umum',
            'Okeconnect',
            ?, ?,
            ?, 1,
            1,
            9999,
            0,
            '',
            '',
            ?,
            'prepaid',
            0
        )
        ON DUPLICATE KEY UPDATE
            category = VALUES(category),
            brand = VALUES(brand),
            price = VALUES(price),
            sell_price = VALUES(price) + margin,
            buyer_product_status = VALUES(buyer_product_status),
            description = IFNULL(VALUES(description), description)
    ");

    foreach ($res_data as $p) {

        if (!is_array($p)) {
            continue;
        }

        if (empty($p['kode'])) {
            continue;
        }

        $sku = trim($p['kode']);

        $api_skus[] = $sku;

        $price = (int)($p['harga'] ?? 0);

        $margin = $existing[$sku]['margin'] ?? 0;

        $new_sell = $price + $margin;

        $old_sell = $existing[$sku]['sell_price'] ?? null;

        if ($old_sell !== null && $old_sell != $new_sell) {

            $changed[] = [
                'sku'  => $sku,
                'nama' => $p['keterangan'] ?? '',
                'old'  => $old_sell,
                'new'  => $new_sell
            ];
        }

        // Cari deskripsi dari Samaki berdasarkan code
        $description = $desc_map[strtoupper($sku)] ?? null;

        $stmt->execute([
            $sku,
            $p['keterangan'] ?? '',
            $p['kategori'] ?? '',
            $p['produk'] ?? '',
            $price,
            $price,
            (isset($p['status']) && $p['status'] == '1') ? 1 : 0,
            $description
        ]);

        $count++;
    }

    // ==================================================
    // NONAKTIFKAN PRODUK YANG HILANG
    // ==================================================

    if (!empty($api_skus)) {

        $in = str_repeat('?,', count($api_skus) - 1) . '?';

        $stmt = $pdo->prepare("
            UPDATE products
            SET buyer_product_status = 0
            WHERE buyer_sku_code NOT IN ($in)
        ");

        $stmt->execute($api_skus);
    }

    echo json_encode([
        'success' => true,
        'message' => "Berhasil sinkronisasi {$count} produk Okeconnect.",
        'count' => $count,
        'categories' => count($categories),
        'descriptions_loaded' => count($desc_map),
        'changed_total' => count($changed),
        'changed' => array_slice($changed, 0, 20)
    ]);

    exit;
}

if ($action === 'Member') {
    global $pdo;

    $uaRaw = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ua = getDevice($uaRaw);

    // Pastikan database terhubung
    if (!$pdo) {
        echo json_encode(["error" => "Koneksi database gagal"]);
        exit;
    }

    // Ambil & sanitasi data dari request body
    $id_user = trim($_POST['id_user'] ?? '');
    $nama_user = htmlspecialchars(trim($_POST['nama_user'] ?? ''), ENT_QUOTES, 'UTF-8');
    $nomor_telepon = trim($_POST['nomor_telepon'] ?? '');
    $email_user = filter_var($_POST['email_user'] ?? '', FILTER_VALIDATE_EMAIL) ? trim($_POST['email_user']) : '';
    $saldo_user = (int)($_POST['saldo_user'] ?? 0);
    $nama_membership = htmlspecialchars(trim($_POST['nama_membership'] ?? 'Umum'), ENT_QUOTES, 'UTF-8');
    $poin_member = (int)($_POST['poin_member'] ?? 0);
    $jumlah_transaksi = (int)($_POST['jumlah_transaksi'] ?? 0);

    if (empty($id_user)) {
        echo json_encode(["error" => "ID User tidak boleh kosong"]);
        exit;
    }

    // Cek apakah id_user sudah ada di database. Jika sudah ada, update. Jika belum, insert.
    $sql = "SELECT id_user, ua FROM Member WHERE id_user = :id_user";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id_user', $id_user);
    $stmt->execute();
    $exists = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($exists) {
        // kalau UA kosong atau -
        if (empty($exists['ua']) || $exists['ua'] === '-') {
            $sql = "UPDATE Member SET 
                        nama_user = :nama_user, 
                        nomor_telepon = :nomor_telepon, 
                        email_user = :email_user, 
                        saldo_user = :saldo_user, 
                        nama_membership = :nama_membership, 
                        poin_member = :poin_member, 
                        jumlah_transaksi = :jumlah_transaksi,
                        ua = :ua
                    WHERE id_user = :id_user";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':ua', $ua);
            $msg = "Data user diupdate + UA disimpan";
        } else {
            $sql = "UPDATE Member SET 
                        nama_user = :nama_user, 
                        nomor_telepon = :nomor_telepon, 
                        email_user = :email_user, 
                        saldo_user = :saldo_user, 
                        nama_membership = :nama_membership, 
                        poin_member = :poin_member, 
                        jumlah_transaksi = :jumlah_transaksi
                    WHERE id_user = :id_user";
            $stmt = $pdo->prepare($sql);
            $msg = "Data user diupdate (UA lama dipertahankan)";
        }
        $stmt->bindParam(':nama_user', $nama_user);
        $stmt->bindParam(':nomor_telepon', $nomor_telepon);
        $stmt->bindParam(':email_user', $email_user);
        $stmt->bindParam(':saldo_user', $saldo_user);
        $stmt->bindParam(':nama_membership', $nama_membership);
        $stmt->bindParam(':poin_member', $poin_member);
        $stmt->bindParam(':jumlah_transaksi', $jumlah_transaksi);
        $stmt->bindParam(':id_user', $id_user);
        $stmt->execute();

        echo json_encode([
            "success" => true,
            "message" => $msg
        ]);
    } else {
        $sql = "INSERT INTO Member 
                    (id_user, nama_user, nomor_telepon, email_user, saldo_user, nama_membership, poin_member, jumlah_transaksi, last_login, ua) 
                VALUES 
                    (:id_user, :nama_user, :nomor_telepon, :email_user, :saldo_user, :nama_membership, :poin_member, :jumlah_transaksi, :last_login, :ua)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id_user', $id_user);
        $stmt->bindParam(':nama_user', $nama_user);
        $stmt->bindParam(':nomor_telepon', $nomor_telepon);
        $stmt->bindParam(':email_user', $email_user);
        $stmt->bindParam(':saldo_user', $saldo_user);
        $stmt->bindParam(':nama_membership', $nama_membership);
        $stmt->bindParam(':poin_member', $poin_member);
        $stmt->bindParam(':jumlah_transaksi', $jumlah_transaksi);
        $last_login = date("Y-m-d H:i:s");
        $stmt->bindParam(':last_login', $last_login);
        $stmt->bindParam(':ua', $ua);
        $stmt->execute();
        echo json_encode(array("message" => "Data user berhasil disimpan"));
    }
    exit;
}

// Jika tidak ada aksi yang cocok
echo json_encode(['error' => 'Aksi tidak valid. Gunakan ?action=products, ?action=transaction, atau ?action=history.']);
