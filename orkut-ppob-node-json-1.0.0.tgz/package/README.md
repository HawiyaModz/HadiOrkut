# ORKUT Node.js 20-24 — JSON + Closed API

- Node.js 20–24
- Tanpa MySQL/MariaDB
- JSON storage di `data/`
- Closed API dengan `CLOSED_API_KEY`
- Kredensial provider disimpan server-side

Jalankan:

```bash
npm install
npm start
```

Salin `.env.example` menjadi `.env` lalu isi `CLOSED_API_KEY` dan `SESSION_SECRET`.

Lihat `CLOSED-API.md` untuk endpoint API tertutup.
